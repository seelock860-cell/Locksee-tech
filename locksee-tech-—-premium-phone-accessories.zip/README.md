# LOCKSEE TECH — Premium Phone Accessories & Consumer Electronics

Nigeria's premier online store for authentic smartphone accessories, high-power GaN chargers, rugged MagSafe cases, heavy-capacity power banks, and studio-grade audio gear.

---

## 🌟 Brand & Visual Identity
- **Primary Background**: Black (`#080808`)
- **Secondary Background**: Dark Charcoal (`#151515`)
- **Accent Colour**: Metallic Gold (`#D4AF37`)
- **Main Text**: Pure White (`#FFFFFF`)
- **Secondary Text**: Light Grey (`#B8B8B8`)
- **Typography**: Cinzel (luxury display headings) + Plus Jakarta Sans (ultra-clean body font)
- **Zero-Pill Discipline**: High-contrast, clean typography, refined border geometry, anti-AI-slop design.

---

## 🚀 Key Features

1. **Full-Featured E-Commerce Catalogue**:
   - 9 Curated categories: Phone Cases, Screen Protectors, Chargers and Cables, Power Banks, Earphones and Headphones, Smartwatches, Bluetooth Speakers, Phone Holders and Stands, Other Phone Accessories.
   - Real-time search, category filtering, availability filters, and price sorting.
   - Genuine specifications and verified stock counts.

2. **Functional Shopping Cart**:
   - Stock limit validation (prevents ordering quantities exceeding warehouse stock).
   - Dynamic delivery fee computation (Lagos: ₦2,500; Nationwide 35 other states & FCT: ₦4,500).
   - One-tap WhatsApp order export with formatted breakdown.

3. **Secure Checkout & Server-Side Validation**:
   - **Never trusts client-side prices**: Subtotals are recomputed server-side against authenticated database product prices.
   - **Strict stock reservation**: Rejects orders if stock is depleted by concurrent buyers.
   - Generates unique reference code (`LT-YYYYMMDD-XXXX`).
   - All orders default strictly to `unpaid` upon initial submission.

4. **Payment Options**:
   - **Direct Bank Transfer (GTBank)**: Full corporate details displayed (Bank: Guaranty Trust Bank, Account: 0123456789, Account Name: LOCKSEE TECH ENTERPRISES) with clear notice that orders remain pending until manually verified by the accounting desk.
   - **Online Card / USSD Payment**: Prepared for Paystack / Flutterwave integration with HMAC SHA512 webhook signature verification and duplicate-event protection.
   - **WhatsApp Assisted Checkout**: Direct WhatsApp routing to `09024971419` with international link formatting.

5. **Customer Order Tracking**:
   - Real-time tracker modal by unguessable Order Reference (`LT-YYYYMMDD-XXXX`).
   - Live delivery pipeline: Received → Confirmed → Processing → In Transit → Delivered.

6. **Secure Administrator Control Portal**:
   - Protected route with session tokens. Initial username: `lock`.
   - **Overview**: Verified sales revenue vs unpaid orders, total orders, low-stock warnings.
   - **Product Management**: Add, edit pricing, update stock, delete with confirmation, toggle featured items.
   - **Order Management**: Inspect delivery address, update statuses, confirm verified bank transfers, export CSV.
   - **Homepage Editor**: Update headline, subtext, and promotional banner.
   - **Store & Bank Settings**: Update WhatsApp number (`09024971419`), GTBank details, and delivery fees.
   - **Supabase Integration Status**: Live connection status, table architecture, and copyable SQL migration scripts.
   - **Audit Logs**: Immutable log of administrative actions.

---

## 🗄️ Supabase PostgreSQL Integration

LOCKSEE TECH includes full PostgreSQL database schema, constraints, and Row Level Security (RLS) policies.

### SQL Migration Setup:
1. Open the [Supabase Dashboard](https://supabase.com).
2. Go to your project's **SQL Editor**.
3. Copy the script from `src/db/supabase-migration.sql` (or copy it directly from the Admin Dashboard's **Supabase Status** tab).
4. Run the query to initialize the 8 tables:
   - `profiles`
   - `categories`
   - `products`
   - `orders`
   - `order_items`
   - `payments`
   - `store_settings`
   - `admin_audit_logs`
5. Configure your project credentials in your environment variables.

---

## ⚙️ Environment Variables (`.env`)

```env
# AI Studio Runtime
PORT=3000
APP_URL="http://localhost:3000"

# Admin Authentication
ADMIN_USERNAME="lock"
ADMIN_PASSWORD="LockseeTech2026!#"
ADMIN_JWT_SECRET="locksee-tech-super-secure-jwt-secret-key-2026"

# Supabase Integration (Optional: Local fallback active by default)
SUPABASE_URL="https://your-project.supabase.co"
SUPABASE_ANON_KEY="your-anon-public-key"
SUPABASE_SERVICE_ROLE_KEY="your-service-role-key"

# Nigerian Payment Gateways (Paystack / Flutterwave)
PAYSTACK_SECRET_KEY="sk_live_..."
PAYSTACK_PUBLIC_KEY="pk_live_..."
FLUTTERWAVE_SECRET_KEY="FLWSECK_..."
FLUTTERWAVE_PUBLIC_KEY="FLWPUBK_..."

# WhatsApp Ordering Support Number
WHATSAPP_NUMBER="09024971419"
```

---

## 🧪 Automated Tests

Run the automated checkout and payment validation tests:

```bash
npm test
```

Verifies:
- Order reference formatting (`LT-YYYYMMDD-XXXX`)
- Lagos vs Nationwide delivery fee logic
- Server-side stock limit checks
- Price tampering rejection
- Unpaid order default status
- WhatsApp international number encoding (`2349024971419`)

---

## 🚢 Deployment Instructions

### Option 1: Deploying to Vercel (1-Click & Recommended)

This project is pre-configured for Vercel with zero extra setup needed (`vercel.json` and serverless API routing via `api/index.ts` are already included):

#### Method A — Deploy via GitHub (Recommended):
1. Push this project to your GitHub account (or export the codebase).
2. Go to [vercel.com/new](https://vercel.com/new) and log in.
3. Import your GitHub repository.
4. In the **Configure Project** step:
   - **Framework Preset**: Vite
   - **Root Directory**: `./` (leave default)
   - **Build Command**: `npm run build` (auto-detected)
   - **Output Directory**: `dist` (auto-detected)
5. Add your **Environment Variables** in the Vercel dashboard:
   - `ADMIN_USERNAME`: `lock`
   - `ADMIN_PASSWORD`: `lock123`
   - `SUPABASE_URL`: `https://udlxgbbafjyrxzraucoc.supabase.co`
   - `SUPABASE_ANON_KEY`: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVkbHhnYmJhZmp5cnh6cmF1Y29jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMxNzU3MDksImV4cCI6MjEwODc1MTcwOX0.3CZAM1caQO69kIWk0_tMSwlhszxqQPr1fTqaJWcHoT8`
   - `ADMIN_JWT_SECRET`: Any random secure string (e.g. `locksee-secret-2026-prod-key`)
   - `WHATSAPP_NUMBER`: `09024971419`
6. Click **Deploy**. Vercel will build and assign you a free `*.vercel.app` live domain with automatic SSL certificates!

#### Method B — Deploy via Vercel CLI:
```bash
npm install -g vercel
vercel
```
Follow the prompt, accept the default settings, and run `vercel --prod` to deploy to production.

---

### Option 2: Render / Railway / Heroku / DigitalOcean / Docker
1. Set Environment Variables matching `.env.example`.
2. Build Command: `npm run build`
3. Start Command: `npm start`
4. Port: Set to `3000` or map `$PORT`.

