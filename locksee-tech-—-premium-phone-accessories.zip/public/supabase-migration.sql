-- ============================================================================
-- LOCKSEE TECH — E-COMMERCE DATABASE MIGRATION SCRIPT FOR SUPABASE
-- Run this in the Supabase SQL Editor (https://app.supabase.com)
-- ============================================================================

-- Enable UUID extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ----------------------------------------------------------------------------
-- 1. PROFILES TABLE (for Admin & Registered Users)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT UNIQUE NOT NULL,
    full_name TEXT,
    phone_number TEXT,
    role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'admin', 'super_admin')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'profiles' AND policyname = 'Users can view own profile') THEN
        CREATE POLICY "Users can view own profile" ON profiles FOR SELECT USING (auth.uid() = id);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'profiles' AND policyname = 'Users can insert own profile') THEN
        CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'profiles' AND policyname = 'Users can update own profile') THEN
        CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);
    END IF;
END $$;

-- ----------------------------------------------------------------------------
-- 2. CATEGORIES TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    description TEXT,
    image_url TEXT,
    is_active BOOLEAN DEFAULT true,
    display_order INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'categories' AND policyname = 'Public can view active categories') THEN
        CREATE POLICY "Public can view active categories" ON categories FOR SELECT USING (is_active = true);
    END IF;
END $$;

-- ----------------------------------------------------------------------------
-- 3. PRODUCTS TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sku TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    description TEXT NOT NULL,
    price NUMERIC(12, 2) NOT NULL CHECK (price >= 0),
    discount_price NUMERIC(12, 2) CHECK (discount_price IS NULL OR discount_price >= 0),
    category_id UUID REFERENCES categories(id) ON DELETE SET NULL,
    category_name TEXT NOT NULL,
    stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
    is_featured BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    images JSONB NOT NULL DEFAULT '[]'::jsonb,
    specs JSONB DEFAULT '{}'::jsonb,
    rating NUMERIC(3, 2) DEFAULT 5.0,
    review_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_sku ON products(sku);
CREATE INDEX IF NOT EXISTS idx_products_active ON products(is_active);

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'products' AND policyname = 'Public can view active products') THEN
        CREATE POLICY "Public can view active products" ON products FOR SELECT USING (is_active = true);
    END IF;
END $$;

-- ----------------------------------------------------------------------------
-- 4. ORDERS TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reference TEXT UNIQUE NOT NULL,
    customer_name TEXT NOT NULL,
    customer_phone TEXT NOT NULL,
    customer_email TEXT,
    delivery_address TEXT NOT NULL,
    state TEXT NOT NULL,
    city TEXT NOT NULL,
    delivery_instructions TEXT,
    subtotal NUMERIC(12, 2) NOT NULL CHECK (subtotal >= 0),
    delivery_fee NUMERIC(12, 2) NOT NULL CHECK (delivery_fee >= 0),
    total_amount NUMERIC(12, 2) NOT NULL CHECK (total_amount >= 0),
    payment_method TEXT NOT NULL,
    payment_status TEXT NOT NULL DEFAULT 'unpaid',
    order_status TEXT NOT NULL DEFAULT 'pending',
    payment_reference TEXT,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_orders_reference ON orders(reference);
CREATE INDEX IF NOT EXISTS idx_orders_customer_phone ON orders(customer_phone);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(order_status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'orders' AND policyname = 'Public can insert orders') THEN
        CREATE POLICY "Public can insert orders" ON orders FOR INSERT WITH CHECK (true);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'orders' AND policyname = 'Allow select on orders') THEN
        CREATE POLICY "Allow select on orders" ON orders FOR SELECT USING (true);
    END IF;
END $$;

-- ----------------------------------------------------------------------------
-- 5. ORDER ITEMS TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS order_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id UUID REFERENCES products(id) ON DELETE SET NULL,
    product_name TEXT NOT NULL,
    product_image TEXT NOT NULL,
    sku TEXT NOT NULL,
    unit_price NUMERIC(12, 2) NOT NULL CHECK (unit_price >= 0),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    total_price NUMERIC(12, 2) NOT NULL CHECK (total_price >= 0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'order_items' AND policyname = 'Public can insert order items') THEN
        CREATE POLICY "Public can insert order items" ON order_items FOR INSERT WITH CHECK (true);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'order_items' AND policyname = 'Public can view order items') THEN
        CREATE POLICY "Public can view order items" ON order_items FOR SELECT USING (true);
    END IF;
END $$;

-- ----------------------------------------------------------------------------
-- 6. PAYMENTS TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_reference TEXT NOT NULL,
    amount NUMERIC(12, 2) NOT NULL CHECK (amount >= 0),
    provider TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'unpaid',
    transaction_id TEXT,
    provider_reference TEXT,
    raw_response JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_payments_order_ref ON payments(order_reference);

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'payments' AND policyname = 'Allow insert on payments') THEN
        CREATE POLICY "Allow insert on payments" ON payments FOR INSERT WITH CHECK (true);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'payments' AND policyname = 'Allow select on payments') THEN
        CREATE POLICY "Allow select on payments" ON payments FOR SELECT USING (true);
    END IF;
END $$;

-- ----------------------------------------------------------------------------
-- 7. STORE SETTINGS TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS store_settings (
    id TEXT PRIMARY KEY DEFAULT 'default',
    business_name TEXT NOT NULL DEFAULT 'LOCKSEE TECH',
    tagline TEXT NOT NULL DEFAULT 'Premium Phone Accessories & Gadgets Nigeria',
    whatsapp_number TEXT NOT NULL DEFAULT '09024971419',
    contact_email TEXT NOT NULL DEFAULT 'support@lockseetech.com',
    phone_number TEXT NOT NULL DEFAULT '+234 902 497 1419',
    store_address TEXT NOT NULL DEFAULT 'Lagos, Nigeria',
    delivery_fee_lagos NUMERIC(12, 2) NOT NULL DEFAULT 2500,
    delivery_fee_nationwide NUMERIC(12, 2) NOT NULL DEFAULT 4500,
    bank_name TEXT NOT NULL DEFAULT 'Guaranty Trust Bank (GTBank)',
    account_number TEXT NOT NULL DEFAULT '0123456789',
    account_name TEXT NOT NULL DEFAULT 'LOCKSEE TECH ENTERPRISES',
    bank_transfer_instructions TEXT NOT NULL DEFAULT 'Please transfer the exact order amount to the bank account above. Use your Order Reference as payment narration.',
    hero_headline TEXT NOT NULL DEFAULT 'Upgrade Your Tech. Elevate Your Lifestyle.',
    hero_subheadline TEXT NOT NULL DEFAULT 'Discover quality phone accessories, powerful gadgets, and everyday technology essentials at LOCKSEE TECH.',
    promo_banner_text TEXT NOT NULL DEFAULT 'Nationwide Fast Delivery Across Nigeria | 100% Authentic Quality Guaranteed',
    promo_banner_active BOOLEAN DEFAULT true,
    paystack_public_key TEXT DEFAULT '',
    flutterwave_public_key TEXT DEFAULT '',
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);
ALTER TABLE store_settings ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'store_settings' AND policyname = 'Public can view store settings') THEN
        CREATE POLICY "Public can view store settings" ON store_settings FOR SELECT USING (true);
    END IF;
END $$;

-- ----------------------------------------------------------------------------
-- 8. ADMIN AUDIT LOGS TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin_audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    admin_user TEXT NOT NULL,
    action TEXT NOT NULL,
    target_type TEXT NOT NULL,
    target_id TEXT NOT NULL,
    details TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);
ALTER TABLE admin_audit_logs ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'admin_audit_logs' AND policyname = 'Allow select on audit logs') THEN
        CREATE POLICY "Allow select on audit logs" ON admin_audit_logs FOR SELECT USING (true);
    END IF;
END $$;

-- ----------------------------------------------------------------------------
-- INITIAL SEED DATA FOR LOCKSEE TECH
-- ----------------------------------------------------------------------------

INSERT INTO store_settings (id, business_name, tagline, whatsapp_number, contact_email)
VALUES ('default', 'LOCKSEE TECH', 'Premium Phone Accessories & Gadgets Nigeria', '09024971419', 'support@lockseetech.com')
ON CONFLICT (id) DO NOTHING;

-- Seed Categories
INSERT INTO categories (id, name, slug, description, image_url, display_order) VALUES
('c1000000-0000-0000-0000-000000000001', 'Phone Cases', 'phone-cases', 'Military-grade armor, luxury leather & sleek MagSafe phone cases', 'https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?auto=format&fit=crop&w=600&q=80', 1),
('c1000000-0000-0000-0000-000000000002', 'Screen Protectors', 'screen-protectors', '9H tempered glass, privacy filters & edge-to-edge protection', 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=600&q=80', 2),
('c1000000-0000-0000-0000-000000000003', 'Chargers & Cables', 'chargers-and-cables', 'Fast GaN chargers, PD braided cables & wireless charging docks', 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=600&q=80', 3),
('c1000000-0000-0000-0000-000000000004', 'Power Banks', 'power-banks', 'High-capacity fast-charging power banks from 10,000mAh to 40,000mAh', 'https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?auto=format&fit=crop&w=600&q=80', 4),
('c1000000-0000-0000-0000-000000000005', 'Earphones & Headphones', 'earphones-and-headphones', 'Noise-cancelling wireless earbuds, studio headsets & deep bass sound', 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=600&q=80', 5),
('c1000000-0000-0000-0000-000000000006', 'Smartwatches', 'smartwatches', 'Health monitoring, AMOLED display, waterproof sports & lifestyle smartwatches', 'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&w=600&q=80', 6),
('c1000000-0000-0000-0000-000000000007', 'Bluetooth Speakers', 'bluetooth-speakers', 'Crisp acoustics, heavy bass, water-resistant outdoor & portable speakers', 'https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=600&q=80', 7),
('c1000000-0000-0000-0000-000000000008', 'Phone Holders & Stands', 'phone-holders-and-stands', 'Magnetic car dashboard mounts, desk stands & vlogging tripods', 'https://images.unsplash.com/photo-1586953208448-b95a79798f07?auto=format&fit=crop&w=600&q=80', 8),
('c1000000-0000-0000-0000-000000000009', 'Other Phone Accessories', 'other-accessories', 'OTG adapters, camera lens rings, cleaning kits & lanyard charms', 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=600&q=80', 9)
ON CONFLICT (slug) DO NOTHING;
