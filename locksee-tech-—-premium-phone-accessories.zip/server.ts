import express, { Request, Response, NextFunction } from 'express';
import http from 'http';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import dotenv from 'dotenv';
import { createClient } from '@supabase/supabase-js';

dotenv.config();

// Supabase Backend Configuration
const rawSupabaseUrl = process.env.SUPABASE_URL || 'https://udlxgbbafjyrxzraucoc.supabase.co';
export const sanitizedSupabaseUrl = rawSupabaseUrl.trim().replace(/\/rest\/v1\/?$/i, '').replace(/\/+$/, '');
export const supabaseAnonKey = (process.env.SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVkbHhnYmJhZmp5cnh6cmF1Y29jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMxNzU3MDksImV4cCI6MjEwODc1MTcwOX0.3CZAM1caQO69kIWk0_tMSwlhszxqQPr1fTqaJWcHoT8').trim();

export const supabase = (sanitizedSupabaseUrl && supabaseAnonKey)
  ? createClient(sanitizedSupabaseUrl, supabaseAnonKey)
  : null;

const app = express();
const PORT = process.env.PORT || 3000;
const IS_VERCEL = Boolean(process.env.VERCEL);
const DEFAULT_DATA_DIR = path.resolve(process.cwd(), 'data');
const DEFAULT_DB_FILE = path.resolve(DEFAULT_DATA_DIR, 'db.json');
const DATA_DIR = IS_VERCEL ? path.resolve('/tmp', 'data') : DEFAULT_DATA_DIR;
const DB_FILE = IS_VERCEL ? path.resolve(DATA_DIR, 'db.json') : DEFAULT_DB_FILE;

// Ensure data directory exists
try {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
} catch (err) {
  // Gracefully continue on read-only environments
}


// Initial Seed Data
const INITIAL_CATEGORIES = [
  {
    id: 'cat-1',
    name: 'Phone Cases',
    slug: 'phone-cases',
    description: 'Military-grade armor, luxury leather & sleek MagSafe phone cases',
    image_url: 'https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?auto=format&fit=crop&w=600&q=80',
    item_count: 3
  },
  {
    id: 'cat-2',
    name: 'Screen Protectors',
    slug: 'screen-protectors',
    description: '9H tempered glass, privacy filters & edge-to-edge protection',
    image_url: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=600&q=80',
    item_count: 2
  },
  {
    id: 'cat-3',
    name: 'Chargers and Cables',
    slug: 'chargers-and-cables',
    description: 'Fast GaN chargers, PD braided cables & wireless charging docks',
    image_url: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=600&q=80',
    item_count: 3
  },
  {
    id: 'cat-4',
    name: 'Power Banks',
    slug: 'power-banks',
    description: 'High-capacity fast-charging power banks from 10,000mAh to 40,000mAh',
    image_url: 'https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?auto=format&fit=crop&w=600&q=80',
    item_count: 2
  },
  {
    id: 'cat-5',
    name: 'Earphones and Headphones',
    slug: 'earphones-and-headphones',
    description: 'Noise-cancelling wireless earbuds, studio headsets & deep bass sound',
    image_url: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=600&q=80',
    item_count: 2
  },
  {
    id: 'cat-6',
    name: 'Smartwatches',
    slug: 'smartwatches',
    description: 'Health monitoring, AMOLED display, waterproof sports & lifestyle smartwatches',
    image_url: 'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&w=600&q=80',
    item_count: 1
  },
  {
    id: 'cat-7',
    name: 'Bluetooth Speakers',
    slug: 'bluetooth-speakers',
    description: 'Crisp acoustics, heavy bass, water-resistant outdoor & portable speakers',
    image_url: 'https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=600&q=80',
    item_count: 1
  },
  {
    id: 'cat-8',
    name: 'Phone Holders and Stands',
    slug: 'phone-holders-and-stands',
    description: 'Magnetic car dashboard mounts, desk stands & vlogging tripods',
    image_url: 'https://images.unsplash.com/photo-1586953208448-b95a79798f07?auto=format&fit=crop&w=600&q=80',
    item_count: 2
  },
  {
    id: 'cat-9',
    name: 'Other Phone Accessories',
    slug: 'other-phone-accessories',
    description: 'OTG adapters, camera lens rings, cleaning kits & lanyard charms',
    image_url: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=600&q=80',
    item_count: 1
  }
];

const INITIAL_PRODUCTS = [
  {
    id: 'prod-1',
    sku: 'LT-CAS-IP16PM-MAG',
    name: 'LOCKSEE UltraGuard MagSafe Armor Case (iPhone 16 Pro Max)',
    slug: 'locksee-ultraguard-magsafe-armor-case-iphone-16-pro-max',
    description: 'Military drop-tested shockproof bumper with scratch-resistant matte frosted back, reinforced N52 neodymium magnetic ring for flawless MagSafe charging, and elevated camera bezel protection.',
    price: 18500,
    discount_price: 15500,
    category_id: 'cat-1',
    category_name: 'Phone Cases',
    stock: 24,
    is_featured: true,
    is_active: true,
    images: [
      'https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1580910051074-3eb694886505?auto=format&fit=crop&w=800&q=80'
    ],
    specs: {
      'Compatibility': 'iPhone 16 Pro Max (6.9 inch)',
      'Material': 'Bayer Polycarbonate + Flexible TPU Edge',
      'MagSafe': 'N52 Magnet Array, 15W Alignment',
      'Drop Protection': 'Up to 10ft Military Spec'
    },
    rating: 4.9,
    review_count: 38,
    created_at: new Date('2026-09-15').toISOString()
  },
  {
    id: 'prod-2',
    sku: 'LT-CHG-65W-GAN',
    name: 'Anker PowerPort III 65W GaN Fast Charger (3-Port)',
    slug: 'anker-powerport-iii-65w-gan-fast-charger',
    description: 'Ultra-compact Gallium Nitride (GaN II) high-speed wall charger featuring dual USB-C Power Delivery ports and one USB-A port. Charges iPhone, Samsung, MacBooks, and tablets simultaneously with multi-protect temperature control.',
    price: 36000,
    discount_price: 32500,
    category_id: 'cat-3',
    category_name: 'Chargers and Cables',
    stock: 18,
    is_featured: true,
    is_active: true,
    images: [
      'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=800&q=80'
    ],
    specs: {
      'Total Output': '65W Max',
      'Ports': '2x USB-C PD, 1x USB-A QC 3.0',
      'Plug Type': 'UK 3-Pin (Nigeria Standard)',
      'Technology': 'GaN II Fast Charging'
    },
    rating: 4.95,
    review_count: 52,
    created_at: new Date('2026-09-18').toISOString()
  },
  {
    id: 'prod-3',
    sku: 'LT-PB-ORA-30K',
    name: 'Oraimo PowerBox 30000mAh 22.5W Fast Charge Power Bank',
    slug: 'oraimo-powerbox-30000mah-fast-charge-power-bank',
    description: 'Colossal 30,000mAh power capacity designed for Nigerian everyday reliability. Supports 22.5W Two-Way Quick Charge, LED digital battery percentage display, Type-C in/out, and dual high-speed USB outputs.',
    price: 34000,
    discount_price: 29500,
    category_id: 'cat-4',
    category_name: 'Power Banks',
    stock: 15,
    is_featured: true,
    is_active: true,
    images: [
      'https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?auto=format&fit=crop&w=800&q=80'
    ],
    specs: {
      'Capacity': '30,000mAh (111Wh)',
      'Fast Charge': '22.5W PD 3.0 & QC 3.0',
      'Display': 'LED Real-time Digital Screen',
      'Ports': '1x Type-C, 2x USB-A, 1x Micro-USB'
    },
    rating: 4.88,
    review_count: 64,
    created_at: new Date('2026-09-20').toISOString()
  },
  {
    id: 'prod-4',
    sku: 'LT-AUD-SNY-XM5',
    name: 'Sony WH-1000XM5 Wireless Noise-Cancelling Headphones',
    slug: 'sony-wh-1000xm5-wireless-noise-cancelling-headphones',
    description: 'Industry-leading Active Noise Cancellation with Auto NC Optimizer, 8 microphones for crystal clear hands-free calls, 30-hour battery life, and ultra-comfortable soft-fit leather styling.',
    price: 420000,
    discount_price: 395000,
    category_id: 'cat-5',
    category_name: 'Earphones and Headphones',
    stock: 6,
    is_featured: true,
    is_active: true,
    images: [
      'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=800&q=80'
    ],
    specs: {
      'Battery': '30 Hours with ANC On',
      'Codecs': 'LDAC, AAC, SBC',
      'Connectivity': 'Bluetooth 5.2 & 3.5mm Aux',
      'Features': 'Speak-to-Chat, Multipoint Connection'
    },
    rating: 5.0,
    review_count: 19,
    created_at: new Date('2026-09-22').toISOString()
  },
  {
    id: 'prod-5',
    sku: 'LT-SCR-PRV-9H',
    name: 'DiamondShield 28° Anti-Peeping Privacy Tempered Glass',
    slug: 'diamondshield-28-anti-peeping-privacy-tempered-glass',
    description: 'Ultra-tough 9H hardness tempered glass with 28-degree micro-louver privacy angle. Prevents onlookers from seeing your screen in public spaces while maintaining 99.9% clarity straight-on.',
    price: 7500,
    discount_price: 6000,
    category_id: 'cat-2',
    category_name: 'Screen Protectors',
    stock: 45,
    is_featured: false,
    is_active: true,
    images: [
      'https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=800&q=80'
    ],
    specs: {
      'Hardness': '9H Sapphire-Grade Coating',
      'Privacy Angle': '28° Side Blinding',
      'Oleophobic': 'Anti-Fingerprint Hydrophobic Layer',
      'Installation': 'Auto-Alignment Dust Tray Included'
    },
    rating: 4.85,
    review_count: 27,
    created_at: new Date('2026-09-25').toISOString()
  },
  {
    id: 'prod-6',
    sku: 'LT-HLD-BAS-CAR',
    name: 'Baseus 15W Qi2 MagSafe Wireless Car Mount & Charger',
    slug: 'baseus-15w-qi2-magsafe-wireless-car-mount-charger',
    description: 'Precision magnetic car air-vent holder with 15W certified wireless fast charging. 360-degree ball joint rotation for navigation and hands-free driving on Nigerian roads with strong anti-shake grip.',
    price: 24500,
    discount_price: 21000,
    category_id: 'cat-8',
    category_name: 'Phone Holders and Stands',
    stock: 20,
    is_featured: true,
    is_active: true,
    images: [
      'https://images.unsplash.com/photo-1586953208448-b95a79798f07?auto=format&fit=crop&w=800&q=80'
    ],
    specs: {
      'Charging Standard': 'Qi2 15W Wireless Fast Charge',
      'Mount Type': 'Steel-core Twist-lock Air Vent Clip',
      'Magnet Strength': '18N Neodymium MagSafe Array',
      'Included': '1m Type-C Fast Cable'
    },
    rating: 4.9,
    review_count: 31,
    created_at: new Date('2026-09-28').toISOString()
  },
  {
    id: 'prod-7',
    sku: 'LT-WCH-APP-U2',
    name: 'Apple Watch Ultra 2 GPS + Cellular 49mm Titanium',
    slug: 'apple-watch-ultra-2-gps-cellular-49mm-titanium',
    description: 'Rugged aerospace-grade titanium case with flat sapphire crystal front, customized Action button, precision dual-frequency GPS, and up to 36 hours of normal battery life.',
    price: 1150000,
    discount_price: null,
    category_id: 'cat-6',
    category_name: 'Smartwatches',
    stock: 4,
    is_featured: true,
    is_active: true,
    images: [
      'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&w=800&q=80'
    ],
    specs: {
      'Case': '49mm Aerospace Titanium',
      'Display': '3,000 Nits Always-On Retina OLED',
      'Water Resistance': '100m / Dive to 40m',
      'Connectivity': 'Cellular LTE + GPS'
    },
    rating: 5.0,
    review_count: 12,
    created_at: new Date('2026-10-01').toISOString()
  },
  {
    id: 'prod-8',
    sku: 'LT-SPK-JBL-CHG5',
    name: 'JBL Charge 5 Portable Waterproof Bluetooth Speaker',
    slug: 'jbl-charge-5-portable-waterproof-bluetooth-speaker',
    description: 'Delivers bold JBL Original Pro Sound with long excursion driver, separate tweeter, and dual pumping JBL bass radiators. IP67 waterproof and dustproof with integrated power bank.',
    price: 185000,
    discount_price: 165000,
    category_id: 'cat-7',
    category_name: 'Bluetooth Speakers',
    stock: 8,
    is_featured: true,
    is_active: true,
    images: [
      'https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=800&q=80'
    ],
    specs: {
      'Playtime': 'Up to 20 Hours',
      'Protection': 'IP67 Waterproof & Dustproof',
      'Output': '30W RMS Woofer + 10W RMS Tweeter',
      'Feature': 'Built-in Power Bank function'
    },
    rating: 4.95,
    review_count: 42,
    created_at: new Date('2026-10-05').toISOString()
  },
  {
    id: 'prod-9',
    sku: 'LT-CBL-4IN1-100W',
    name: 'TitaniumBraided 100W 4-in-1 Fast Charging Cable (1.5M)',
    slug: 'titanium-braided-100w-4-in-1-fast-charging-cable',
    description: 'Universal multi-cable with swappable tips: USB-A to Type-C, USB-A to Lightning, Type-C to Type-C (100W PD), and Type-C to Lightning (27W PD). Zinc alloy shell with 20,000+ bend lifespan.',
    price: 12000,
    discount_price: 9500,
    category_id: 'cat-3',
    category_name: 'Chargers and Cables',
    stock: 50,
    is_featured: false,
    is_active: true,
    images: [
      'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=800&q=80'
    ],
    specs: {
      'Max Power': '100W Fast Power Delivery',
      'Connectors': 'USB-A, USB-C, Lightning',
      'Length': '1.5 Metres (4.9ft)',
      'Material': 'High-density ballistic nylon'
    },
    rating: 4.8,
    review_count: 58,
    created_at: new Date('2026-10-08').toISOString()
  },
  {
    id: 'prod-10',
    sku: 'LT-CAS-S24U-ARM',
    name: 'Spigen Tough Armor Heavy Duty Case (Samsung Galaxy S24 Ultra)',
    slug: 'spigen-tough-armor-heavy-duty-case-samsung-galaxy-s24-ultra',
    description: 'Air Cushion technology with extreme impact foam lining, reinforced camera cutouts, built-in ergonomic kickstand for horizontal video watching, and precise S-Pen accessibility.',
    price: 22000,
    discount_price: 19500,
    category_id: 'cat-1',
    category_name: 'Phone Cases',
    stock: 14,
    is_featured: false,
    is_active: true,
    images: [
      'https://images.unsplash.com/photo-1580910051074-3eb694886505?auto=format&fit=crop&w=800&q=80'
    ],
    specs: {
      'Compatibility': 'Samsung Galaxy S24 Ultra (6.8 inch)',
      'Kickstand': 'Reinforced Metal Hands-free Stand',
      'Protection': 'Dual Layer TPU + Polycarbonate',
      'S-Pen Slot': 'Easy Finger Access Cutout'
    },
    rating: 4.9,
    review_count: 24,
    created_at: new Date('2026-10-10').toISOString()
  }
];

const INITIAL_SETTINGS = {
  business_name: 'LOCKSEE TECH',
  tagline: 'Premium Phone Accessories & Electronics Nigeria',
  whatsapp_number: process.env.WHATSAPP_NUMBER || '09024971419',
  contact_email: 'support@lockseetech.com',
  phone_number: '+234 902 497 1419',
  store_address: 'Suite 4B, Tech Hub Plaza, Computer Village, Ikeja, Lagos, Nigeria',
  delivery_fee_lagos: 2500,
  delivery_fee_nationwide: 4500,
  bank_name: 'Guaranty Trust Bank (GTBank)',
  account_number: '0123456789',
  account_name: 'LOCKSEE TECH ENTERPRISES',
  bank_transfer_instructions: 'Please transfer the exact order amount to the bank account above. Use your unique Order Reference as the payment narration or memo.',
  hero_headline: 'Upgrade Your Tech. Elevate Your Lifestyle.',
  hero_subheadline: 'Discover quality phone accessories, powerful gadgets, and everyday technology essentials at LOCKSEE TECH.',
  promo_banner_text: '🚚 Fast Nationwide Delivery Across All 36 States & FCT | 100% Genuine Certified Accessories',
  promo_banner_active: true,
  paystack_public_key: process.env.PAYSTACK_PUBLIC_KEY || '',
  flutterwave_public_key: process.env.FLUTTERWAVE_PUBLIC_KEY || ''
};

// Database state container
interface DatabaseSchema {
  categories: any[];
  products: any[];
  orders: any[];
  order_items: any[];
  payments: any[];
  settings: typeof INITIAL_SETTINGS;
  audit_logs: any[];
}

function loadDatabase(): DatabaseSchema {
  try {
    const fileToRead = fs.existsSync(DB_FILE) ? DB_FILE : (fs.existsSync(DEFAULT_DB_FILE) ? DEFAULT_DB_FILE : null);
    if (fileToRead) {
      const raw = fs.readFileSync(fileToRead, 'utf-8');
      const parsed = JSON.parse(raw);
      return {
        categories: parsed.categories || INITIAL_CATEGORIES,
        products: parsed.products || INITIAL_PRODUCTS,
        orders: parsed.orders || [],
        order_items: parsed.order_items || [],
        payments: parsed.payments || [],
        settings: { ...INITIAL_SETTINGS, ...(parsed.settings || {}) },
        audit_logs: parsed.audit_logs || []
      };
    }
  } catch (err) {
    console.error('Failed reading database file, initializing fresh store:', err);
  }

  const freshDb: DatabaseSchema = {
    categories: INITIAL_CATEGORIES,
    products: INITIAL_PRODUCTS,
    orders: [],
    order_items: [],
    payments: [],
    settings: INITIAL_SETTINGS,
    audit_logs: []
  };
  saveDatabase(freshDb);
  return freshDb;
}

function saveDatabase(db: DatabaseSchema) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing db.json:', err);
  }
}

let db = loadDatabase();

// Admin Authentication Helpers
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'lock';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'lock123';
const ADMIN_JWT_SECRET = process.env.ADMIN_JWT_SECRET || 'locksee-tech-jwt-secret-key-2026';

// Map of active tokens: token -> { username, expiresAt }
const activeTokens = new Map<string, { username: string; expiresAt: number }>();

function generateToken(username: string): string {
  const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000; // 30 days
  const payload = `${username}:${expiresAt}`;
  const sig = crypto.createHmac('sha256', ADMIN_JWT_SECRET).update(payload).digest('hex');
  const token = Buffer.from(`${payload}:${sig}`).toString('base64url');
  activeTokens.set(token, { username, expiresAt });
  return token;
}

function verifyAdminToken(token: string): { valid: boolean; username: string } {
  if (!token) return { valid: false, username: '' };

  // 1. Check in-memory map first
  const cached = activeTokens.get(token);
  if (cached && cached.expiresAt > Date.now()) {
    return { valid: true, username: cached.username };
  }

  // 2. Stateless HMAC verification (persists across dev server restarts)
  try {
    const decoded = Buffer.from(token, 'base64url').toString('utf-8');
    const parts = decoded.split(':');
    if (parts.length === 3) {
      const [u, expStr, sig] = parts;
      const exp = Number(expStr);
      if (!isNaN(exp) && exp > Date.now()) {
        const expectedSig = crypto.createHmac('sha256', ADMIN_JWT_SECRET).update(`${u}:${expStr}`).digest('hex');
        if (crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expectedSig))) {
          // Re-populate activeTokens cache
          activeTokens.set(token, { username: u, expiresAt: exp });
          return { valid: true, username: u };
        }
      }
    }
  } catch (err) {
    // Non-HMAC or legacy token
  }

  return { valid: false, username: '' };
}

function requireAdminAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Admin authentication token required' });
  }

  const token = authHeader.split(' ')[1];
  const { valid, username } = verifyAdminToken(token);

  if (!valid) {
    return res.status(401).json({ error: 'Unauthorized: Session expired or invalid' });
  }

  (req as any).adminUser = username || 'lock';
  next();
}

function logAudit(action: string, target_type: 'order' | 'product' | 'settings' | 'auth', target_id: string, details: string, admin_user = 'lock') {
  const log = {
    id: 'log-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
    admin_user,
    action,
    target_type,
    target_id,
    details,
    created_at: new Date().toISOString()
  };
  db.audit_logs.unshift(log);
  if (db.audit_logs.length > 500) db.audit_logs.pop();
  saveDatabase(db);
}

// Middlewares
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.resolve(process.cwd(), 'public')));

// ============================================================================
// API ROUTES
// ============================================================================

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    store: 'LOCKSEE TECH',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// Store Settings (Public)
app.get('/api/settings', (req, res) => {
  res.json({
    business_name: db.settings.business_name,
    tagline: db.settings.tagline,
    whatsapp_number: db.settings.whatsapp_number,
    contact_email: db.settings.contact_email,
    phone_number: db.settings.phone_number,
    store_address: db.settings.store_address,
    delivery_fee_lagos: db.settings.delivery_fee_lagos,
    delivery_fee_nationwide: db.settings.delivery_fee_nationwide,
    bank_name: db.settings.bank_name,
    account_number: db.settings.account_number,
    account_name: db.settings.account_name,
    bank_transfer_instructions: db.settings.bank_transfer_instructions,
    hero_headline: db.settings.hero_headline,
    hero_subheadline: db.settings.hero_subheadline,
    promo_banner_text: db.settings.promo_banner_text,
    promo_banner_active: db.settings.promo_banner_active,
    paystack_public_key: db.settings.paystack_public_key,
    flutterwave_public_key: db.settings.flutterwave_public_key
  });
});

// Update Store Settings (Admin Only)
app.put('/api/admin/settings', requireAdminAuth, (req, res) => {
  const allowedKeys = [
    'business_name', 'tagline', 'whatsapp_number', 'contact_email', 'phone_number',
    'store_address', 'delivery_fee_lagos', 'delivery_fee_nationwide', 'bank_name',
    'account_number', 'account_name', 'bank_transfer_instructions', 'hero_headline',
    'hero_subheadline', 'promo_banner_text', 'promo_banner_active', 'paystack_public_key',
    'flutterwave_public_key'
  ];

  for (const key of allowedKeys) {
    if (req.body[key] !== undefined) {
      (db.settings as any)[key] = req.body[key];
    }
  }

  saveDatabase(db);
  logAudit('UPDATE_SETTINGS', 'settings', 'global', 'Updated store configuration and payment settings');
  res.json({ success: true, settings: db.settings });
});

// Categories (Public)
app.get('/api/categories', (req, res) => {
  // Update item count dynamically
  const categoriesWithCount = db.categories.map(cat => ({
    ...cat,
    item_count: db.products.filter(p => p.category_id === cat.id && p.is_active).length
  }));
  res.json(categoriesWithCount);
});

// Products (Public)
app.get('/api/products', (req, res) => {
  const { category, search, sort, featured } = req.query;
  let filtered = db.products.filter(p => p.is_active);

  if (category && typeof category === 'string' && category !== 'all') {
    filtered = filtered.filter(p => p.category_id === category || p.category_name.toLowerCase() === category.toLowerCase());
  }

  if (featured === 'true') {
    filtered = filtered.filter(p => p.is_featured);
  }

  if (search && typeof search === 'string') {
    const q = search.toLowerCase().trim();
    filtered = filtered.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q) ||
      p.sku.toLowerCase().includes(q) ||
      p.category_name.toLowerCase().includes(q)
    );
  }

  // Sorting
  if (sort === 'price_asc') {
    filtered.sort((a, b) => (a.discount_price || a.price) - (b.discount_price || b.price));
  } else if (sort === 'price_desc') {
    filtered.sort((a, b) => (b.discount_price || b.price) - (a.discount_price || a.price));
  } else if (sort === 'rating') {
    filtered.sort((a, b) => (b.rating || 0) - (a.rating || 0));
  } else {
    // Default newest
    filtered.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  res.json(filtered);
});

// Single Product (Public)
app.get('/api/products/:id', (req, res) => {
  const product = db.products.find(p => p.id === req.params.id || p.slug === req.params.id);
  if (!product) {
    return res.status(404).json({ error: 'Product not found' });
  }
  res.json(product);
});

// Admin Products CRUD
app.get('/api/admin/products', requireAdminAuth, (req, res) => {
  res.json(db.products);
});

app.post('/api/admin/products', requireAdminAuth, (req, res) => {
  const { name, sku, description, price, discount_price, category_id, stock, is_featured, is_active, images, specs } = req.body;

  if (!name || !price || !category_id) {
    return res.status(400).json({ error: 'Name, price, and category are required' });
  }

  const category = db.categories.find(c => c.id === category_id);
  const category_name = category ? category.name : 'Other Accessories';

  const generatedSku = sku?.trim() || 'LT-' + Math.random().toString(36).substring(2, 8).toUpperCase();
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

  const newProduct = {
    id: 'prod-' + Date.now(),
    sku: generatedSku,
    name,
    slug: slug + '-' + Math.floor(Math.random() * 1000),
    description: description || '',
    price: Number(price),
    discount_price: discount_price ? Number(discount_price) : null,
    category_id,
    category_name,
    stock: Number(stock) || 0,
    is_featured: Boolean(is_featured),
    is_active: is_active !== undefined ? Boolean(is_active) : true,
    images: Array.isArray(images) && images.length ? images : ['https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=800&q=80'],
    specs: specs || {},
    rating: 5.0,
    review_count: 0,
    created_at: new Date().toISOString()
  };

  db.products.unshift(newProduct);
  saveDatabase(db);
  logAudit('CREATE_PRODUCT', 'product', newProduct.id, `Created product "${newProduct.name}" (${newProduct.sku})`);

  res.status(201).json(newProduct);
});

app.put('/api/admin/products/:id', requireAdminAuth, (req, res) => {
  const index = db.products.findIndex(p => p.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Product not found' });
  }

  const existing = db.products[index];
  const { name, sku, description, price, discount_price, category_id, stock, is_featured, is_active, images, specs } = req.body;

  let category_name = existing.category_name;
  if (category_id && category_id !== existing.category_id) {
    const cat = db.categories.find(c => c.id === category_id);
    if (cat) category_name = cat.name;
  }

  const updatedProduct = {
    ...existing,
    name: name !== undefined ? name : existing.name,
    sku: sku !== undefined ? sku : existing.sku,
    description: description !== undefined ? description : existing.description,
    price: price !== undefined ? Number(price) : existing.price,
    discount_price: discount_price !== undefined ? (discount_price ? Number(discount_price) : null) : existing.discount_price,
    category_id: category_id !== undefined ? category_id : existing.category_id,
    category_name,
    stock: stock !== undefined ? Number(stock) : existing.stock,
    is_featured: is_featured !== undefined ? Boolean(is_featured) : existing.is_featured,
    is_active: is_active !== undefined ? Boolean(is_active) : existing.is_active,
    images: Array.isArray(images) ? images : existing.images,
    specs: specs !== undefined ? specs : existing.specs,
    updated_at: new Date().toISOString()
  };

  db.products[index] = updatedProduct;
  saveDatabase(db);
  logAudit('UPDATE_PRODUCT', 'product', updatedProduct.id, `Updated product "${updatedProduct.name}"`);

  res.json(updatedProduct);
});

app.delete('/api/admin/products/:id', requireAdminAuth, (req, res) => {
  const index = db.products.findIndex(p => p.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Product not found' });
  }

  const deleted = db.products.splice(index, 1)[0];
  saveDatabase(db);
  logAudit('DELETE_PRODUCT', 'product', deleted.id, `Deleted product "${deleted.name}" (${deleted.sku})`);

  res.json({ success: true, message: 'Product deleted successfully' });
});

// ============================================================================
// CUSTOMER CHECKOUT & ORDERS (STRICT SERVER-SIDE VALIDATION)
// ============================================================================

app.post('/api/orders', (req, res) => {
  const {
    customer_name,
    customer_phone,
    customer_email,
    delivery_address,
    state,
    city,
    delivery_instructions,
    items,
    payment_method,
    notes
  } = req.body;

  // 1. Validate required customer input
  if (!customer_name || !customer_phone || !delivery_address || !state || !city) {
    return res.status(400).json({ error: 'Please provide all required delivery details (Name, Phone, Address, State, City)' });
  }

  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Cart is empty. Add items before checking out.' });
  }

  // 2. SERVER-SIDE STOCK & PRICE VALIDATION
  let calculatedSubtotal = 0;
  const verifiedOrderItems: any[] = [];
  const stockDeductionPlan: { productIndex: number; newStock: number }[] = [];

  for (const item of items) {
    const productIndex = db.products.findIndex(p => p.id === item.product_id);
    if (productIndex === -1) {
      return res.status(400).json({ error: `Product with ID ${item.product_id} no longer exists in our catalogue.` });
    }

    const liveProduct = db.products[productIndex];

    if (!liveProduct.is_active) {
      return res.status(400).json({ error: `Product "${liveProduct.name}" is currently unavailable.` });
    }

    const requestedQty = Math.max(1, parseInt(item.quantity, 10) || 1);

    // Strictly verify available stock
    if (liveProduct.stock < requestedQty) {
      return res.status(400).json({
        error: `Insufficient stock for "${liveProduct.name}". Only ${liveProduct.stock} left in stock (you requested ${requestedQty}). Please reduce quantity.`
      });
    }

    // SERVER-SIDE PRICE (Never trust client price!)
    const verifiedUnitPrice = liveProduct.discount_price || liveProduct.price;
    const itemTotal = verifiedUnitPrice * requestedQty;
    calculatedSubtotal += itemTotal;

    verifiedOrderItems.push({
      id: 'item-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
      product_id: liveProduct.id,
      product_name: liveProduct.name,
      product_image: liveProduct.images[0] || '',
      sku: liveProduct.sku,
      unit_price: verifiedUnitPrice,
      quantity: requestedQty,
      total_price: itemTotal
    });

    stockDeductionPlan.push({
      productIndex,
      newStock: liveProduct.stock - requestedQty
    });
  }

  // 3. Compute delivery fee server-side
  const isLagos = state.toLowerCase().includes('lagos');
  const delivery_fee = isLagos ? db.settings.delivery_fee_lagos : db.settings.delivery_fee_nationwide;
  const total_amount = calculatedSubtotal + delivery_fee;

  // 4. Generate unique Order Reference (e.g. LT-20261027-4821)
  const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  const orderReference = `LT-${dateStr}-${randomSuffix}`;

  // 5. Deduct reserved stock
  for (const plan of stockDeductionPlan) {
    db.products[plan.productIndex].stock = plan.newStock;
  }

  // 6. Create Order Record
  const newOrder = {
    id: 'ord-' + Date.now(),
    reference: orderReference,
    customer_name: customer_name.trim(),
    customer_phone: customer_phone.trim(),
    customer_email: customer_email?.trim() || '',
    delivery_address: delivery_address.trim(),
    state: state.trim(),
    city: city.trim(),
    delivery_instructions: delivery_instructions?.trim() || '',
    items: verifiedOrderItems,
    subtotal: calculatedSubtotal,
    delivery_fee,
    total_amount,
    payment_method: payment_method || 'bank_transfer',
    payment_status: 'unpaid', // Orders are NEVER marked paid automatically on submit!
    order_status: 'pending',
    notes: notes || '',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  db.orders.unshift(newOrder);

  // Link Order Items
  for (const item of verifiedOrderItems) {
    db.order_items.push({
      ...item,
      order_id: newOrder.id,
      created_at: newOrder.created_at
    });
  }

  // Create initial payment tracking record
  db.payments.push({
    id: 'pay-' + Date.now(),
    order_reference: orderReference,
    amount: total_amount,
    provider: payment_method === 'online_paystack' ? 'paystack' : payment_method === 'online_flutterwave' ? 'flutterwave' : 'bank_transfer',
    status: 'unpaid',
    created_at: new Date().toISOString()
  });

  saveDatabase(db);

  // Asynchronous replication to connected Supabase instance
  if (supabase) {
    (async () => {
      try {
        const { error: ordErr } = await supabase.from('orders').insert({
          reference: newOrder.reference,
          customer_name: newOrder.customer_name,
          customer_phone: newOrder.customer_phone,
          customer_email: newOrder.customer_email || null,
          delivery_address: newOrder.delivery_address,
          state: newOrder.state,
          city: newOrder.city,
          delivery_instructions: newOrder.delivery_instructions || null,
          subtotal: newOrder.subtotal,
          delivery_fee: newOrder.delivery_fee,
          total_amount: newOrder.total_amount,
          payment_method: newOrder.payment_method,
          payment_status: newOrder.payment_status,
          order_status: newOrder.order_status,
          notes: newOrder.notes || null,
          created_at: newOrder.created_at
        });

        if (ordErr) {
          // If the orders table is pending creation via the migration script, log note without crashing
          console.warn('Supabase sync notice:', ordErr.message);
        } else {
          console.log(`✅ Order ${newOrder.reference} replicated to Supabase backend.`);
        }
      } catch (err: any) {
        console.warn('Supabase order mirror catch:', err?.message || err);
      }
    })();
  }

  res.status(201).json({
    success: true,
    order: newOrder,
    bank_details: {
      bank_name: db.settings.bank_name,
      account_number: db.settings.account_number,
      account_name: db.settings.account_name,
      instructions: db.settings.bank_transfer_instructions
    }
  });
});

// Order Tracking (Public with exact reference)
app.get('/api/orders/track/:reference', (req, res) => {
  const ref = req.params.reference.trim().toUpperCase();
  const order = db.orders.find(o => o.reference.toUpperCase() === ref);

  if (!order) {
    return res.status(404).json({ error: 'Order reference not found. Please verify your reference number (e.g. LT-20261027-1234).' });
  }

  // Return public tracking safe information
  res.json({
    reference: order.reference,
    customer_name: order.customer_name,
    state: order.state,
    city: order.city,
    items: order.items.map((i: any) => ({
      product_name: i.product_name,
      quantity: i.quantity,
      product_image: i.product_image,
      unit_price: i.unit_price,
      total_price: i.total_price
    })),
    subtotal: order.subtotal,
    delivery_fee: order.delivery_fee,
    total_amount: order.total_amount,
    payment_method: order.payment_method,
    payment_status: order.payment_status,
    order_status: order.order_status,
    created_at: order.created_at,
    bank_details: order.payment_status === 'unpaid' ? {
      bank_name: db.settings.bank_name,
      account_number: db.settings.account_number,
      account_name: db.settings.account_name,
      instructions: db.settings.bank_transfer_instructions
    } : null
  });
});

// ============================================================================
// PAYMENT INTEGRATION (PAYSTACK & FLUTTERWAVE)
// ============================================================================

// Initialize Payment
app.post('/api/payments/initialize', async (req, res) => {
  const { order_reference, email } = req.body;

  if (!order_reference) {
    return res.status(400).json({ error: 'Order reference required' });
  }

  const order = db.orders.find(o => o.reference === order_reference);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  const paystackSecret = process.env.PAYSTACK_SECRET_KEY;
  const payerEmail = email || order.customer_email || `${order.customer_phone.replace(/[^0-9]/g, '')}@customer.lockseetech.com`;

  // Real Paystack API call if key configured
  if (paystackSecret && paystackSecret.startsWith('sk_')) {
    try {
      const response = await fetch('https://api.paystack.co/transaction/initialize', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${paystackSecret}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email: payerEmail,
          amount: Math.round(order.total_amount * 100), // in Kobo
          reference: `${order.reference}-${Date.now()}`,
          callback_url: `${process.env.APP_URL || 'http://localhost:3000'}/order-confirmation?ref=${order.reference}`,
          metadata: {
            order_reference: order.reference,
            customer_name: order.customer_name,
            phone: order.customer_phone
          }
        })
      });

      const data = await response.json();
      if (data.status && data.data?.authorization_url) {
        return res.json({
          status: 'success',
          authorization_url: data.data.authorization_url,
          access_code: data.data.access_code,
          reference: data.data.reference
        });
      } else {
        return res.status(400).json({ error: data.message || 'Payment initialization failed with provider' });
      }
    } catch (err: any) {
      console.error('Paystack initialization error:', err);
      return res.status(500).json({ error: 'Connection to payment gateway failed: ' + err.message });
    }
  }

  // Sandbox simulation mode (when PAYSTACK_SECRET_KEY is not yet configured)
  res.json({
    status: 'sandbox_ready',
    message: 'Payment gateway is ready for live/test Paystack API key. In test mode, you can verify simulation.',
    order_reference: order.reference,
    total_amount: order.total_amount,
    currency: 'NGN',
    test_reference: `TEST-${order.reference}-${Date.now()}`,
    instructions: 'Configure PAYSTACK_SECRET_KEY in server environment to enable direct live card/transfer checkout via Paystack.'
  });
});

// Verify Payment
app.get('/api/payments/verify/:reference', async (req, res) => {
  const { reference } = req.params;
  const paystackSecret = process.env.PAYSTACK_SECRET_KEY;

  // Find order associated with this reference
  const order = db.orders.find(o => o.reference === reference || o.payment_reference === reference || reference.startsWith(o.reference));
  if (!order) {
    return res.status(404).json({ error: 'Order not found for reference' });
  }

  if (paystackSecret && paystackSecret.startsWith('sk_')) {
    try {
      const response = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
        headers: { Authorization: `Bearer ${paystackSecret}` }
      });
      const data = await response.json();

      if (data.status && data.data.status === 'success') {
        const paidAmount = data.data.amount / 100;
        if (paidAmount >= order.total_amount) {
          order.payment_status = 'paid';
          order.order_status = 'confirmed';
          order.payment_reference = reference;
          order.updated_at = new Date().toISOString();

          // Update payment record
          const p = db.payments.find(pay => pay.order_reference === order.reference);
          if (p) {
            p.status = 'paid';
            p.transaction_id = data.data.id?.toString();
            p.provider_reference = reference;
            p.raw_response = data.data;
          }

          saveDatabase(db);
          logAudit('PAYMENT_VERIFIED', 'order', order.id, `Payment verified via Paystack. Amount: ₦${paidAmount.toLocaleString()}`, 'SYSTEM');

          return res.json({ verified: true, status: 'paid', order });
        }
      }

      return res.json({ verified: false, status: data.data?.status || 'unverified', message: data.message });
    } catch (err: any) {
      console.error('Paystack verification error:', err);
      return res.status(500).json({ error: 'Verification failed: ' + err.message });
    }
  }

  // If no secret key configured, return status
  res.json({
    verified: false,
    status: order.payment_status,
    message: 'Live payment verification requires PAYSTACK_SECRET_KEY. Administrators can verify bank transfers in the admin dashboard.'
  });
});

// Payment Webhook (HMAC SHA512 Signature Validation & Duplicate Protection)
app.post('/api/payments/webhook', (req, res) => {
  const paystackSecret = process.env.PAYSTACK_SECRET_KEY;
  const signature = req.headers['x-paystack-signature'];

  if (paystackSecret && signature) {
    const hash = crypto.createHmac('sha512', paystackSecret).update(JSON.stringify(req.body)).digest('hex');
    if (hash !== signature) {
      return res.status(400).send('Invalid webhook signature');
    }
  }

  const event = req.body;
  if (event && event.event === 'charge.success') {
    const data = event.data;
    const orderRef = data.metadata?.order_reference;

    if (orderRef) {
      const order = db.orders.find(o => o.reference === orderRef);
      if (order && order.payment_status !== 'paid') {
        order.payment_status = 'paid';
        order.order_status = 'confirmed';
        order.payment_reference = data.reference;
        order.updated_at = new Date().toISOString();

        const p = db.payments.find(pay => pay.order_reference === order.reference);
        if (p) {
          p.status = 'paid';
          p.transaction_id = data.id?.toString();
          p.raw_response = data;
        }

        saveDatabase(db);
        logAudit('WEBHOOK_PAYMENT_SUCCESS', 'order', order.id, `Webhook confirmed payment for ${order.reference}`, 'PAYSTACK_WEBHOOK');
      }
    }
  }

  res.sendStatus(200);
});

// ============================================================================
// ADMIN DASHBOARD AUTHENTICATION & MANAGEMENT
// ============================================================================

// Admin Login (Username: lock / is lock, Password: lock123 / is lock123)
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }

  const cleanUser = String(username).trim().toLowerCase();
  const cleanPass = String(password).trim();

  // Accept "lock" and also "is lock" to honor exact phrasing
  const validUsers = [ADMIN_USERNAME.toLowerCase(), 'lock', 'is lock'];
  // Accept "lock123" and also "is lock123"
  const validPasswords = [ADMIN_PASSWORD, 'lock123', 'is lock123'];

  if (!validUsers.includes(cleanUser) || !validPasswords.includes(cleanPass)) {
    return res.status(401).json({ error: 'Invalid administrator credentials' });
  }

  const effectiveUser = cleanUser === 'is lock' ? 'lock' : cleanUser;
  const token = generateToken(effectiveUser);
  logAudit('ADMIN_LOGIN', 'auth', effectiveUser, `Admin "${effectiveUser}" logged in successfully`);

  res.json({
    success: true,
    token,
    user: {
      username: effectiveUser,
      role: 'super_admin'
    }
  });
});

// Admin Analytics Overview
app.get('/api/admin/analytics', requireAdminAuth, (req, res) => {
  const total_orders = db.orders.length;
  const pending_orders = db.orders.filter(o => o.order_status === 'pending').length;
  const confirmed_orders = db.orders.filter(o => o.order_status === 'confirmed').length;
  const completed_orders = db.orders.filter(o => o.order_status === 'delivered').length;

  // STRICTLY DISTINGUISH recorded orders from verified revenue!
  const total_verified_revenue = db.orders
    .filter(o => o.payment_status === 'paid')
    .reduce((sum, o) => sum + o.total_amount, 0);

  const total_unpaid_revenue = db.orders
    .filter(o => o.payment_status !== 'paid' && o.order_status !== 'cancelled')
    .reduce((sum, o) => sum + o.total_amount, 0);

  const low_stock_products = db.products.filter(p => p.stock <= 5);

  res.json({
    total_orders,
    pending_orders,
    confirmed_orders,
    completed_orders,
    total_verified_revenue,
    total_unpaid_revenue,
    low_stock_products_count: low_stock_products.length,
    low_stock_products: low_stock_products.map(p => ({
      id: p.id,
      name: p.name,
      sku: p.sku,
      stock: p.stock
    })),
    total_products: db.products.length,
    recent_orders: db.orders.slice(0, 5)
  });
});

// Admin Orders List & Filter
app.get('/api/admin/orders', requireAdminAuth, (req, res) => {
  try {
    const { status, payment_status, search } = req.query;
    let filtered = Array.isArray(db.orders) ? [...db.orders] : [];

    if (status && typeof status === 'string' && status !== 'all') {
      filtered = filtered.filter(o => o.order_status === status);
    }

    if (payment_status && typeof payment_status === 'string' && payment_status !== 'all') {
      filtered = filtered.filter(o => o.payment_status === payment_status);
    }

    if (search && typeof search === 'string' && search.trim()) {
      const q = search.toLowerCase().trim();
      filtered = filtered.filter(o =>
        ((o.reference || '').toLowerCase().includes(q)) ||
        ((o.customer_name || '').toLowerCase().includes(q)) ||
        ((o.customer_phone || '').includes(q)) ||
        (o.customer_email && o.customer_email.toLowerCase().includes(q))
      );
    }

    res.json(filtered);
  } catch (err: any) {
    console.error('Error fetching admin orders:', err);
    res.status(500).json({ error: 'Failed to retrieve orders: ' + err.message });
  }
});

// Admin Supabase Migration SQL Script
app.get('/api/admin/supabase-script', (req, res) => {
  try {
    const scriptPath = path.resolve(process.cwd(), 'src/db/supabase-migration.sql');
    if (fs.existsSync(scriptPath)) {
      const content = fs.readFileSync(scriptPath, 'utf-8');
      res.type('text/plain').send(content);
    } else {
      res.status(404).json({ error: 'Migration script not found' });
    }
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to read script: ' + err.message });
  }
});

// Admin Update Order Status & Confirm Bank Transfer
app.put('/api/admin/orders/:id/status', requireAdminAuth, (req, res) => {
  const { order_status, payment_status, notes } = req.body;
  const order = db.orders.find(o => o.id === req.params.id || o.reference === req.params.id);

  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  const previousStatus = `${order.order_status} / ${order.payment_status}`;

  if (order_status) {
    order.order_status = order_status;
  }

  if (payment_status) {
    order.payment_status = payment_status;
    const p = db.payments.find(pay => pay.order_reference === order.reference);
    if (p) p.status = payment_status;
  }

  if (notes !== undefined) {
    order.notes = notes;
  }

  order.updated_at = new Date().toISOString();
  saveDatabase(db);

  logAudit(
    'UPDATE_ORDER_STATUS',
    'order',
    order.reference,
    `Status updated from [${previousStatus}] to [${order.order_status} / ${order.payment_status}] by admin`
  );

  res.json({ success: true, order });
});

// Admin Audit Logs
app.get('/api/admin/audit-logs', requireAdminAuth, (req, res) => {
  res.json(db.audit_logs.slice(0, 50));
});

// Supabase Status & Details Provider
app.get('/api/supabase/status', async (req, res) => {
  const isConfigured = Boolean(supabase && sanitizedSupabaseUrl && supabaseAnonKey);
  const projectRef = sanitizedSupabaseUrl.match(/https:\/\/([^.]+)\.supabase\.co/)?.[1] || 'udlxgbbafjyrxzraucoc';

  res.json({
    configured: isConfigured,
    url: sanitizedSupabaseUrl || 'Not Set',
    project_ref: projectRef,
    has_service_key: Boolean(process.env.SUPABASE_SERVICE_ROLE_KEY),
    status: isConfigured ? 'connected' : 'disconnected',
    message: isConfigured
      ? `Connected to Supabase project "${projectRef}" at ${sanitizedSupabaseUrl}`
      : 'Supabase credentials not configured'
  });
});

// ============================================================================
// VITE CLIENT MOUNTING (DEV / PROD)
// ============================================================================

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  const httpServer = http.createServer(app);

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const disableHmr = process.env.DISABLE_HMR === 'true';
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: disableHmr ? false : { server: httpServer }
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, () => {
    console.log(`⚡ LOCKSEE TECH server active on http://0.0.0.0:${PORT}`);
  });
}

// Start server when run directly (local dev / container / standalone node)
if (!process.env.VERCEL) {
  startServer();
}

export default app;
