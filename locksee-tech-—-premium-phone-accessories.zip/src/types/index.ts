export interface Product {
  id: string;
  sku: string;
  name: string;
  slug: string;
  description: string;
  price: number; // in NGN (Naira)
  discount_price?: number | null;
  category_id: string;
  category_name: string;
  stock: number;
  is_featured: boolean;
  is_active: boolean;
  images: string[];
  specs?: Record<string, string>;
  rating?: number;
  review_count?: number;
  created_at: string;
  updated_at?: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon_name?: string;
  image_url?: string;
  item_count?: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selected_variant?: string;
}

export type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
export type PaymentStatus = 'unpaid' | 'pending_verification' | 'paid' | 'failed' | 'refunded';
export type PaymentMethod = 'bank_transfer' | 'online_paystack' | 'online_flutterwave' | 'whatsapp';

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  product_name: string;
  product_image: string;
  sku: string;
  unit_price: number;
  quantity: number;
  total_price: number;
}

export interface Order {
  id: string;
  reference: string;
  customer_name: string;
  customer_phone: string;
  customer_email?: string;
  delivery_address: string;
  state: string;
  city: string;
  delivery_instructions?: string;
  items: OrderItem[];
  subtotal: number;
  delivery_fee: number;
  total_amount: number;
  payment_method: PaymentMethod;
  payment_status: PaymentStatus;
  order_status: OrderStatus;
  payment_reference?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface StoreSettings {
  business_name: string;
  tagline: string;
  whatsapp_number: string;
  contact_email: string;
  phone_number: string;
  store_address: string;
  delivery_fee_lagos: number;
  delivery_fee_nationwide: number;
  bank_name: string;
  account_number: string;
  account_name: string;
  bank_transfer_instructions: string;
  hero_headline: string;
  hero_subheadline: string;
  promo_banner_text: string;
  promo_banner_active: boolean;
  paystack_public_key: string;
  flutterwave_public_key: string;
}

export interface PaymentRecord {
  id: string;
  order_reference: string;
  amount: number;
  provider: 'paystack' | 'flutterwave' | 'bank_transfer';
  status: PaymentStatus;
  transaction_id?: string;
  provider_reference?: string;
  raw_response?: any;
  created_at: string;
}

export interface AdminAuditLog {
  id: string;
  admin_user: string;
  action: string;
  target_type: 'order' | 'product' | 'settings' | 'auth';
  target_id: string;
  details: string;
  created_at: string;
}

export interface AnalyticsSummary {
  total_orders: number;
  pending_orders: number;
  confirmed_orders: number;
  completed_orders: number;
  total_verified_revenue: number;
  total_unpaid_revenue: number;
  low_stock_products_count: number;
  total_products: number;
}
