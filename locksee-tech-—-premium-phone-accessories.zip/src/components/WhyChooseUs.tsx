import React from 'react';
import { ShieldCheck, Lock, Truck, Headphones, Smartphone } from 'lucide-react';

export const WhyChooseUs: React.FC = () => {
  const features = [
    {
      icon: ShieldCheck,
      title: 'Quality Products',
      description: 'Strictly authentic, manufacturer-tested phone accessories and certified chargers with actual drop and power specifications.'
    },
    {
      icon: Lock,
      title: 'Secure Checkout',
      description: 'Transparent ordering with direct corporate GTBank account transfers and verified manual accounting reconciliation.'
    },
    {
      icon: Truck,
      title: 'Nationwide Delivery',
      description: 'Prompt dispatch from Lagos to all 36 states and the Federal Capital Territory with reliable tracking on every parcel.'
    },
    {
      icon: Headphones,
      title: 'Responsive Support',
      description: 'Dedicated phone and direct WhatsApp assistance for pre-order technical advice, stock questions, and delivery updates.'
    },
    {
      icon: Smartphone,
      title: 'Convenient Ordering',
      description: 'Order effortlessly through our secure online shopping cart or send your cart straight to our sales rep on WhatsApp with one click.'
    }
  ];

  return (
    <section className="py-16 sm:py-20 bg-[#080808] border-b border-[#1f1f1f]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs uppercase font-bold tracking-[0.25em] text-[#D4AF37] block mb-2">
            The LOCKSEE Standard
          </span>
          <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-wide">
            Why Choose LOCKSEE TECH
          </h2>
          <p className="text-sm sm:text-base text-[#888888] mt-3">
            We provide genuine technology solutions backed by honest service, transparent pricing in Nigerian Naira, and fast dispatch.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {features.map((feat, idx) => {
            const Icon = feat.icon;
            return (
              <div
                key={idx}
                className="bg-[#121212] border border-[#222222] p-6 hover:border-[#D4AF37]/40 transition-colors flex flex-col justify-start"
              >
                <div className="w-12 h-12 bg-[#1a1a1a] border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] mb-5">
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-white mb-2">
                  {feat.title}
                </h3>
                <p className="text-xs text-[#999999] leading-relaxed">
                  {feat.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
