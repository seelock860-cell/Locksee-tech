import React from 'react';
import { ArrowLeft, ShieldCheck, Truck, RefreshCw, FileText, Phone, Mail, MapPin, MessageCircle } from 'lucide-react';

interface PolicyViewProps {
  view: string;
  onBack: () => void;
  whatsappNumber: string;
}

export const PolicyViews: React.FC<PolicyViewProps> = ({ view, onBack, whatsappNumber }) => {
  const cleanNumber = whatsappNumber.replace(/[^0-9]/g, '');
  const waUrl = cleanNumber.startsWith('0') ? `https://wa.me/234${cleanNumber.substring(1)}` : `https://wa.me/${cleanNumber}`;

  return (
    <div className="py-12 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 text-xs font-semibold text-[#888888] hover:text-[#D4AF37] mb-8 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Return to Store</span>
      </button>

      {/* About Us */}
      {view === 'about' && (
        <div className="space-y-8 bg-[#101010] border border-[#222222] p-8 sm:p-10">
          <div className="border-b border-[#202020] pb-6">
            <span className="text-xs uppercase font-bold tracking-widest text-[#D4AF37] block mb-2">Our Company</span>
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">About LOCKSEE TECH</h1>
          </div>

          <div className="space-y-4 text-sm text-[#B8B8B8] leading-relaxed">
            <p>
              <strong>LOCKSEE TECH</strong> is Nigeria's trusted e-commerce hub for high-grade smartphone accessories, mobile power systems, protective armor cases, and digital lifestyle electronics.
            </p>
            <p>
              Based in Computer Village, Ikeja, Lagos, we bridge the gap between discerning Nigerian smartphone users and authentic global accessory brands like Anker, Oraimo, Baseus, Spigen, Sony, and JBL.
            </p>
            <p>
              In a marketplace flooded with counterfeit cables that fry battery chips and low-grade power banks with falsified capacities, LOCKSEE TECH tests and verifies every unit in our inventory before shipping.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6 border-t border-[#202020]">
            <div className="p-4 bg-[#141414] border border-[#222222]">
              <ShieldCheck className="w-6 h-6 text-[#D4AF37] mb-2" />
              <h3 className="text-sm font-bold text-white mb-1">Authenticity Pledge</h3>
              <p className="text-xs text-[#888888]">100% genuine components with actual factory wattages and capacities.</p>
            </div>
            <div className="p-4 bg-[#141414] border border-[#222222]">
              <Truck className="w-6 h-6 text-[#D4AF37] mb-2" />
              <h3 className="text-sm font-bold text-white mb-1">Fast Delivery</h3>
              <p className="text-xs text-[#888888]">Same/next-day in Lagos; 2-4 business days across other 35 Nigerian states.</p>
            </div>
            <div className="p-4 bg-[#141414] border border-[#222222]">
              <RefreshCw className="w-6 h-6 text-[#D4AF37] mb-2" />
              <h3 className="text-sm font-bold text-white mb-1">Guaranteed Support</h3>
              <p className="text-xs text-[#888888]">Direct WhatsApp lines and immediate resolution for post-delivery needs.</p>
            </div>
          </div>
        </div>
      )}

      {/* Contact Us */}
      {view === 'contact' && (
        <div className="space-y-8 bg-[#101010] border border-[#222222] p-8 sm:p-10">
          <div className="border-b border-[#202020] pb-6">
            <span className="text-xs uppercase font-bold tracking-widest text-[#D4AF37] block mb-2">Get in Touch</span>
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">Contact LOCKSEE TECH</h1>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-sm">
            <div className="space-y-6">
              <p className="text-[#B8B8B8] leading-relaxed">
                Have questions about charger compatibility with your device, order status, or wholesale requests? Reach our friendly Lagos customer team through any of the channels below.
              </p>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold text-white">Store & Fulfillment Center</h4>
                    <p className="text-xs text-[#888888]">Suite 4B, Tech Hub Plaza, Computer Village, Ikeja, Lagos, Nigeria</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold text-white">Customer Support Line</h4>
                    <p className="text-xs text-[#888888]">+234 902 497 1419</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <MessageCircle className="w-5 h-5 text-[#25D366] shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold text-white">Direct WhatsApp Sales</h4>
                    <p className="text-xs text-[#888888]">09024971419 (Immediate response 8AM – 9PM daily)</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold text-white">Email Address</h4>
                    <p className="text-xs text-[#888888]">support@lockseetech.com</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-[#141414] border border-[#2a2a2a] p-6 space-y-4">
              <h3 className="font-bold text-white text-base">Direct Chat with Sales</h3>
              <p className="text-xs text-[#888888]">
                For instant assistance with product selection, delivery estimates, or payment verification:
              </p>
              <a
                href={waUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 px-4 bg-[#25D366] hover:bg-[#20ba59] text-black font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Chat on WhatsApp: 09024971419</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Delivery Info */}
      {view === 'delivery-info' && (
        <div className="space-y-8 bg-[#101010] border border-[#222222] p-8 sm:p-10">
          <div className="border-b border-[#202020] pb-6">
            <span className="text-xs uppercase font-bold tracking-widest text-[#D4AF37] block mb-2">Shipping Information</span>
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">Nationwide Delivery Policy</h1>
          </div>

          <div className="space-y-6 text-sm text-[#B8B8B8] leading-relaxed">
            <div className="p-4 bg-[#141414] border-l-2 border-[#D4AF37]">
              <h3 className="text-base font-bold text-white mb-1">1. Lagos Deliveries (₦2,500 Flat Fee)</h3>
              <p className="text-xs text-[#999999]">
                Orders within Lagos (Island and Mainland) are dispatched via our contracted dispatch riders. Deliveries typically arrive same-day if payment is verified before 1:00 PM, or next business day.
              </p>
            </div>

            <div className="p-4 bg-[#141414] border-l-2 border-[#D4AF37]">
              <h3 className="text-base font-bold text-white mb-1">2. Interstate & Nationwide Deliveries (₦4,500 Flat Fee)</h3>
              <p className="text-xs text-[#999999]">
                We partner with established courier networks (GIG Logistics, DHL, and Speedaf) to deliver parcels safely to all 35 Nigerian States and the Federal Capital Territory (Abuja). Transit timeline is 2 to 4 working days depending on state capital or regional outpost.
              </p>
            </div>

            <div className="p-4 bg-[#141414] border-l-2 border-[#D4AF37]">
              <h3 className="text-base font-bold text-white mb-1">3. Parcel Tracking</h3>
              <p className="text-xs text-[#999999]">
                Every customer receives a unique Order Reference (e.g. <code>LT-20261027-4821</code>) usable directly in our website's Track Order portal for live updates from dispatch to arrival.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Return Policy */}
      {view === 'return-policy' && (
        <div className="space-y-8 bg-[#101010] border border-[#222222] p-8 sm:p-10">
          <div className="border-b border-[#202020] pb-6">
            <span className="text-xs uppercase font-bold tracking-widest text-[#D4AF37] block mb-2">Warranty Guidelines</span>
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">7-Day Return & Replacement Policy</h1>
          </div>

          <div className="space-y-4 text-sm text-[#B8B8B8] leading-relaxed">
            <p>
              At LOCKSEE TECH, customer satisfaction is paramount. We provide a <strong>7-Day Replacement Guarantee</strong> on all hardware accessories against factory defects.
            </p>
            <h3 className="text-base font-bold text-white pt-2">Eligible Return Conditions:</h3>
            <ul className="list-disc pl-5 space-y-1.5 text-xs text-[#999999]">
              <li>Product is defective upon unboxing (e.g., charger fails to power on, wireless earbud pairing defect).</li>
              <li>Incorrect item received compared to your verified order invoice.</li>
              <li>Item must include all original packaging, manuals, and accessories.</li>
            </ul>
            <h3 className="text-base font-bold text-white pt-2">Non-Eligible Conditions:</h3>
            <ul className="list-disc pl-5 space-y-1.5 text-xs text-[#999999]">
              <li>Physical user damage, water damage (except on rated submersible gear), or improper electrical surge damage.</li>
              <li>Tempered glass screen protectors once peeled from their backing film and installed.</li>
            </ul>
            <p className="pt-2">
              To initiate a claim, message our WhatsApp support desk at <strong>09024971419</strong> with your order reference and a short photo or video showing the defect.
            </p>
          </div>
        </div>
      )}

      {/* Privacy Policy & Terms */}
      {(view === 'privacy-policy' || view === 'terms') && (
        <div className="space-y-8 bg-[#101010] border border-[#222222] p-8 sm:p-10">
          <div className="border-b border-[#202020] pb-6">
            <span className="text-xs uppercase font-bold tracking-widest text-[#D4AF37] block mb-2">Legal Compliance</span>
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">
              {view === 'privacy-policy' ? 'Privacy Policy' : 'Terms & Conditions'}
            </h1>
          </div>

          <div className="space-y-4 text-sm text-[#B8B8B8] leading-relaxed">
            <p>
              LOCKSEE TECH ENTERPRISES strictly respects customer data privacy under the Nigeria Data Protection Act (NDPA).
            </p>
            <p>
              We collect customer name, telephone number, and physical delivery address strictly for the purpose of courier dispatch and invoice accounting. We never sell, lease, or share customer contact records with third-party advertisers.
            </p>
            <p>
              We do not process or store online credit or debit card numbers on our servers. All transactions are conducted safely via direct bank transfers to our corporate GTBank account or through direct WhatsApp sales representatives.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
