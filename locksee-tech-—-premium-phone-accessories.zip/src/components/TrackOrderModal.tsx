import React, { useState } from 'react';
import { api } from '../lib/api';
import { X, Search, PackageCheck, Clock, CheckCircle2, Truck, AlertCircle, Loader2, Building2 } from 'lucide-react';

interface TrackOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialReference?: string;
  whatsappNumber: string;
}

export const TrackOrderModal: React.FC<TrackOrderModalProps> = ({
  isOpen,
  onClose,
  initialReference = '',
  whatsappNumber
}) => {
  const [reference, setReference] = useState(initialReference);
  const [loading, setLoading] = useState(false);
  const [orderData, setOrderData] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Lock body scroll when track order modal is open (Hook must run unconditionally)
  React.useEffect(() => {
    if (isOpen) {
      const prev = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = prev;
      };
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!reference.trim()) {
      setError('Please enter your order reference (e.g. LT-20261027-1234)');
      return;
    }

    setLoading(true);
    setError(null);
    setOrderData(null);

    try {
      const data = await api.trackOrder(reference.trim());
      setOrderData(data);
    } catch (err: any) {
      setError(err.message || 'Order reference not found');
    } finally {
      setLoading(false);
    }
  };

  const statusSteps = [
    { key: 'pending', label: 'Order Received' },
    { key: 'confirmed', label: 'Confirmed' },
    { key: 'processing', label: 'Processing / Packing' },
    { key: 'shipped', label: 'In Transit' },
    { key: 'delivered', label: 'Delivered' }
  ];

  const getStepIndex = (status: string) => {
    switch (status) {
      case 'pending': return 0;
      case 'confirmed': return 1;
      case 'processing': return 2;
      case 'shipped': return 3;
      case 'delivered': return 4;
      default: return 0;
    }
  };

  const currentIndex = orderData ? getStepIndex(orderData.order_status) : 0;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto overscroll-contain bg-black/85 backdrop-blur-sm flex justify-center items-start sm:items-center p-2 sm:p-4 py-3 sm:py-6">
      <div onClick={onClose} className="fixed inset-0 bg-transparent" aria-hidden="true" />

      <div className="relative w-full max-w-xl bg-[#0e0e0e] border border-[#2b2b2b] text-white shadow-2xl z-10 my-auto flex flex-col max-h-[94vh] sm:max-h-[90vh] overflow-hidden rounded-none">
        {/* Header - Pinned at top */}
        <div className="shrink-0 p-4 sm:p-5 border-b border-[#222222] bg-[#121212] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <PackageCheck className="w-5 h-5 text-[#D4AF37]" />
            <div>
              <h2 className="text-base sm:text-lg font-bold font-display text-white">Track Your Order</h2>
              <p className="text-[11px] text-[#888888]">Real-time parcel and payment status</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-[#888888] hover:text-white transition-colors cursor-pointer" aria-label="Close track modal">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 overscroll-contain" style={{ WebkitOverflowScrolling: 'touch' }}>
          {/* Reference Lookup Form */}
          <form onSubmit={handleSearch} className="flex gap-2">
            <input
              type="text"
              placeholder="Enter reference (e.g. LT-20261027-4821)"
              value={reference}
              onChange={e => setReference(e.target.value)}
              className="flex-1 bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] px-4 py-2.5 text-sm font-mono text-white focus:outline-none uppercase"
            />
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2.5 bg-[#D4AF37] hover:bg-[#F4D068] text-black font-bold text-xs uppercase tracking-wider transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              <span>Track</span>
            </button>
          </form>

          {/* Error Message */}
          {error && (
            <div className="p-4 bg-red-950/50 border border-red-800 text-red-200 text-xs flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Results Display */}
          {orderData && (
            <div className="space-y-6 pt-2">
              {/* Order Reference & Meta */}
              <div className="p-4 bg-[#141414] border border-[#242424] flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-[#888888] uppercase block">Order Reference</span>
                  <span className="font-mono font-bold text-white text-base">{orderData.reference}</span>
                </div>
                <div className="text-right">
                  <span className="text-[11px] text-[#888888] uppercase block">Payment Status</span>
                  <span className={`text-xs font-black uppercase px-2 py-0.5 inline-block ${
                    orderData.payment_status === 'paid'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : 'bg-amber-950 text-amber-300 border border-amber-800'
                  }`}>
                    {orderData.payment_status}
                  </span>
                </div>
              </div>

              {/* Status Timeline */}
              <div>
                <h4 className="text-xs uppercase font-bold tracking-widest text-[#D4AF37] mb-4">
                  Delivery Progress
                </h4>
                <div className="relative border-l-2 border-[#242424] ml-3 pl-6 space-y-6">
                  {statusSteps.map((step, idx) => {
                    const isDone = idx <= currentIndex;
                    const isCurrent = idx === currentIndex;
                    return (
                      <div key={step.key} className="relative">
                        <div className={`absolute -left-[31px] top-0 w-4 h-4 rounded-full border-2 ${
                          isDone
                            ? 'bg-[#D4AF37] border-[#D4AF37]'
                            : 'bg-[#141414] border-[#333333]'
                        }`} />
                        <div className="flex items-center justify-between">
                          <span className={`text-xs font-bold ${
                            isCurrent ? 'text-[#D4AF37]' : isDone ? 'text-white' : 'text-[#666666]'
                          }`}>
                            {step.label}
                          </span>
                          {isCurrent && (
                            <span className="text-[10px] text-[#D4AF37] bg-[#221c08] border border-[#D4AF37]/40 px-2 py-0.5">
                              Current Status
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Items in order */}
              <div className="space-y-2 pt-2 border-t border-[#1f1f1f]">
                <h4 className="text-xs uppercase font-bold tracking-widest text-[#888888] mb-2">
                  Items in Parcel
                </h4>
                {orderData.items.map((item: any, i: number) => (
                  <div key={i} className="flex justify-between items-center text-xs py-1.5 border-b border-[#1c1c1c]">
                    <div>
                      <span className="text-white font-medium">{item.product_name}</span>
                      <span className="text-[#777777] block text-[11px]">Qty: {item.quantity}</span>
                    </div>
                    <span className="text-[#D4AF37] font-semibold">₦{item.total_price.toLocaleString()}</span>
                  </div>
                ))}

                <div className="pt-2 text-xs flex justify-between text-[#888888]">
                  <span>Total Amount</span>
                  <span className="font-bold text-white text-sm">₦{orderData.total_amount.toLocaleString()}</span>
                </div>
              </div>

              {/* Bank Details Reminder if Unpaid */}
              {orderData.payment_status !== 'paid' && orderData.bank_details && (
                <div className="p-4 bg-[#141414] border border-[#2a2a2a] text-xs space-y-2">
                  <div className="flex items-center gap-1.5 font-bold text-white">
                    <Building2 className="w-4 h-4 text-[#D4AF37]" />
                    <span>Payment Pending Verification</span>
                  </div>
                  <p className="text-[#888888]">
                    Send transfer to: <strong>{orderData.bank_details.bank_name}</strong> | Acc: <strong className="text-[#D4AF37] font-mono">{orderData.bank_details.account_number}</strong> | Narration: <strong className="font-mono">{orderData.reference}</strong>
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
