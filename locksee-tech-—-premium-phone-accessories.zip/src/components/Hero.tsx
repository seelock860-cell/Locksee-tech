import React from 'react';
import { ArrowRight, ShieldCheck, Truck, Headphones, Zap } from 'lucide-react';

interface HeroProps {
  headline?: string;
  subheadline?: string;
  onShopNow: () => void;
  onExploreCategories: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  headline = 'Upgrade Your Tech. Elevate Your Lifestyle.',
  subheadline = 'Discover quality phone accessories, powerful gadgets, and everyday technology essentials at LOCKSEE TECH.',
  onShopNow,
  onExploreCategories
}) => {
  return (
    <section className="relative overflow-hidden bg-[#080808] border-b border-[#1f1f1f] pt-12 pb-16 lg:py-24">
      {/* Subtle gold radial background glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-[#D4AF37]/5 blur-[120px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Headlines & Call to Actions */}
          <div className="lg:col-span-7 space-y-8 text-center lg:text-left">
            {/* Tagline / Sub-badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#151515] border border-[#D4AF37]/40 text-[#D4AF37] text-xs font-semibold uppercase tracking-[0.2em]">
              <Zap className="w-3.5 h-3.5 fill-[#D4AF37]" />
              <span>Authentic Tech Accessories & Gadgets</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.12]">
              Upgrade Your Tech.{' '}
              <span className="block mt-1 gold-gradient-text">
                Elevate Your Lifestyle.
              </span>
            </h1>

            {/* Supporting Text */}
            <p className="text-lg sm:text-xl text-[#B8B8B8] max-w-2xl mx-auto lg:mx-0 font-normal leading-relaxed">
              {subheadline}
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={onShopNow}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 bg-gradient-to-r from-[#D4AF37] via-[#F4D068] to-[#AA820A] text-black font-bold text-sm tracking-widest uppercase hover:brightness-110 transition-all shadow-lg shadow-[#D4AF37]/20 group cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF37]"
              >
                <span>Shop Now</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onExploreCategories}
                className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-4 bg-[#151515] hover:bg-[#1c1c1c] text-white border border-[#2e2e2e] hover:border-[#D4AF37]/50 font-semibold text-sm tracking-widest uppercase transition-all cursor-pointer focus-visible:outline-none"
              >
                <span>Explore Products</span>
              </button>
            </div>

            {/* Trust highlights */}
            <div className="pt-6 border-t border-[#1a1a1a] grid grid-cols-3 gap-4 text-left">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-5 h-5 text-[#D4AF37] shrink-0" />
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">100% Genuine</h4>
                  <p className="text-[11px] text-[#777777]">Certified Original</p>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <Truck className="w-5 h-5 text-[#D4AF37] shrink-0" />
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">Nationwide</h4>
                  <p className="text-[11px] text-[#777777]">Fast dispatch</p>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <Headphones className="w-5 h-5 text-[#D4AF37] shrink-0" />
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">Support</h4>
                  <p className="text-[11px] text-[#777777]">Direct WhatsApp</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Outer decorative gold frame */}
              <div className="relative p-2 bg-[#121212] border border-[#2a2a2a] shadow-2xl">
                <div className="relative overflow-hidden aspect-square bg-[#0d0d0d]">
                  <img
                    src="https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=1000&q=80"
                    alt="LOCKSEE TECH Premium Accessories"
                    className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#080808] via-transparent to-transparent opacity-80" />

                  {/* Overlaid feature tag */}
                  <div className="absolute bottom-4 left-4 right-4 p-4 bg-[#0a0a0a]/90 backdrop-blur-md border border-[#D4AF37]/30 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest block">
                        Featured Technology
                      </span>
                      <h3 className="text-sm font-semibold text-white">
                        65W GaN Fast Chargers & MagSafe
                      </h3>
                    </div>
                    <span className="text-xs font-bold text-[#D4AF37] bg-[#1a1a1a] px-2.5 py-1 border border-[#D4AF37]/40">
                      In Stock
                    </span>
                  </div>
                </div>
              </div>

              {/* Decorative gold corner accents */}
              <div className="absolute -top-2 -left-2 w-6 h-6 border-t-2 border-l-2 border-[#D4AF37] pointer-events-none" />
              <div className="absolute -bottom-2 -right-2 w-6 h-6 border-b-2 border-r-2 border-[#D4AF37] pointer-events-none" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
