import React, { useState } from 'react';
import { Product } from '../types';
import { useCart } from '../context/CartContext';
import { X, ShoppingBag, Plus, Minus, Check, ShieldCheck, Truck, MessageCircle } from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  whatsappNumber: string;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  whatsappNumber
}) => {
  const { addToCart } = useCart();
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Lock body scroll when product detail modal is open (Hook must run unconditionally)
  React.useEffect(() => {
    if (product) {
      const prev = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = prev;
      };
    }
  }, [product]);

  if (!product) return null;

  const effectivePrice = product.discount_price || product.price;
  const isOutOfStock = product.stock <= 0;

  const handleAdd = () => {
    setErrorMsg(null);
    const result = addToCart(product, quantity);
    if (result.success) {
      setAdded(true);
      setTimeout(() => setAdded(false), 2000);
    } else {
      setErrorMsg(result.message || 'Cannot add requested quantity');
    }
  };

  // WhatsApp link for this product
  const cleanNumber = whatsappNumber.replace(/[^0-9]/g, '');
  const waProductMsg = `Hello LOCKSEE TECH, I am interested in purchasing: ${product.name} (SKU: ${product.sku}, Price: ₦${effectivePrice.toLocaleString()}). Is this item available for delivery?`;
  const waUrl = cleanNumber.startsWith('0')
    ? `https://wa.me/234${cleanNumber.substring(1)}?text=${encodeURIComponent(waProductMsg)}`
    : `https://wa.me/${cleanNumber}?text=${encodeURIComponent(waProductMsg)}`;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto overscroll-contain bg-black/85 backdrop-blur-md flex justify-center items-start sm:items-center p-2 sm:p-4 py-3 sm:py-6">
      <div onClick={onClose} className="fixed inset-0 bg-transparent" aria-hidden="true" />

      <div className="relative w-full max-w-3xl bg-[#0e0e0e] border border-[#2b2b2b] text-white shadow-2xl z-10 my-auto overflow-hidden max-h-[94vh] sm:max-h-[90vh] flex flex-col rounded-none">
        {/* Mobile top close bar */}
        <div className="shrink-0 flex items-center justify-between p-3 sm:p-4 border-b border-[#222222] bg-[#121212] z-20">
          <span className="text-xs uppercase font-bold tracking-widest text-[#D4AF37]">Product Details</span>
          <button
            onClick={onClose}
            className="p-1.5 text-[#888888] hover:text-white transition-colors cursor-pointer"
            aria-label="Close product view"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto overscroll-contain" style={{ WebkitOverflowScrolling: 'touch' }}>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Left: Images */}
          <div className="p-6 bg-[#0a0a0a] flex flex-col justify-between border-b md:border-b-0 md:border-r border-[#222222]">
            <div className="aspect-square bg-[#121212] border border-[#222222] overflow-hidden relative">
              <img
                src={product.images[selectedImageIndex] || product.images[0]}
                alt={product.name}
                className="w-full h-full object-cover"
              />

              {product.discount_price && (
                <span className="absolute top-3 left-3 bg-[#D4AF37] text-black font-extrabold text-[10px] px-2 py-0.5 uppercase tracking-wider">
                  Discounted
                </span>
              )}
            </div>

            {/* Gallery Thumbnails */}
            {product.images.length > 1 && (
              <div className="flex gap-2 mt-4 overflow-x-auto pb-1">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImageIndex(idx)}
                    className={`w-16 h-16 border shrink-0 overflow-hidden ${
                      selectedImageIndex === idx ? 'border-[#D4AF37]' : 'border-[#262626] opacity-60'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* Guarantees */}
            <div className="mt-6 pt-4 border-t border-[#1a1a1a] grid grid-cols-2 gap-3 text-left">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-[11px] text-[#888888]">100% Genuine Tech</span>
              </div>
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-[11px] text-[#888888]">Nationwide Courier</span>
              </div>
            </div>
          </div>

          {/* Right: Details & Purchase Controls */}
          <div className="p-6 md:p-8 flex flex-col justify-between space-y-6">
            <div>
              {/* Category & SKU */}
              <div className="flex items-center justify-between text-xs text-[#888888] mb-2">
                <span className="text-[#D4AF37] font-semibold uppercase tracking-wider">
                  {product.category_name}
                </span>
                <span className="font-mono text-[#777777]">SKU: {product.sku}</span>
              </div>

              {/* Title */}
              <h2 className="text-xl sm:text-2xl font-bold font-display text-white mb-3">
                {product.name}
              </h2>

              {/* Price */}
              <div className="flex items-baseline gap-3 mb-4">
                <span className="text-2xl font-black text-white">
                  ₦{effectivePrice.toLocaleString()}
                </span>
                {product.discount_price && (
                  <span className="text-sm text-[#777777] line-through">
                    ₦{product.price.toLocaleString()}
                  </span>
                )}
              </div>

              {/* Stock Status Indicator */}
              <div className="mb-4">
                {isOutOfStock ? (
                  <span className="text-xs font-bold uppercase tracking-wider text-red-400 bg-red-950/40 px-2 py-1 border border-red-800/40">
                    Out of Stock
                  </span>
                ) : (
                  <span className="text-xs font-semibold text-[#888888]">
                    Availability:{' '}
                    <strong className="text-emerald-400">
                      In Stock ({product.stock} units ready for delivery)
                    </strong>
                  </span>
                )}
              </div>

              {/* Description */}
              <p className="text-xs text-[#B8B8B8] leading-relaxed mb-4">
                {product.description}
              </p>

              {/* Technical Specifications */}
              {product.specs && Object.keys(product.specs).length > 0 && (
                <div className="space-y-1.5 pt-3 border-t border-[#1f1f1f]">
                  <h4 className="text-[11px] uppercase font-bold tracking-wider text-[#D4AF37]">
                    Technical Specifications
                  </h4>
                  <div className="divide-y divide-[#1c1c1c] text-xs">
                    {Object.entries(product.specs).map(([key, val]) => (
                      <div key={key} className="py-1.5 flex justify-between gap-4">
                        <span className="text-[#777777]">{key}</span>
                        <span className="text-white font-medium text-right">{val}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Action Bar */}
            <div className="space-y-3 pt-4 border-t border-[#1f1f1f]">
              {errorMsg && (
                <div className="text-xs text-red-400 leading-tight">
                  {errorMsg}
                </div>
              )}

              <div className="flex items-center gap-3">
                {/* Quantity */}
                {!isOutOfStock && (
                  <div className="flex items-center border border-[#2e2e2e] bg-[#121212]">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="p-2 text-[#888888] hover:text-white"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-10 text-center font-mono font-bold text-sm text-white">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                      disabled={quantity >= product.stock}
                      className="p-2 text-[#888888] hover:text-white disabled:opacity-40"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                {/* Add to Cart Button */}
                <button
                  onClick={handleAdd}
                  disabled={isOutOfStock}
                  className={`flex-1 py-3 px-6 text-xs uppercase font-extrabold tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    isOutOfStock
                      ? 'bg-[#1a1a1a] text-[#555555] cursor-not-allowed border border-[#262626]'
                      : added
                      ? 'bg-[#18392b] text-[#25D366] border border-[#25D366]/50'
                      : 'bg-gradient-to-r from-[#D4AF37] via-[#F4D068] to-[#AA820A] text-black hover:brightness-110 shadow-md'
                  }`}
                >
                  {isOutOfStock ? (
                    <span>Sold Out</span>
                  ) : added ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Added to Cart</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4" />
                      <span>Add to Cart (₦{(effectivePrice * quantity).toLocaleString()})</span>
                    </>
                  )}
                </button>
              </div>

              {/* WhatsApp direct order */}
              <a
                href={waUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 bg-[#141414] hover:bg-[#1a1a1a] text-[#25D366] border border-[#25D366]/40 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Ask about this on WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>
  );
};
