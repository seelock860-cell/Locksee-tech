import React, { useState } from 'react';
import { Order } from '../types';
import { CheckCircle2, Copy, Check, Building2, MessageCircle, ArrowRight, X } from 'lucide-react';

interface OrderConfirmationModalProps {
  order: Order | null;
  bankDetails: any;
  onClose: () => void;
  onTrackOrder: (ref: string) => void;
  whatsappNumber: string;
}

export const OrderConfirmationModal: React.FC<OrderConfirmationModalProps> = ({
  order,
  bankDetails,
  onClose,
  onTrackOrder,
  whatsappNumber
}) => {
  const [copied, setCopied] = useState(false);
  const [accountCopied, setAccountCopied] = useState(false);

  // Lock body scroll when order confirmation is open (Hook must run on every render)
  React.useEffect(() => {
    if (order) {
      const prev = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = prev;
      };
    }
  }, [order]);

  if (!order) return null;

  const copyRef = () => {
    navigator.clipboard.writeText(order.reference);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const copyAccount = () => {
    if (bankDetails?.account_number) {
      navigator.clipboard.writeText(bankDetails.account_number);
      setAccountCopied(true);
      setTimeout(() => setAccountCopied(false), 2000);
    }
  };

  // WhatsApp order link
  const cleanNumber = whatsappNumber.replace(/[^0-9]/g, '');
  const waMessage = `Hello LOCKSEE TECH, I just completed order ${order.reference} for ₦${order.total_amount.toLocaleString()}.\n\nCustomer: ${order.customer_name}\nPhone: ${order.customer_phone}\nDelivery: ${order.delivery_address}, ${order.city}, ${order.state}.\n\nPlease find my order confirmation and advise on delivery.`;
  const waUrl = cleanNumber.startsWith('0')
    ? `https://wa.me/234${cleanNumber.substring(1)}?text=${encodeURIComponent(waMessage)}`
    : `https://wa.me/${cleanNumber}?text=${encodeURIComponent(waMessage)}`;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto overscroll-contain bg-black/90 backdrop-blur-md flex justify-center items-start sm:items-center p-2 sm:p-4 py-3 sm:py-6">
      <div onClick={onClose} className="fixed inset-0 bg-transparent" aria-hidden="true" />

      <div className="relative w-full max-w-2xl bg-[#0e0e0e] border border-[#D4AF37]/40 text-white shadow-2xl z-10 flex flex-col max-h-[94vh] sm:max-h-[90vh] overflow-hidden my-auto rounded-none">
        {/* Top Celebration Header - Pinned */}
        <div className="shrink-0 p-4 sm:p-5 bg-gradient-to-r from-[#171717] via-[#241f12] to-[#171717] border-b border-[#2d281a] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-[#D4AF37]/10 border border-[#D4AF37] flex items-center justify-center text-[#D4AF37] shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold font-display text-white leading-tight">Order Successfully Placed!</h2>
              <span className="text-[11px] text-[#B8B8B8]">Thank you for choosing LOCKSEE TECH</span>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-[#888888] hover:text-white transition-colors cursor-pointer" aria-label="Close modal">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 overscroll-contain" style={{ WebkitOverflowScrolling: 'touch' }}>
          {/* Order Reference Box */}
          <div className="p-4 bg-[#141414] border border-[#2a2a2a] flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <span className="text-[11px] uppercase tracking-wider text-[#888888] block">
                Your Unique Order Reference:
              </span>
              <span className="text-xl font-mono font-black text-[#D4AF37]">
                {order.reference}
              </span>
            </div>
            <button
              onClick={copyRef}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#1f1f1f] hover:bg-[#2a2a2a] text-xs font-semibold text-white border border-[#333333] transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#25D366]" />
                  <span>Copied Reference</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Reference</span>
                </>
              )}
            </button>
          </div>

          {/* Payment Status Notice */}
          <div className="p-4 bg-[#181818] border-l-4 border-[#D4AF37] space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase font-bold tracking-wider text-[#D4AF37]">
                Payment Status: {order.payment_status.toUpperCase()}
              </span>
              <span className="text-xs uppercase font-bold text-[#888888]">
                Order Status: {order.order_status.toUpperCase()}
              </span>
            </div>

            {order.payment_method === 'bank_transfer' && (
              <p className="text-xs text-[#BBBBBB] leading-relaxed">
                As per standard verification policy, your order remains in <strong>unpaid/pending</strong> state until your bank transfer is verified by our accounting desk.
              </p>
            )}
          </div>

          {/* Bank Transfer Details Box (if bank transfer or pending) */}
          {order.payment_method === 'bank_transfer' && bankDetails && (
            <div className="p-5 bg-[#121212] border border-[#2e2e2e] space-y-3">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Building2 className="w-4 h-4 text-[#D4AF37]" />
                <span>Bank Transfer Instructions</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-2 border-t border-[#1f1f1f]">
                <div>
                  <span className="text-[#888888] block">Bank Name</span>
                  <span className="font-semibold text-white">{bankDetails.bank_name || 'Guaranty Trust Bank (GTBank)'}</span>
                </div>
                <div>
                  <span className="text-[#888888] block">Account Number</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-base text-[#D4AF37]">{bankDetails.account_number || '0123456789'}</span>
                    <button onClick={copyAccount} className="text-[#888888] hover:text-white p-1" title="Copy account number">
                      {accountCopied ? <Check className="w-3.5 h-3.5 text-[#25D366]" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
                <div>
                  <span className="text-[#888888] block">Account Name</span>
                  <span className="font-semibold text-white">{bankDetails.account_name || 'LOCKSEE TECH ENTERPRISES'}</span>
                </div>
                <div>
                  <span className="text-[#888888] block">Payment Narration / Memo</span>
                  <span className="font-mono font-bold text-white bg-[#1a1a1a] px-1.5 py-0.5 border border-[#333333] inline-block">{order.reference}</span>
                </div>
              </div>

              <p className="text-[11px] text-[#999999] pt-2 border-t border-[#1f1f1f]">
                {bankDetails.instructions || 'Please transfer the exact amount and quote your order reference as the transaction remarks.'}
              </p>
            </div>
          )}


          {/* Ordered Items Summary */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase font-bold tracking-widest text-[#888888]">
              Ordered Items ({order.items.length})
            </h4>
            <div className="space-y-2">
              {order.items.map((item, idx) => (
                <div key={idx} className="flex justify-between items-center text-xs py-2 border-b border-[#1f1f1f]">
                  <div>
                    <span className="font-bold text-white">{item.product_name}</span>
                    <span className="text-[#888888] block">Qty: {item.quantity} × ₦{item.unit_price.toLocaleString()}</span>
                  </div>
                  <span className="font-bold text-[#D4AF37]">₦{item.total_price.toLocaleString()}</span>
                </div>
              ))}
            </div>

            <div className="pt-2 text-xs space-y-1 text-right">
              <div className="text-[#888888]">Subtotal: ₦{order.subtotal.toLocaleString()}</div>
              <div className="text-[#888888]">Delivery Fee ({order.state}): ₦{order.delivery_fee.toLocaleString()}</div>
              <div className="text-sm font-bold text-white pt-1">
                Total: <span className="text-[#D4AF37] text-base font-black">₦{order.total_amount.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Next Action Links */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-4 border-t border-[#222222]">
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="py-3 px-4 bg-[#181818] hover:bg-[#202020] text-[#25D366] border border-[#25D366]/40 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Notify Sales on WhatsApp</span>
            </a>

            <button
              onClick={() => {
                onClose();
                onTrackOrder(order.reference);
              }}
              className="py-3 px-4 bg-[#1f1f1f] hover:bg-[#D4AF37] text-white hover:text-black border border-[#333333] hover:border-[#D4AF37] text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-colors"
            >
              <span>Track This Order</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
