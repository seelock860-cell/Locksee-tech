import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';

interface FloatingWhatsAppProps {
  whatsappNumber: string;
}

export const FloatingWhatsApp: React.FC<FloatingWhatsAppProps> = ({ whatsappNumber }) => {
  const [showTooltip, setShowTooltip] = useState(false);

  const cleanNumber = whatsappNumber.replace(/[^0-9]/g, '');
  const formattedNumber = cleanNumber.startsWith('0') ? `234${cleanNumber.substring(1)}` : cleanNumber;

  const defaultMessage = 'Hello LOCKSEE TECH! I am browsing your online store and have a question about phone accessories.';
  const waUrl = `https://wa.me/${formattedNumber}?text=${encodeURIComponent(defaultMessage)}`;

  return (
    <div className="fixed bottom-6 right-6 z-40 flex items-end gap-3">
      {/* Tooltip speech bubble */}
      {showTooltip && (
        <div className="bg-[#121212] border border-[#25D366]/40 p-3.5 shadow-2xl text-white max-w-xs relative animate-fade-in">
          <div className="flex items-start justify-between gap-2 mb-1">
            <span className="text-xs font-bold text-[#25D366]">Chat with LOCKSEE TECH</span>
            <button
              onClick={() => setShowTooltip(false)}
              className="text-[#777777] hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <p className="text-[11px] text-[#B8B8B8] leading-tight mb-2.5">
            Need advice on fast chargers, MagSafe cases, or urgent delivery in Nigeria? Tap below to chat instantly.
          </p>
          <a
            href={waUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block w-full py-1.5 px-3 bg-[#25D366] hover:bg-[#20ba59] text-black text-center text-xs font-bold tracking-wide transition-colors"
          >
            Start WhatsApp Chat
          </a>
        </div>
      )}

      {/* Floating Button */}
      <a
        href={waUrl}
        target="_blank"
        rel="noopener noreferrer"
        onMouseEnter={() => setShowTooltip(true)}
        className="w-14 h-14 bg-[#25D366] hover:bg-[#20ba59] text-black flex items-center justify-center shadow-xl hover:scale-108 transition-all relative group"
        aria-label="Chat on WhatsApp"
        title="Chat on WhatsApp (09024971419)"
      >
        <MessageCircle className="w-7 h-7 text-black fill-black" />
        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-[#D4AF37] border-2 border-[#080808] rounded-full animate-ping" />
        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-[#D4AF37] border-2 border-[#080808] rounded-full" />
      </a>
    </div>
  );
};
