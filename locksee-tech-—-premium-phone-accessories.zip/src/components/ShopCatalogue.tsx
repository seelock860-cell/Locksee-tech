import React, { useState, useMemo } from 'react';
import { Product, Category } from '../types';
import { ProductCard } from './ProductCard';
import { Search, SlidersHorizontal, ArrowUpDown, X, PackageX } from 'lucide-react';

interface ShopCatalogueProps {
  products: Product[];
  categories: Category[];
  selectedCategoryId: string;
  onSelectCategory: (catId: string) => void;
  onQuickView: (product: Product) => void;
  initialSearch?: string;
}

export const ShopCatalogue: React.FC<ShopCatalogueProps> = ({
  products,
  categories,
  selectedCategoryId,
  onSelectCategory,
  onQuickView,
  initialSearch = ''
}) => {
  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [sortBy, setSortBy] = useState<'newest' | 'price_asc' | 'price_desc' | 'rating'>('newest');
  const [availabilityFilter, setAvailabilityFilter] = useState<'all' | 'in_stock'>('all');
  const [maxPrice, setMaxPrice] = useState<number>(1200000);

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      // Category filter
      if (selectedCategoryId !== 'all' && p.category_id !== selectedCategoryId) {
        return false;
      }

      // Availability filter
      if (availabilityFilter === 'in_stock' && p.stock <= 0) {
        return false;
      }

      // Max price filter
      const effectivePrice = p.discount_price || p.price;
      if (effectivePrice > maxPrice) {
        return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = p.name.toLowerCase().includes(q);
        const matchesDesc = p.description.toLowerCase().includes(q);
        const matchesSku = p.sku.toLowerCase().includes(q);
        const matchesCat = p.category_name.toLowerCase().includes(q);
        if (!matchesName && !matchesDesc && !matchesSku && !matchesCat) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      const priceA = a.discount_price || a.price;
      const priceB = b.discount_price || b.price;

      if (sortBy === 'price_asc') return priceA - priceB;
      if (sortBy === 'price_desc') return priceB - priceA;
      if (sortBy === 'rating') return (b.rating || 0) - (a.rating || 0);
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    });
  }, [products, selectedCategoryId, availabilityFilter, maxPrice, searchQuery, sortBy]);

  return (
    <div className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Header & Breadcrumb */}
      <div className="border-b border-[#202020] pb-6 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <span className="text-xs uppercase font-bold tracking-[0.25em] text-[#D4AF37] block mb-1">
            Genuine Accessories
          </span>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-white tracking-wide">
            Product Catalogue
          </h1>
        </div>
        <div className="text-xs text-[#888888]">
          Showing <span className="font-bold text-white">{filteredProducts.length}</span> of {products.length} products
        </div>
      </div>

      {/* Filter and Control Bar */}
      <div className="bg-[#101010] border border-[#222222] p-4 sm:p-5 mb-8 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-[#777777] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search accessories or SKU..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] pl-9 pr-8 py-2 text-xs text-white focus:outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#777777] hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category Dropdown */}
          <div>
            <select
              value={selectedCategoryId}
              onChange={e => onSelectCategory(e.target.value)}
              className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] px-3 py-2 text-xs text-white focus:outline-none"
            >
              <option value="all">All Categories</option>
              {categories.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Sort By Dropdown */}
          <div className="flex items-center gap-2">
            <ArrowUpDown className="w-4 h-4 text-[#777777] shrink-0" />
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] px-3 py-2 text-xs text-white focus:outline-none"
            >
              <option value="newest">Newest Products</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="rating">Highest Rated</option>
            </select>
          </div>

          {/* Stock Availability Filter */}
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-[#777777] shrink-0" />
            <select
              value={availabilityFilter}
              onChange={e => setAvailabilityFilter(e.target.value as any)}
              className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] px-3 py-2 text-xs text-white focus:outline-none"
            >
              <option value="all">All Availability</option>
              <option value="in_stock">In Stock Only</option>
            </select>
          </div>
        </div>

        {/* Active Filters Pill Bar */}
        {(selectedCategoryId !== 'all' || searchQuery || availabilityFilter !== 'all') && (
          <div className="pt-3 border-t border-[#1a1a1a] flex flex-wrap items-center gap-2 text-xs">
            <span className="text-[#777777]">Active filters:</span>
            {selectedCategoryId !== 'all' && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-[#1a1a1a] border border-[#333333] text-white">
                Category: {categories.find(c => c.id === selectedCategoryId)?.name || selectedCategoryId}
                <button onClick={() => onSelectCategory('all')} className="hover:text-[#D4AF37]">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
            {searchQuery && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-[#1a1a1a] border border-[#333333] text-white">
                Query: "{searchQuery}"
                <button onClick={() => setSearchQuery('')} className="hover:text-[#D4AF37]">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
            {availabilityFilter === 'in_stock' && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-[#1a1a1a] border border-[#333333] text-white">
                In Stock Only
                <button onClick={() => setAvailabilityFilter('all')} className="hover:text-[#D4AF37]">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
            <button
              onClick={() => {
                onSelectCategory('all');
                setSearchQuery('');
                setAvailabilityFilter('all');
              }}
              className="text-[#D4AF37] hover:underline text-xs ml-2"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {/* Product Grid or Professional Empty State */}
      {filteredProducts.length === 0 ? (
        <div className="py-20 text-center bg-[#101010] border border-[#202020] p-8 max-w-xl mx-auto space-y-4">
          <div className="w-16 h-16 bg-[#161616] border border-[#2a2a2a] mx-auto flex items-center justify-center text-[#555555]">
            <PackageX className="w-8 h-8 text-[#888888]" />
          </div>
          <h3 className="font-display text-xl font-bold text-white">
            No Accessories Match Your Selection
          </h3>
          <p className="text-xs text-[#888888] leading-relaxed">
            We couldn't find any products matching your specific search or filter criteria. Try resetting filters or searching for alternative accessories like chargers, power banks, or MagSafe cases.
          </p>
          <button
            onClick={() => {
              onSelectCategory('all');
              setSearchQuery('');
              setAvailabilityFilter('all');
            }}
            className="px-6 py-2.5 bg-[#D4AF37] hover:bg-[#F4D068] text-black font-bold text-xs uppercase tracking-wider transition-all inline-block"
          >
            View All Products
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              onQuickView={onQuickView}
            />
          ))}
        </div>
      )}
    </div>
  );
};
