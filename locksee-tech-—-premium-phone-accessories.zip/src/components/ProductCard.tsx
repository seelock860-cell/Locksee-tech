import React, { useState } from 'react';
import { Product } from '../types';
import { useCart } from '../context/CartContext';
import { ShoppingBag, Eye, Star, Check } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onQuickView: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView }) => {
  const { addToCart } = useCart();
  const [added, setAdded] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const effectivePrice = product.discount_price || product.price;
  const isOutOfStock = product.stock <= 0;
  const isLowStock = product.stock > 0 && product.stock <= 5;

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    setErrorMessage(null);
    const result = addToCart(product, 1);
    if (result.success) {
      setAdded(true);
      setTimeout(() => setAdded(false), 2000);
    } else {
      setErrorMessage(result.message || 'Failed to add item');
      setTimeout(() => setErrorMessage(null), 3000);
    }
  };

  return (
    <div
      onClick={() => onQuickView(product)}
      className="group bg-[#121212] border border-[#222222] hover:border-[#D4AF37]/50 transition-all duration-300 flex flex-col justify-between overflow-hidden cursor-pointer"
    >
      {/* Image Container */}
      <div className="relative aspect-square bg-[#0a0a0a] overflow-hidden">
        <img
          src={product.images[0] || 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=600&q=80'}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-106 transition-transform duration-500"
          loading="lazy"
        />

        {/* Stock / Discount Overlay */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 items-start">
          {product.discount_price && (
            <span className="text-[10px] font-black uppercase tracking-wider bg-[#D4AF37] text-black px-2 py-0.5 shadow-sm">
              SAVE ₦{(product.price - product.discount_price).toLocaleString()}
            </span>
          )}

          {isOutOfStock ? (
            <span className="text-[10px] font-bold uppercase tracking-wider bg-red-950/90 text-red-400 border border-red-800/60 px-2 py-0.5">
              Out of Stock
            </span>
          ) : isLowStock ? (
            <span className="text-[10px] font-bold uppercase tracking-wider bg-amber-950/90 text-amber-300 border border-amber-800/60 px-2 py-0.5">
              Only {product.stock} Left
            </span>
          ) : null}
        </div>

        {/* Quick View Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onQuickView(product);
          }}
          className="absolute bottom-3 right-3 p-2 bg-[#080808]/80 hover:bg-[#D4AF37] text-white hover:text-black border border-white/10 hover:border-transparent opacity-0 group-hover:opacity-100 transition-all duration-200"
          title="Quick view product specs"
        >
          <Eye className="w-4 h-4" />
        </button>
      </div>

      {/* Product Content */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Category & SKU */}
          <div className="flex items-center justify-between text-[11px] text-[#777777] mb-1.5">
            <span className="uppercase tracking-wider font-semibold text-[#D4AF37]/90">{product.category_name}</span>
            <span className="font-mono">{product.sku}</span>
          </div>

          {/* Product Name */}
          <h3 className="text-sm font-bold text-white group-hover:text-[#D4AF37] transition-colors line-clamp-2 leading-snug">
            {product.name}
          </h3>

          {/* Rating (only when supported by genuine reviews) */}
          {product.rating && product.review_count && product.review_count > 0 ? (
            <div className="flex items-center gap-1.5 mt-2">
              <div className="flex text-[#D4AF37]">
                <Star className="w-3.5 h-3.5 fill-[#D4AF37]" />
              </div>
              <span className="text-xs font-semibold text-white">{product.rating.toFixed(1)}</span>
              <span className="text-[11px] text-[#777777]">({product.review_count})</span>
            </div>
          ) : (
            <div className="mt-2 text-[11px] text-[#666666]">Genuine Verified Item</div>
          )}
        </div>

        {/* Price & Add to Cart */}
        <div className="mt-4 pt-4 border-t border-[#1c1c1c]">
          <div className="flex items-baseline gap-2 mb-3">
            <span className="text-base sm:text-lg font-black text-white">
              ₦{effectivePrice.toLocaleString()}
            </span>
            {product.discount_price && (
              <span className="text-xs text-[#777777] line-through">
                ₦{product.price.toLocaleString()}
              </span>
            )}
          </div>

          {/* Error Message if stock exceeded */}
          {errorMessage && (
            <div className="text-[11px] text-red-400 mb-2 leading-tight">
              {errorMessage}
            </div>
          )}

          {/* Action Button */}
          <button
            onClick={handleAdd}
            disabled={isOutOfStock}
            className={`w-full py-2.5 px-4 text-xs uppercase tracking-wider font-bold transition-all flex items-center justify-center gap-2 ${
              isOutOfStock
                ? 'bg-[#1a1a1a] text-[#555555] border border-[#222222] cursor-not-allowed'
                : added
                ? 'bg-[#18392b] text-[#25D366] border border-[#25D366]/40'
                : 'bg-[#1a1a1a] hover:bg-[#D4AF37] text-white hover:text-black border border-[#333333] hover:border-[#D4AF37]'
            }`}
          >
            {isOutOfStock ? (
              <span>Out of Stock</span>
            ) : added ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Added to Cart</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Add to Cart</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
