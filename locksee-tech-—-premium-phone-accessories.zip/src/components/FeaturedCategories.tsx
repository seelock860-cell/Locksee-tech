import React from 'react';
import { Category } from '../types';
import { ArrowUpRight } from 'lucide-react';

interface FeaturedCategoriesProps {
  categories: Category[];
  onSelectCategory: (categoryId: string) => void;
}

export const FeaturedCategories: React.FC<FeaturedCategoriesProps> = ({
  categories,
  onSelectCategory
}) => {
  return (
    <section className="py-16 sm:py-20 bg-[#0d0d0d] border-b border-[#1f1f1f]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-[#222222] gap-4">
          <div>
            <span className="text-xs uppercase font-bold tracking-[0.25em] text-[#D4AF37] block mb-2">
              Curated Collections
            </span>
            <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-wide">
              Featured Categories
            </h2>
          </div>
          <p className="text-sm text-[#888888] max-w-md">
            Explore authentic accessories engineered for peak performance, extreme device durability, and elegant daily use.
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {categories.map((cat) => (
            <div
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className="group relative bg-[#141414] border border-[#242424] hover:border-[#D4AF37]/60 transition-all duration-300 overflow-hidden cursor-pointer flex flex-col justify-between"
            >
              {/* Category Image */}
              <div className="relative aspect-[4/3] overflow-hidden bg-[#0a0a0a]">
                <img
                  src={cat.image_url || 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=600&q=80'}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500 opacity-85 group-hover:opacity-100"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-transparent to-transparent opacity-90" />
              </div>

              {/* Category Info */}
              <div className="p-4 sm:p-5 flex items-end justify-between gap-2 border-t border-[#1f1f1f]">
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-[#D4AF37] transition-colors leading-snug">
                    {cat.name}
                  </h3>
                  <span className="text-[11px] text-[#777777] font-medium block mt-1">
                    {cat.item_count !== undefined ? `${cat.item_count} items available` : 'View accessories'}
                  </span>
                </div>

                <div className="w-7 h-7 shrink-0 rounded-none bg-[#1d1d1d] group-hover:bg-[#D4AF37] text-[#888888] group-hover:text-black flex items-center justify-center transition-all">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>

              {/* Bottom Subtle Gold Accent Bar */}
              <div className="h-[2px] w-0 group-hover:w-full bg-[#D4AF37] transition-all duration-300" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
