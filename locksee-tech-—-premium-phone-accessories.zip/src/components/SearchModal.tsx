import React, { useState, useMemo } from 'react';
import { Product } from '../types';
import { Search, X, ArrowRight } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onSelectProduct: (product: Product) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  products,
  onSelectProduct
}) => {
  const [query, setQuery] = useState('');

  const searchResults = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase().trim();
    return products.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q) ||
      p.sku.toLowerCase().includes(q) ||
      p.category_name.toLowerCase().includes(q)
    ).slice(0, 8);
  }, [query, products]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 sm:pt-20 overflow-y-auto">
      <div onClick={onClose} className="fixed inset-0 bg-black/85 backdrop-blur-sm" />

      <div className="relative w-full max-w-2xl bg-[#101010] border border-[#2b2b2b] text-white shadow-2xl z-10 overflow-hidden">
        {/* Search Input Bar */}
        <div className="p-4 sm:p-5 border-b border-[#222222] flex items-center gap-3 bg-[#141414]">
          <Search className="w-5 h-5 text-[#D4AF37] shrink-0" />
          <input
            type="text"
            autoFocus
            placeholder="Search chargers, power banks, cases, or SKU..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-sm sm:text-base text-white placeholder-[#777777] focus:outline-none"
          />
          {query && (
            <button onClick={() => setQuery('')} className="text-[#888888] hover:text-white p-1">
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs uppercase font-bold text-[#888888] hover:text-[#D4AF37] px-2 py-1"
          >
            Esc
          </button>
        </div>

        {/* Results */}
        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-2">
          {query.trim() && searchResults.length === 0 ? (
            <div className="py-12 text-center text-xs text-[#888888]">
              No accessories found matching "<span className="text-white font-medium">{query}</span>"
            </div>
          ) : !query.trim() ? (
            <div className="py-8 text-center text-xs text-[#777777]">
              Type product name, category (e.g. "Chargers", "Cases"), or brand (Anker, Oraimo, Baseus)
            </div>
          ) : (
            searchResults.map(p => (
              <div
                key={p.id}
                onClick={() => {
                  onSelectProduct(p);
                  onClose();
                }}
                className="p-3 bg-[#151515] hover:bg-[#1f1f1f] border border-[#242424] hover:border-[#D4AF37]/50 flex items-center justify-between gap-3 cursor-pointer transition-all"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 bg-[#0a0a0a] border border-[#222222] shrink-0 overflow-hidden">
                    <img src={p.images[0]} alt="" className="w-full h-full object-cover" />
                  </div>
                  <div className="min-w-0">
                    <span className="text-[10px] text-[#D4AF37] uppercase font-semibold block">{p.category_name}</span>
                    <h4 className="text-xs font-bold text-white truncate">{p.name}</h4>
                    <span className="text-[11px] text-[#777777] font-mono">SKU: {p.sku}</span>
                  </div>
                </div>

                <div className="text-right shrink-0 flex items-center gap-3">
                  <div>
                    <span className="text-xs font-bold text-white">
                      ₦{(p.discount_price || p.price).toLocaleString()}
                    </span>
                    <span className="block text-[10px] text-emerald-400">
                      {p.stock > 0 ? `${p.stock} in stock` : 'Out of stock'}
                    </span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-[#888888]" />
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
