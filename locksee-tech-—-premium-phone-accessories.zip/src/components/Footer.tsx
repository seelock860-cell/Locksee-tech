import React from 'react';
import { ShieldCheck, MessageCircle, Mail, MapPin, Phone, ArrowUpRight } from 'lucide-react';
import { Category } from '../types';

interface FooterProps {
  categories: Category[];
  onSelectCategory: (catId: string) => void;
  onNavigate: (view: string) => void;
  whatsappNumber: string;
}

export const Footer: React.FC<FooterProps> = ({
  categories,
  onSelectCategory,
  onNavigate,
  whatsappNumber
}) => {
  const cleanNumber = whatsappNumber.replace(/[^0-9]/g, '');
  const waUrl = cleanNumber.startsWith('0') ? `https://wa.me/234${cleanNumber.substring(1)}` : `https://wa.me/${cleanNumber}`;

  return (
    <footer className="bg-[#050505] border-t border-[#1a1a1a] text-[#888888] text-xs">
      {/* Upper Newsletter & Brand Ribbon */}
      <div className="border-b border-[#141414] py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            <div className="md:col-span-6 space-y-2">
              <span className="font-display font-bold text-2xl tracking-[0.2em] text-white block">
                LOCKSEE<span className="text-[#D4AF37]"> TECH</span>
              </span>
              <p className="text-sm text-[#999999] max-w-md">
                Nigeria's premier destination for genuine, high-performance smartphone accessories, certified GaN chargers, rugged cases, and premium lifestyle audio.
              </p>
            </div>
            <div className="md:col-span-6 flex flex-col sm:flex-row items-center justify-start md:justify-end gap-4">
              <a
                href={waUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#151515] hover:bg-[#202020] border border-[#25D366]/40 text-white font-bold text-xs uppercase tracking-wider transition-all"
              >
                <MessageCircle className="w-4 h-4 text-[#25D366]" />
                <span>WhatsApp Desk (09024971419)</span>
              </a>
              <button
                onClick={() => onNavigate('shop')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#D4AF37] hover:bg-[#F4D068] text-black font-extrabold text-xs uppercase tracking-widest transition-all"
              >
                <span>Browse Store</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Links Grid */}
      <div className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
            {/* Column 1: Categories */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-widest text-white border-b border-[#1c1c1c] pb-2">
                Top Categories
              </h4>
              <ul className="space-y-2">
                {categories.slice(0, 6).map((cat) => (
                  <li key={cat.id}>
                    <button
                      onClick={() => onSelectCategory(cat.id)}
                      className="hover:text-[#D4AF37] transition-colors text-left"
                    >
                      {cat.name}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Column 2: Customer Care & Policies */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-widest text-white border-b border-[#1c1c1c] pb-2">
                Customer Care & Policy
              </h4>
              <ul className="space-y-2">
                <li>
                  <button onClick={() => onNavigate('delivery-info')} className="hover:text-[#D4AF37] transition-colors">
                    Delivery Information (Lagos & 36 States)
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavigate('return-policy')} className="hover:text-[#D4AF37] transition-colors">
                    7-Day Warranty & Return Policy
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavigate('privacy-policy')} className="hover:text-[#D4AF37] transition-colors">
                    Privacy Policy & Data Protection
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavigate('terms')} className="hover:text-[#D4AF37] transition-colors">
                    Terms & Conditions
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavigate('track')} className="hover:text-[#D4AF37] transition-colors text-[#D4AF37] font-semibold">
                    Track Existing Order
                  </button>
                </li>
              </ul>
            </div>

            {/* Column 3: Contact Details */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-widest text-white border-b border-[#1c1c1c] pb-2">
                Contact & Showroom
              </h4>
              <div className="space-y-2.5">
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                  <span>Suite 4B, Tech Hub Plaza, Computer Village, Ikeja, Lagos, Nigeria</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Phone className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>+234 902 497 1419</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <MessageCircle className="w-4 h-4 text-[#25D366] shrink-0" />
                  <span>09024971419 (WhatsApp Direct)</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Mail className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>support@lockseetech.com</span>
                </div>
              </div>
            </div>

            {/* Column 4: Payment & Security */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-widest text-white border-b border-[#1c1c1c] pb-2">
                Payment Security
              </h4>
              <p className="text-xs text-[#999999] leading-relaxed">
                We accept direct bank transfers to our verified corporate GTBank account and WhatsApp orders with prompt accounting confirmation.
              </p>
              <div className="p-3 bg-[#111111] border border-[#222222] space-y-1">
                <div className="flex items-center gap-2 text-white font-semibold text-[11px]">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Verified GTBank Corporate Desk</span>
                </div>
                <p className="text-[10px] text-[#777777]">
                  All transfers are verified before packaging and dispatch.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Copyright */}
      <div className="border-t border-[#121212] py-6 bg-[#040404]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px]">
          <p>© {new Date().getFullYear()} LOCKSEE TECH ENTERPRISES. All Rights Reserved.</p>
          <p className="text-[#666666]">
            Built with modern high-performance full-stack architecture & Supabase PostgreSQL.
          </p>
        </div>
      </div>
    </footer>
  );
};
