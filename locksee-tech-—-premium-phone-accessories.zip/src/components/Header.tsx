import React, { useState } from 'react';
import {
  ShoppingBag,
  Search,
  Menu,
  X,
  Phone,
  Compass,
  MessageCircle,
  PackageCheck
} from 'lucide-react';
import { useCart } from '../context/CartContext';

interface HeaderProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  whatsappNumber: string;
  businessName: string;
  onOpenSearch: () => void;
  onOpenTrackOrder: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  setCurrentView,
  whatsappNumber,
  businessName,
  onOpenSearch,
  onOpenTrackOrder
}) => {
  const { totalItems, toggleCart } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const cleanWhatsAppNumber = whatsappNumber.replace(/[^0-9]/g, '');
  const formattedWhatsAppUrl = cleanWhatsAppNumber.startsWith('0')
    ? `https://wa.me/234${cleanWhatsAppNumber.substring(1)}?text=${encodeURIComponent('Hello LOCKSEE TECH, I am visiting your store and would like to make an inquiry.')}`
    : `https://wa.me/${cleanWhatsAppNumber}?text=${encodeURIComponent('Hello LOCKSEE TECH, I am visiting your store and would like to make an inquiry.')}`;

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'shop', label: 'Shop' },
    { id: 'categories', label: 'Categories' },
    { id: 'about', label: 'About Us' },
    { id: 'contact', label: 'Contact' }
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#080808]/95 backdrop-blur-md border-b border-[#222222]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Brand Logo */}
          <button
            onClick={() => {
              setCurrentView('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-3 text-left group focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AF37]"
          >
            <div className="w-10 h-10 rounded-sm bg-gradient-to-br from-[#1c1c1c] to-[#0c0c0c] border border-[#D4AF37]/50 flex items-center justify-center shadow-lg group-hover:border-[#D4AF37] transition-all">
              <span className="font-display font-black text-xl text-[#D4AF37] tracking-wider">L</span>
            </div>
            <div>
              <span className="font-display font-bold text-xl tracking-[0.2em] text-white block leading-none">
                LOCKSEE<span className="text-[#D4AF37] font-black"> TECH</span>
              </span>
              <span className="text-[10px] uppercase tracking-[0.25em] text-[#888888] font-medium block mt-1">
                Premium Phone Accessories
              </span>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center space-x-8">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentView(item.id);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`text-sm uppercase tracking-wider font-medium transition-colors hover:text-[#D4AF37] relative py-1 ${
                  currentView === item.id ? 'text-[#D4AF37]' : 'text-[#B8B8B8]'
                }`}
              >
                {item.label}
                {currentView === item.id && (
                  <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#D4AF37]" />
                )}
              </button>
            ))}
          </nav>

          {/* Action Icons & Contact */}
          <div className="flex items-center gap-3 sm:gap-4">
            {/* Search Button */}
            <button
              onClick={onOpenSearch}
              className="p-2 text-[#B8B8B8] hover:text-[#D4AF37] transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AF37]"
              aria-label="Search accessories"
              title="Search products"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Track Order Button */}
            <button
              onClick={onOpenTrackOrder}
              className="hidden lg:flex items-center gap-1.5 text-xs font-semibold text-[#B8B8B8] hover:text-[#D4AF37] border border-[#2a2a2a] hover:border-[#D4AF37]/50 px-3 py-1.5 transition-colors"
              title="Track your order"
            >
              <PackageCheck className="w-4 h-4 text-[#D4AF37]" />
              <span>Track Order</span>
            </button>

            {/* WhatsApp Contact Button */}
            <a
              href={formattedWhatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-2 bg-[#151515] hover:bg-[#1f1f1f] text-[#E0E0E0] hover:text-[#25D366] border border-[#2e2e2e] hover:border-[#25D366]/40 px-3.5 py-1.5 text-xs font-semibold tracking-wide transition-all shadow-sm"
              title="Chat with sales on WhatsApp"
            >
              <MessageCircle className="w-4 h-4 text-[#25D366]" />
              <span>09024971419</span>
            </a>

            {/* Cart Trigger */}
            <button
              onClick={toggleCart}
              className="relative p-2.5 bg-[#151515] hover:bg-[#1a1a1a] text-white border border-[#D4AF37]/40 hover:border-[#D4AF37] transition-all flex items-center justify-center focus-visible:outline-none"
              aria-label="View shopping cart"
            >
              <ShoppingBag className="w-5 h-5 text-[#D4AF37]" />
              {totalItems > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-[#D4AF37] text-black font-extrabold text-[11px] min-w-5 h-5 px-1 rounded-full flex items-center justify-center shadow-md">
                  {totalItems}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-[#B8B8B8] hover:text-white"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6 text-[#D4AF37]" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0d0d0d] border-b border-[#222222] px-6 py-5 space-y-4">
          <div className="flex flex-col space-y-3">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentView(item.id);
                  setMobileMenuOpen(false);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`text-left text-base font-medium py-2 transition-colors ${
                  currentView === item.id ? 'text-[#D4AF37] font-semibold' : 'text-[#CCCCCC]'
                }`}
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => {
                onOpenTrackOrder();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-2 text-left text-base font-medium py-2 text-[#D4AF37]"
            >
              <PackageCheck className="w-4 h-4" />
              <span>Track Your Order</span>
            </button>
          </div>

          <div className="pt-4 border-t border-[#222222]">
            <a
              href={formattedWhatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 bg-[#151515] border border-[#25D366]/40 text-white text-sm font-semibold rounded-none"
            >
              <MessageCircle className="w-4 h-4 text-[#25D366]" />
              <span>Chat With Us on WhatsApp: 09024971419</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
