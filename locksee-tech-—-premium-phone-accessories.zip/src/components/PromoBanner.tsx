import React from 'react';
import { Sparkles, X } from 'lucide-react';

interface PromoBannerProps {
  text: string;
  isActive: boolean;
}

export const PromoBanner: React.FC<PromoBannerProps> = ({ text, isActive }) => {
  const [dismissed, setDismissed] = React.useState(false);

  if (!isActive || dismissed || !text) return null;

  return (
    <div className="bg-gradient-to-r from-[#151515] via-[#201c10] to-[#151515] border-b border-[#D4AF37]/30 text-xs py-2 px-4 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div className="flex-1 flex items-center justify-center gap-2 text-center">
          <Sparkles className="w-3.5 h-3.5 text-[#D4AF37] shrink-0 animate-pulse" />
          <span className="text-[#E0E0E0] font-medium tracking-wide">
            {text}
          </span>
        </div>
        <button
          onClick={() => setDismissed(true)}
          className="text-[#888888] hover:text-[#D4AF37] transition-colors p-0.5"
          aria-label="Dismiss banner"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
