import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, MessageCircle } from 'lucide-react';

interface CartDrawerProps {
  onProceedToCheckout: () => void;
  whatsappNumber: string;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ onProceedToCheckout, whatsappNumber }) => {
  const {
    items,
    isCartOpen,
    closeCart,
    removeFromCart,
    updateQuantity,
    subtotal,
    totalItems
  } = useCart();

  const [deliveryRegion, setDeliveryRegion] = useState<'lagos' | 'nationwide'>('lagos');
  const deliveryFee = deliveryRegion === 'lagos' ? 2500 : 4500;
  const estimatedTotal = subtotal + (items.length > 0 ? deliveryFee : 0);

  if (!isCartOpen) return null;

  // Generate WhatsApp order message from current cart
  const cleanNumber = whatsappNumber.replace(/[^0-9]/g, '');
  const itemsText = items.map(
    (item, index) => `${index + 1}. ${item.product.name} (Qty: ${item.quantity}) - ₦${((item.product.discount_price || item.product.price) * item.quantity).toLocaleString()}`
  ).join('\n');

  const waMessage = `Hello LOCKSEE TECH, I would like to place an order for the following items:\n\n${itemsText}\n\nSubtotal: ₦${subtotal.toLocaleString()}\nEstimated Delivery (${deliveryRegion === 'lagos' ? 'Lagos' : 'Nationwide'}): ₦${deliveryFee.toLocaleString()}\nEstimated Total: ₦${estimatedTotal.toLocaleString()}\n\nPlease confirm availability and delivery timeframe.`;

  const waUrl = cleanNumber.startsWith('0')
    ? `https://wa.me/234${cleanNumber.substring(1)}?text=${encodeURIComponent(waMessage)}`
    : `https://wa.me/${cleanNumber}?text=${encodeURIComponent(waMessage)}`;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={closeCart}
        className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
      />

      {/* Drawer */}
      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#0e0e0e] border-l border-[#242424] text-white flex flex-col shadow-2xl">
          {/* Header */}
          <div className="p-6 border-b border-[#222222] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-[#181818] border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37]">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-lg font-bold font-display tracking-wide text-white">Your Cart</h2>
                <span className="text-xs text-[#888888]">{totalItems} {totalItems === 1 ? 'item' : 'items'} selected</span>
              </div>
            </div>
            <button
              onClick={closeCart}
              className="p-2 text-[#888888] hover:text-white transition-colors"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-12">
                <div className="w-16 h-16 bg-[#161616] border border-[#2a2a2a] flex items-center justify-center text-[#555555]">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white mb-1">Your cart is empty</h3>
                  <p className="text-xs text-[#888888] max-w-xs">
                    Browse our premium chargers, cases, and power banks to upgrade your tech.
                  </p>
                </div>
                <button
                  onClick={closeCart}
                  className="px-6 py-2.5 bg-[#181818] hover:bg-[#D4AF37] text-white hover:text-black border border-[#333333] hover:border-[#D4AF37] text-xs uppercase font-bold tracking-wider transition-all"
                >
                  Start Shopping
                </button>
              </div>
            ) : (
              items.map((item) => {
                const unitPrice = item.product.discount_price || item.product.price;
                const itemTotal = unitPrice * item.quantity;
                const isMax = item.quantity >= item.product.stock;

                return (
                  <div
                    key={item.product.id}
                    className="p-3 bg-[#141414] border border-[#222222] flex gap-3.5 relative"
                  >
                    {/* Thumbnail */}
                    <div className="w-20 h-20 bg-[#0a0a0a] shrink-0 border border-[#242424] overflow-hidden">
                      <img
                        src={item.product.images[0]}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Details */}
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <h4 className="text-xs font-bold text-white line-clamp-1">
                            {item.product.name}
                          </h4>
                          <button
                            onClick={() => removeFromCart(item.product.id)}
                            className="text-[#666666] hover:text-red-400 p-0.5"
                            title="Remove item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <span className="text-[10px] text-[#777777] font-mono block">
                          SKU: {item.product.sku}
                        </span>
                      </div>

                      <div className="flex items-center justify-between pt-2">
                        {/* Quantity Counter */}
                        <div className="flex items-center border border-[#2e2e2e] bg-[#0c0c0c]">
                          <button
                            onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                            className="p-1 text-[#888888] hover:text-white transition-colors"
                            aria-label="Decrease quantity"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-8 text-center text-xs font-bold font-mono text-white">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                            disabled={isMax}
                            className={`p-1 transition-colors ${
                              isMax ? 'text-[#444444] cursor-not-allowed' : 'text-[#888888] hover:text-white'
                            }`}
                            aria-label="Increase quantity"
                            title={isMax ? `Max stock available: ${item.product.stock}` : undefined}
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        {/* Price */}
                        <div className="text-right">
                          <span className="text-xs font-bold text-[#D4AF37]">
                            ₦{itemTotal.toLocaleString()}
                          </span>
                          {item.quantity > 1 && (
                            <span className="text-[10px] text-[#777777] block">
                              @ ₦{unitPrice.toLocaleString()} each
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer & Checkout Summary */}
          {items.length > 0 && (
            <div className="p-6 border-t border-[#222222] bg-[#121212] space-y-4">
              {/* Delivery Estimation Toggle */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-[#888888]">Delivery Estimate:</span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setDeliveryRegion('lagos')}
                      className={`px-2 py-0.5 text-[10px] font-bold uppercase transition-all ${
                        deliveryRegion === 'lagos'
                          ? 'bg-[#D4AF37] text-black'
                          : 'bg-[#1e1e1e] text-[#888888] hover:text-white'
                      }`}
                    >
                      Lagos (₦2,500)
                    </button>
                    <button
                      onClick={() => setDeliveryRegion('nationwide')}
                      className={`px-2 py-0.5 text-[10px] font-bold uppercase transition-all ${
                        deliveryRegion === 'nationwide'
                          ? 'bg-[#D4AF37] text-black'
                          : 'bg-[#1e1e1e] text-[#888888] hover:text-white'
                      }`}
                    >
                      Other States (₦4,500)
                    </button>
                  </div>
                </div>
              </div>

              {/* Subtotal & Totals */}
              <div className="space-y-2 pt-2 border-t border-[#202020] text-xs">
                <div className="flex justify-between text-[#888888]">
                  <span>Subtotal</span>
                  <span className="font-medium text-white">₦{subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-[#888888]">
                  <span>Delivery Fee</span>
                  <span className="font-medium text-white">₦{deliveryFee.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-[#262626]">
                  <span>Total Amount</span>
                  <span className="text-base text-[#D4AF37] font-black">
                    ₦{estimatedTotal.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-2.5 pt-2">
                <button
                  onClick={() => {
                    closeCart();
                    onProceedToCheckout();
                  }}
                  className="w-full py-3.5 bg-gradient-to-r from-[#D4AF37] via-[#F4D068] to-[#AA820A] text-black font-extrabold text-xs uppercase tracking-widest hover:brightness-110 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                >
                  <span>Proceed to Checkout</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                {/* WhatsApp Quick Order */}
                <a
                  href={waUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 bg-[#181818] hover:bg-[#202020] text-[#25D366] hover:text-[#2ee072] border border-[#25D366]/30 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Order via WhatsApp (09024971419)</span>
                </a>

                <button
                  onClick={closeCart}
                  className="w-full py-2 text-center text-xs text-[#777777] hover:text-white transition-colors"
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
