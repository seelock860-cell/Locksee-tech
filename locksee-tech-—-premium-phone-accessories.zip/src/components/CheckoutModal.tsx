import React, { useState, useEffect, useRef } from 'react';
import { useCart } from '../context/CartContext';
import { api } from '../lib/api';
import { X, Lock, ShieldCheck, Building2, MessageCircle, AlertCircle, Loader2 } from 'lucide-react';
import { Order } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderSuccess: (order: Order, bankDetails: any) => void;
  whatsappNumber: string;
}

const NIGERIAN_STATES = [
  'Lagos', 'Abuja (FCT)', 'Abia', 'Adamawa', 'Akwa Ibom', 'Anambra', 'Bauchi',
  'Bayelsa', 'Benue', 'Borno', 'Cross River', 'Delta', 'Ebonyi', 'Edo',
  'Ekiti', 'Enugu', 'Gombe', 'Imo', 'Jigawa', 'Kaduna', 'Kano', 'Katsina',
  'Kebbi', 'Kogi', 'Kwara', 'Nasarawa', 'Niger', 'Ogun', 'Ondo', 'Osun',
  'Oyo', 'Plateau', 'Rivers', 'Sokoto', 'Taraba', 'Yobe', 'Zamfara'
];

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  onOrderSuccess,
  whatsappNumber
}) => {
  const { items, subtotal, clearCart } = useCart();
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const [formData, setFormData] = useState({
    customer_name: '',
    customer_phone: '',
    customer_email: '',
    delivery_address: '',
    state: 'Lagos',
    city: '',
    delivery_instructions: '',
    payment_method: 'bank_transfer' as 'bank_transfer' | 'whatsapp'
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Prevent background body scroll when checkout is open
  useEffect(() => {
    if (isOpen) {
      const prevOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      // Reset scroll position to very top so the beginning is always visible
      if (scrollContainerRef.current) {
        scrollContainerRef.current.scrollTop = 0;
      }
      return () => {
        document.body.style.overflow = prevOverflow;
      };
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const isLagos = formData.state.toLowerCase().includes('lagos');
  const deliveryFee = isLagos ? 2500 : 4500;
  const finalTotal = subtotal + deliveryFee;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formData.customer_name.trim()) {
      setError('Please enter your full name in Section 1');
      if (scrollContainerRef.current) {
        scrollContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
      }
      return;
    }
    if (!formData.customer_phone.trim()) {
      setError('Please enter a valid Nigerian phone number in Section 1');
      if (scrollContainerRef.current) {
        scrollContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
      }
      return;
    }
    if (!formData.delivery_address.trim() || !formData.city.trim()) {
      setError('Please complete the delivery street address and city in Section 2');
      return;
    }
    if (items.length === 0) {
      setError('Your shopping cart is empty');
      return;
    }

    setIsSubmitting(true);

    try {
      // Submit order to backend (which runs strict server-side stock & price verification)
      const payload = {
        customer_name: formData.customer_name,
        customer_phone: formData.customer_phone,
        customer_email: formData.customer_email || undefined,
        delivery_address: formData.delivery_address,
        state: formData.state,
        city: formData.city,
        delivery_instructions: formData.delivery_instructions || undefined,
        items: items.map(i => ({
          product_id: i.product.id,
          quantity: i.quantity
        })),
        payment_method: formData.payment_method
      };

      const result = await api.createOrder(payload);

      if (result.success && result.order) {
        clearCart();
        onClose();
        onOrderSuccess(result.order, result.bank_details);
      } else {
        setError('Order could not be submitted. Please review your cart.');
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred during order processing');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto overscroll-contain bg-black/85 backdrop-blur-sm flex justify-center items-start sm:items-center p-2 sm:p-4 py-3 sm:py-6">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-transparent"
        aria-hidden="true"
      />

      {/* Modal Dialog with Fixed Header and Scrollable Content */}
      <div className="relative w-full max-w-2xl bg-[#0e0e0e] border border-[#2b2b2b] text-white shadow-2xl z-10 flex flex-col max-h-[94vh] sm:max-h-[90vh] overflow-hidden my-auto rounded-none">
        {/* Pinned Top Header (Always Visible at the beginning) */}
        <div className="shrink-0 p-4 sm:p-5 border-b border-[#222222] flex items-center justify-between bg-[#121212]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 bg-[#1c1c1c] border border-[#D4AF37]/50 flex items-center justify-center text-[#D4AF37]">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold font-display text-white leading-tight">
                Secure Customer Checkout
              </h2>
              <p className="text-[11px] text-[#888888]">
                LOCKSEE TECH — Nationwide Delivery across Nigeria
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-[#888888] hover:text-white transition-colors cursor-pointer"
            aria-label="Close checkout"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body with touch inertia */}
        <div
          ref={scrollContainerRef}
          className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 overscroll-contain"
          style={{ WebkitOverflowScrolling: 'touch' }}
        >
          {/* Error Message */}
          {error && (
            <div className="p-3.5 bg-red-950/70 border border-red-800 text-red-200 text-xs flex items-start gap-3">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <div className="leading-relaxed">{error}</div>
            </div>
          )}

          <form id="checkout-form" onSubmit={handleSubmit} className="space-y-6">
            {/* 1. CUSTOMER CONTACT DETAILS */}
            <div className="bg-[#121212] border border-[#222222] p-4 sm:p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-[#1f1f1f] pb-2">
                <h3 className="text-xs uppercase font-bold tracking-widest text-[#D4AF37]">
                  1. Customer Information
                </h3>
                <span className="text-[10px] text-[#777777] uppercase font-semibold">Step 1 of 3</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-1.5">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Babatunde Adeleke"
                    value={formData.customer_name}
                    onChange={e => setFormData({ ...formData, customer_name: e.target.value })}
                    className="w-full bg-[#181818] border border-[#2e2e2e] focus:border-[#D4AF37] px-3.5 py-2.5 text-sm text-white focus:outline-none transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-1.5">
                    Phone Number (WhatsApp reachable) *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 08012345678"
                    value={formData.customer_phone}
                    onChange={e => setFormData({ ...formData, customer_phone: e.target.value })}
                    className="w-full bg-[#181818] border border-[#2e2e2e] focus:border-[#D4AF37] px-3.5 py-2.5 text-sm text-white focus:outline-none transition-colors"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-1.5">
                    Email Address (Optional, for payment confirmation)
                  </label>
                  <input
                    type="email"
                    placeholder="e.g. adeleke@example.com"
                    value={formData.customer_email}
                    onChange={e => setFormData({ ...formData, customer_email: e.target.value })}
                    className="w-full bg-[#181818] border border-[#2e2e2e] focus:border-[#D4AF37] px-3.5 py-2.5 text-sm text-white focus:outline-none transition-colors"
                  />
                </div>
              </div>
            </div>

            {/* 2. DELIVERY ADDRESS */}
            <div className="bg-[#121212] border border-[#222222] p-4 sm:p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-[#1f1f1f] pb-2">
                <h3 className="text-xs uppercase font-bold tracking-widest text-[#D4AF37]">
                  2. Delivery Address
                </h3>
                <span className="text-[10px] text-[#777777] uppercase font-semibold">Step 2 of 3</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-1.5">
                    Street Address & House/Office Number *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 14 Admiralty Way, Lekki Phase 1"
                    value={formData.delivery_address}
                    onChange={e => setFormData({ ...formData, delivery_address: e.target.value })}
                    className="w-full bg-[#181818] border border-[#2e2e2e] focus:border-[#D4AF37] px-3.5 py-2.5 text-sm text-white focus:outline-none transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-1.5">
                    State *
                  </label>
                  <select
                    value={formData.state}
                    onChange={e => setFormData({ ...formData, state: e.target.value })}
                    className="w-full bg-[#181818] border border-[#2e2e2e] focus:border-[#D4AF37] px-3.5 py-2.5 text-sm text-white focus:outline-none transition-colors"
                  >
                    {NIGERIAN_STATES.map(st => (
                      <option key={st} value={st} className="bg-[#121212]">
                        {st} {st === 'Lagos' ? '(Lagos Dispatch - ₦2,500)' : '(Nationwide Courier - ₦4,500)'}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-1.5">
                    City / Town *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Ikeja, Lekki, or Ibadan"
                    value={formData.city}
                    onChange={e => setFormData({ ...formData, city: e.target.value })}
                    className="w-full bg-[#181818] border border-[#2e2e2e] focus:border-[#D4AF37] px-3.5 py-2.5 text-sm text-white focus:outline-none transition-colors"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-1.5">
                    Special Delivery Instructions (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Call before arrival, leave with security at the gate"
                    value={formData.delivery_instructions}
                    onChange={e => setFormData({ ...formData, delivery_instructions: e.target.value })}
                    className="w-full bg-[#181818] border border-[#2e2e2e] focus:border-[#D4AF37] px-3.5 py-2.5 text-sm text-white focus:outline-none transition-colors"
                  />
                </div>
              </div>
            </div>

            {/* 3. PAYMENT METHOD */}
            <div className="bg-[#121212] border border-[#222222] p-4 sm:p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-[#1f1f1f] pb-2">
                <h3 className="text-xs uppercase font-bold tracking-widest text-[#D4AF37]">
                  3. Payment Method
                </h3>
                <span className="text-[10px] text-[#777777] uppercase font-semibold">Step 3 of 3</span>
              </div>

              <div className="space-y-3">
                {/* Bank Transfer */}
                <label className={`block p-4 border transition-all cursor-pointer ${
                  formData.payment_method === 'bank_transfer'
                    ? 'bg-[#181818] border-[#D4AF37]'
                    : 'bg-[#121212] border-[#242424] hover:border-[#383838]'
                }`}>
                  <div className="flex items-start gap-3">
                    <input
                      type="radio"
                      name="payment_method"
                      value="bank_transfer"
                      checked={formData.payment_method === 'bank_transfer'}
                      onChange={() => setFormData({ ...formData, payment_method: 'bank_transfer' })}
                      className="mt-1 text-[#D4AF37] focus:ring-0"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-[#D4AF37]" />
                        <span className="text-sm font-bold text-white">Direct Bank Transfer (GTBank)</span>
                      </div>
                      <p className="text-xs text-[#888888] mt-1 leading-relaxed">
                        Instant transfer to our corporate account. <strong className="text-[#D4AF37]">Important:</strong> The order remains in <span className="underline">Unpaid / Pending</span> status until the transfer is verified by our finance team.
                      </p>
                    </div>
                  </div>
                </label>


                {/* WhatsApp Ordering */}
                <label className={`block p-4 border transition-all cursor-pointer ${
                  formData.payment_method === 'whatsapp'
                    ? 'bg-[#181818] border-[#25D366]'
                    : 'bg-[#121212] border-[#242424] hover:border-[#383838]'
                }`}>
                  <div className="flex items-start gap-3">
                    <input
                      type="radio"
                      name="payment_method"
                      value="whatsapp"
                      checked={formData.payment_method === 'whatsapp'}
                      onChange={() => setFormData({ ...formData, payment_method: 'whatsapp' })}
                      className="mt-1 text-[#25D366] focus:ring-0"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <MessageCircle className="w-4 h-4 text-[#25D366]" />
                        <span className="text-sm font-bold text-white">WhatsApp Ordering & Assisted Checkout</span>
                      </div>
                      <p className="text-xs text-[#888888] mt-1 leading-relaxed">
                        Generates your official order reference and opens a chat directly with our sales rep (09024971419) to finalize dispatch.
                      </p>
                    </div>
                  </div>
                </label>
              </div>
            </div>

            {/* Pricing Summary Breakdown */}
            <div className="p-4 bg-[#141414] border border-[#242424] space-y-2 text-xs">
              <div className="flex justify-between text-[#888888]">
                <span>Cart Subtotal ({items.reduce((s, i) => s + i.quantity, 0)} items)</span>
                <span className="text-white font-medium">₦{subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-[#888888]">
                <span>Delivery Fee ({formData.state})</span>
                <span className="text-white font-medium">₦{deliveryFee.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-[#262626]">
                <span>Total Payable</span>
                <span className="text-lg text-[#D4AF37] font-black">
                  ₦{finalTotal.toLocaleString()}
                </span>
              </div>
            </div>
          </form>
        </div>

        {/* Pinned Bottom Submit Action Bar */}
        <div className="shrink-0 p-4 border-t border-[#222222] bg-[#121212]">
          <button
            type="submit"
            form="checkout-form"
            disabled={isSubmitting}
            className="w-full py-4 bg-gradient-to-r from-[#D4AF37] via-[#F4D068] to-[#AA820A] text-black font-extrabold text-sm uppercase tracking-widest hover:brightness-110 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Verifying Stock & Creating Order...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-5 h-5" />
                <span>Confirm Order (₦{finalTotal.toLocaleString()})</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
