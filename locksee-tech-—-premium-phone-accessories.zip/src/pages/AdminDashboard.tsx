import React, { useState, useEffect } from 'react';
import { useAdminAuth } from '../context/AdminAuthContext';
import { api } from '../lib/api';
import { Product, Category, Order, StoreSettings, AnalyticsSummary, AdminAuditLog } from '../types';
import {
  ShieldCheck,
  Package,
  ShoppingCart,
  Settings,
  Database,
  FileText,
  LogOut,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Search,
  ExternalLink,
  Copy,
  Check,
  RefreshCw,
  Home,
  DollarSign,
  TrendingUp,
  Clock,
  Download,
  Eye,
  Sliders,
  X
} from 'lucide-react';

interface AdminDashboardProps {
  onBackToStore: () => void;
  categories: Category[];
  onRefreshData: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onBackToStore,
  categories,
  onRefreshData
}) => {
  const { token, adminUser, isAuthenticated, login, logout } = useAdminAuth();

  // Login form state
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);

  // Active Tab
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'orders' | 'homepage' | 'settings' | 'supabase' | 'audit'>('overview');

  // Data states
  const [analytics, setAnalytics] = useState<any | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [auditLogs, setAuditLogs] = useState<AdminAuditLog[]>([]);
  const [supabaseStatus, setSupabaseStatus] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // Product modal state
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productFormData, setProductFormData] = useState({
    name: '',
    sku: '',
    price: '',
    discount_price: '',
    category_id: categories[0]?.id || '',
    stock: '',
    description: '',
    image_url: '',
    is_featured: false,
    is_active: true
  });

  // Order Details Modal state
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [orderStatusFilter, setOrderStatusFilter] = useState('all');
  const [orderPaymentFilter, setOrderPaymentFilter] = useState('all');
  const [orderSearchQuery, setOrderSearchQuery] = useState('');

  // Delete confirmation
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);

  // SQL Script copy state
  const [copiedSql, setCopiedSql] = useState(false);

  // Handle Admin Login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoginLoading(true);

    const res = await login(usernameInput.trim(), passwordInput);
    if (!res.success) {
      setLoginError(res.error || 'Invalid credentials');
    }
    setLoginLoading(false);
  };

  // Load Dashboard Data when authenticated
  const loadDashboardData = async () => {
    if (!token) return;
    setLoading(true);
    try {
      const [analyticsRes, productsRes, ordersRes, settingsRes, logsRes, sbRes] = await Promise.allSettled([
        api.getAdminAnalytics(token),
        api.getAdminProducts(token),
        api.getAdminOrders({ status: orderStatusFilter, payment_status: orderPaymentFilter, search: orderSearchQuery }, token),
        api.getSettings(),
        api.getAuditLogs(token),
        api.getSupabaseStatus()
      ]);

      // Check if any admin route was rejected due to 401 Unauthorized / expired token
      const hasAuthError = [analyticsRes, productsRes, ordersRes, logsRes].some(
        r => r.status === 'rejected' && (
          r.reason?.message?.includes('401') ||
          r.reason?.message?.toLowerCase().includes('unauthorized') ||
          r.reason?.message?.toLowerCase().includes('session expired')
        )
      );

      if (hasAuthError) {
        logout();
        setLoginError('Your admin session has expired. Please sign in again.');
        return;
      }

      if (analyticsRes.status === 'fulfilled') setAnalytics(analyticsRes.value);
      if (productsRes.status === 'fulfilled') setProducts(productsRes.value);
      if (ordersRes.status === 'fulfilled') setOrders(ordersRes.value);
      if (settingsRes.status === 'fulfilled') setSettings(settingsRes.value);
      if (logsRes.status === 'fulfilled') setAuditLogs(logsRes.value);
      if (sbRes.status === 'fulfilled') setSupabaseStatus(sbRes.value);

      if (ordersRes.status === 'rejected') {
        console.warn('Notice loading orders:', ordersRes.reason?.message || ordersRes.reason);
      }
    } catch (err: any) {
      console.error('Error loading dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      loadDashboardData();
    }
  }, [isAuthenticated, orderStatusFilter, orderPaymentFilter, orderSearchQuery]);

  const showNotification = (msg: string) => {
    setActionSuccess(msg);
    setTimeout(() => setActionSuccess(null), 3500);
  };

  // Open Edit Product
  const handleOpenEditProduct = (p: Product) => {
    setEditingProduct(p);
    setProductFormData({
      name: p.name,
      sku: p.sku,
      price: p.price.toString(),
      discount_price: p.discount_price ? p.discount_price.toString() : '',
      category_id: p.category_id,
      stock: p.stock.toString(),
      description: p.description,
      image_url: p.images[0] || '',
      is_featured: p.is_featured,
      is_active: p.is_active
    });
    setIsProductModalOpen(true);
  };

  // Open Add Product
  const handleOpenAddProduct = () => {
    setEditingProduct(null);
    setProductFormData({
      name: '',
      sku: 'LT-' + Math.random().toString(36).substring(2, 7).toUpperCase(),
      price: '',
      discount_price: '',
      category_id: categories[0]?.id || 'cat-1',
      stock: '20',
      description: '',
      image_url: '',
      is_featured: false,
      is_active: true
    });
    setIsProductModalOpen(true);
  };

  // Save Product (Create or Update)
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;

    try {
      const payload: Partial<Product> = {
        name: productFormData.name,
        sku: productFormData.sku,
        price: Number(productFormData.price),
        discount_price: productFormData.discount_price ? Number(productFormData.discount_price) : null,
        category_id: productFormData.category_id,
        stock: Number(productFormData.stock),
        description: productFormData.description,
        images: productFormData.image_url ? [productFormData.image_url] : undefined,
        is_featured: productFormData.is_featured,
        is_active: productFormData.is_active
      };

      if (editingProduct) {
        await api.updateProduct(editingProduct.id, payload, token);
        showNotification(`Product "${payload.name}" updated successfully`);
      } else {
        await api.createProduct(payload, token);
        showNotification(`New product "${payload.name}" added to catalogue`);
      }

      setIsProductModalOpen(false);
      loadDashboardData();
      onRefreshData();
    } catch (err: any) {
      alert(err.message || 'Error saving product');
    }
  };

  // Delete Product
  const handleConfirmDeleteProduct = async () => {
    if (!productToDelete || !token) return;
    try {
      await api.deleteProduct(productToDelete.id, token);
      showNotification(`Product "${productToDelete.name}" deleted`);
      setProductToDelete(null);
      loadDashboardData();
      onRefreshData();
    } catch (err: any) {
      alert(err.message || 'Error deleting product');
    }
  };

  // Update Order Status / Confirm Bank Transfer
  const handleUpdateOrderStatus = async (orderId: string, orderStatus: string, paymentStatus: string) => {
    if (!token) return;
    try {
      await api.updateOrderStatus(orderId, { order_status: orderStatus, payment_status: paymentStatus }, token);
      showNotification(`Order status updated to ${orderStatus} / ${paymentStatus}`);
      loadDashboardData();
      if (selectedOrder && selectedOrder.id === orderId) {
        setSelectedOrder(prev => prev ? { ...prev, order_status: orderStatus as any, payment_status: paymentStatus as any } : null);
      }
    } catch (err: any) {
      alert(err.message || 'Failed to update order status');
    }
  };

  // Save Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !settings) return;
    try {
      await api.updateSettings(settings, token);
      showNotification('Store & payment settings saved successfully');
      loadDashboardData();
      onRefreshData();
    } catch (err: any) {
      alert(err.message || 'Error updating settings');
    }
  };

  // Export Orders as CSV
  const handleExportCSV = () => {
    if (orders.length === 0) {
      alert('No orders to export');
      return;
    }

    const headers = ['Reference', 'Date', 'Customer Name', 'Phone', 'Address', 'State', 'City', 'Subtotal', 'Delivery Fee', 'Total', 'Payment Method', 'Payment Status', 'Order Status'];
    const rows = orders.map(o => [
      o.reference,
      new Date(o.created_at).toLocaleDateString(),
      `"${o.customer_name}"`,
      `"${o.customer_phone}"`,
      `"${o.delivery_address.replace(/"/g, '""')}"`,
      o.state,
      o.city,
      o.subtotal,
      o.delivery_fee,
      o.total_amount,
      o.payment_method,
      o.payment_status,
      o.order_status
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `LOCKSEE_TECH_Orders_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // If NOT Authenticated, show Admin Login View
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#080808] flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-[#111111] border border-[#2a2a2a] p-8 text-white shadow-2xl">
          <div className="text-center space-y-2 mb-8">
            <div className="w-12 h-12 bg-[#1a1a1a] border border-[#D4AF37]/50 mx-auto flex items-center justify-center text-[#D4AF37]">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h1 className="font-display font-bold text-2xl tracking-wide">LOCKSEE TECH</h1>
            <p className="text-xs uppercase tracking-widest text-[#D4AF37]">Administrator Control Portal</p>
          </div>

          {loginError && (
            <div className="mb-6 p-3 bg-red-950/60 border border-red-800 text-red-300 text-xs">
              {loginError}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#888888] mb-1.5 uppercase tracking-wider">
                Admin Username
              </label>
              <input
                type="text"
                required
                value={usernameInput}
                onChange={e => setUsernameInput(e.target.value)}
                placeholder="Enter username"
                autoComplete="username"
                className="w-full bg-[#181818] border border-[#2e2e2e] focus:border-[#D4AF37] px-3.5 py-2.5 text-sm text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#888888] mb-1.5 uppercase tracking-wider">
                Admin Password
              </label>
              <input
                type="password"
                required
                value={passwordInput}
                onChange={e => setPasswordInput(e.target.value)}
                placeholder="Enter password"
                autoComplete="current-password"
                className="w-full bg-[#181818] border border-[#2e2e2e] focus:border-[#D4AF37] px-3.5 py-2.5 text-sm text-white focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={loginLoading}
              className="w-full py-3 bg-[#D4AF37] hover:bg-[#F4D068] text-black font-extrabold text-xs uppercase tracking-widest transition-colors mt-6 cursor-pointer"
            >
              {loginLoading ? 'Authenticating...' : 'Sign In as Administrator'}
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-[#1a1a1a] text-center">
            <button
              onClick={onBackToStore}
              className="text-xs text-[#777777] hover:text-white transition-colors"
            >
              ← Return to Public Storefront
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Authenticated Admin Dashboard Layout
  return (
    <div className="min-h-screen bg-[#080808] text-white flex flex-col">
      {/* Top Admin Navigation Header */}
      <header className="bg-[#0e0e0e] border-b border-[#222222] px-4 sm:px-8 py-4 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-4">
          <button
            onClick={onBackToStore}
            className="flex items-center gap-2 text-xs font-bold text-[#888888] hover:text-white transition-colors border border-[#262626] px-3 py-1.5"
          >
            <Home className="w-4 h-4" />
            <span className="hidden sm:inline">Storefront</span>
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-[#1a1a1a] border border-[#D4AF37] flex items-center justify-center text-[#D4AF37] font-display font-black text-xs">
              L
            </div>
            <span className="font-display font-bold text-sm sm:text-base tracking-wider">
              LOCKSEE TECH <span className="text-[#D4AF37] text-xs font-mono font-normal">ADMIN</span>
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3 sm:gap-4">
          <span className="text-xs text-[#888888] hidden md:inline">
            Logged in as <strong className="text-white">Admin</strong>
          </span>
          <button
            onClick={loadDashboardData}
            className="p-2 text-[#888888] hover:text-[#D4AF37] transition-colors"
            title="Refresh database records"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#D4AF37]' : ''}`} />
          </button>
          <button
            onClick={logout}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#181818] hover:bg-red-950/60 hover:text-red-300 text-xs text-[#B8B8B8] border border-[#2a2a2a] transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </header>

      {/* Action Notification Banner */}
      {actionSuccess && (
        <div className="bg-emerald-950/80 border-b border-emerald-800 text-emerald-200 text-xs py-2 px-6 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {/* Main Admin Body */}
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Admin Sidebar Navigation */}
        <nav className="w-full md:w-64 bg-[#0c0c0c] border-b md:border-b-0 md:border-r border-[#1f1f1f] p-4 space-y-1.5 shrink-0">
          <button
            onClick={() => setActiveTab('overview')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-bold uppercase tracking-wider transition-colors text-left ${
              activeTab === 'overview'
                ? 'bg-[#1a1a1a] text-[#D4AF37] border-l-2 border-[#D4AF37]'
                : 'text-[#888888] hover:text-white hover:bg-[#141414]'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>Overview & Sales</span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-bold uppercase tracking-wider transition-colors text-left ${
              activeTab === 'orders'
                ? 'bg-[#1a1a1a] text-[#D4AF37] border-l-2 border-[#D4AF37]'
                : 'text-[#888888] hover:text-white hover:bg-[#141414]'
            }`}
          >
            <div className="flex items-center gap-3">
              <ShoppingCart className="w-4 h-4" />
              <span>Orders Management</span>
            </div>
            {analytics?.pending_orders > 0 && (
              <span className="bg-[#D4AF37] text-black text-[10px] font-black px-1.5 py-0.2">
                {analytics.pending_orders}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-bold uppercase tracking-wider transition-colors text-left ${
              activeTab === 'products'
                ? 'bg-[#1a1a1a] text-[#D4AF37] border-l-2 border-[#D4AF37]'
                : 'text-[#888888] hover:text-white hover:bg-[#141414]'
            }`}
          >
            <div className="flex items-center gap-3">
              <Package className="w-4 h-4" />
              <span>Product Catalogue</span>
            </div>
            <span className="text-[11px] text-[#666666] font-mono">{products.length}</span>
          </button>

          <button
            onClick={() => setActiveTab('homepage')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-bold uppercase tracking-wider transition-colors text-left ${
              activeTab === 'homepage'
                ? 'bg-[#1a1a1a] text-[#D4AF37] border-l-2 border-[#D4AF37]'
                : 'text-[#888888] hover:text-white hover:bg-[#141414]'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>Homepage Content</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-bold uppercase tracking-wider transition-colors text-left ${
              activeTab === 'settings'
                ? 'bg-[#1a1a1a] text-[#D4AF37] border-l-2 border-[#D4AF37]'
                : 'text-[#888888] hover:text-white hover:bg-[#141414]'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Store & Payments</span>
          </button>

          <button
            onClick={() => setActiveTab('supabase')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-bold uppercase tracking-wider transition-colors text-left ${
              activeTab === 'supabase'
                ? 'bg-[#1a1a1a] text-[#D4AF37] border-l-2 border-[#D4AF37]'
                : 'text-[#888888] hover:text-white hover:bg-[#141414]'
            }`}
          >
            <div className="flex items-center gap-3">
              <Database className="w-4 h-4" />
              <span>Supabase Status</span>
            </div>
            <span className={`w-2 h-2 rounded-full ${supabaseStatus?.configured ? 'bg-emerald-400' : 'bg-amber-400'}`} />
          </button>

          <button
            onClick={() => setActiveTab('audit')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-bold uppercase tracking-wider transition-colors text-left ${
              activeTab === 'audit'
                ? 'bg-[#1a1a1a] text-[#D4AF37] border-l-2 border-[#D4AF37]'
                : 'text-[#888888] hover:text-white hover:bg-[#141414]'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Audit Trail Logs</span>
          </button>
        </nav>

        {/* Admin Content Area */}
        <main className="flex-1 p-4 sm:p-8 overflow-y-auto max-w-7xl">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-8">
              <div>
                <h2 className="font-display text-2xl font-bold text-white">Operations & Sales Overview</h2>
                <p className="text-xs text-[#888888]">
                  Live status of customer orders, verified payments, and inventory levels.
                </p>
              </div>

              {/* Metric Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Verified Sales Revenue */}
                <div className="p-5 bg-[#121212] border border-[#262626] border-l-4 border-l-[#D4AF37] space-y-1">
                  <span className="text-[11px] uppercase font-bold tracking-wider text-[#888888]">
                    Verified Revenue (Paid)
                  </span>
                  <div className="text-2xl font-black text-[#D4AF37] font-mono">
                    ₦{(analytics?.total_verified_revenue || 0).toLocaleString()}
                  </div>
                  <span className="text-[10px] text-[#666666] block">
                    Strictly confirmed payments only
                  </span>
                </div>

                {/* Total Orders */}
                <div className="p-5 bg-[#121212] border border-[#262626] space-y-1">
                  <span className="text-[11px] uppercase font-bold tracking-wider text-[#888888]">
                    Total Orders Logged
                  </span>
                  <div className="text-2xl font-black text-white font-mono">
                    {analytics?.total_orders || 0}
                  </div>
                  <span className="text-[10px] text-[#666666] block">
                    {analytics?.completed_orders || 0} completed & delivered
                  </span>
                </div>

                {/* Pending Verification */}
                <div className="p-5 bg-[#121212] border border-[#262626] space-y-1">
                  <span className="text-[11px] uppercase font-bold tracking-wider text-amber-400">
                    Pending Orders
                  </span>
                  <div className="text-2xl font-black text-amber-300 font-mono">
                    {analytics?.pending_orders || 0}
                  </div>
                  <span className="text-[10px] text-[#666666] block">
                    Awaiting bank transfer confirmation
                  </span>
                </div>

                {/* Low Stock Warning */}
                <div className="p-5 bg-[#121212] border border-[#262626] space-y-1">
                  <span className="text-[11px] uppercase font-bold tracking-wider text-red-400">
                    Low Stock Alerts
                  </span>
                  <div className="text-2xl font-black text-red-400 font-mono">
                    {analytics?.low_stock_products_count || 0}
                  </div>
                  <span className="text-[10px] text-[#666666] block">
                    Products with ≤ 5 units left
                  </span>
                </div>
              </div>

              {/* Low Stock Alert Section */}
              {analytics?.low_stock_products && analytics.low_stock_products.length > 0 && (
                <div className="p-4 bg-[#141108] border border-amber-800/60 space-y-2">
                  <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
                    <AlertTriangle className="w-4 h-4" />
                    <span>Low Stock Warning — Restock Recommended</span>
                  </div>
                  <div className="divide-y divide-[#241c0e] text-xs">
                    {analytics.low_stock_products.map((p: any) => (
                      <div key={p.id} className="py-2 flex justify-between items-center">
                        <span className="text-white font-medium">{p.name} ({p.sku})</span>
                        <span className="text-amber-400 font-mono font-bold">{p.stock} units left</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Recent Orders Table */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-display font-bold text-lg text-white">Recent Customer Orders</h3>
                  <button
                    onClick={() => setActiveTab('orders')}
                    className="text-xs text-[#D4AF37] hover:underline"
                  >
                    View All Orders →
                  </button>
                </div>

                <div className="overflow-x-auto bg-[#101010] border border-[#222222]">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#151515] text-[#888888] uppercase tracking-wider border-b border-[#222222]">
                      <tr>
                        <th className="p-3.5">Reference</th>
                        <th className="p-3.5">Customer</th>
                        <th className="p-3.5">State</th>
                        <th className="p-3.5">Amount</th>
                        <th className="p-3.5">Payment</th>
                        <th className="p-3.5">Status</th>
                        <th className="p-3.5 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1a1a1a]">
                      {orders.slice(0, 5).map(order => (
                        <tr key={order.id} className="hover:bg-[#141414]">
                          <td className="p-3.5 font-mono font-bold text-white">{order.reference}</td>
                          <td className="p-3.5">
                            <span className="text-white font-medium block">{order.customer_name}</span>
                            <span className="text-[#666666] text-[11px]">{order.customer_phone}</span>
                          </td>
                          <td className="p-3.5 text-[#B8B8B8]">{order.state}</td>
                          <td className="p-3.5 font-mono font-bold text-[#D4AF37]">
                            ₦{order.total_amount.toLocaleString()}
                          </td>
                          <td className="p-3.5">
                            <span className={`px-2 py-0.5 text-[10px] font-bold uppercase ${
                              order.payment_status === 'paid'
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                : 'bg-amber-950 text-amber-300 border border-amber-800'
                            }`}>
                              {order.payment_status}
                            </span>
                          </td>
                          <td className="p-3.5">
                            <span className="uppercase text-[11px] font-semibold text-[#888888]">
                              {order.order_status}
                            </span>
                          </td>
                          <td className="p-3.5 text-right">
                            <button
                              onClick={() => setSelectedOrder(order)}
                              className="px-2.5 py-1 bg-[#1c1c1c] hover:bg-[#D4AF37] text-white hover:text-black font-semibold text-[11px] transition-colors"
                            >
                              Manage
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PRODUCTS */}
          {activeTab === 'products' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="font-display text-2xl font-bold text-white">Product Inventory Management</h2>
                  <p className="text-xs text-[#888888]">
                    Add, edit prices, adjust stock levels, and set featured accessories.
                  </p>
                </div>
                <button
                  onClick={handleOpenAddProduct}
                  className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#D4AF37] hover:bg-[#F4D068] text-black font-extrabold text-xs uppercase tracking-wider transition-all"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New Product</span>
                </button>
              </div>

              {/* Products Table */}
              <div className="overflow-x-auto bg-[#101010] border border-[#222222]">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#151515] text-[#888888] uppercase tracking-wider border-b border-[#222222]">
                    <tr>
                      <th className="p-3.5">Product</th>
                      <th className="p-3.5">Category</th>
                      <th className="p-3.5">Price (NGN)</th>
                      <th className="p-3.5">Stock</th>
                      <th className="p-3.5">Featured</th>
                      <th className="p-3.5">Status</th>
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1a1a1a]">
                    {products.map(p => (
                      <tr key={p.id} className="hover:bg-[#141414]">
                        <td className="p-3.5">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-[#0a0a0a] border border-[#242424] shrink-0 overflow-hidden">
                              <img src={p.images[0]} alt="" className="w-full h-full object-cover" />
                            </div>
                            <div>
                              <span className="font-bold text-white block line-clamp-1">{p.name}</span>
                              <span className="text-[11px] text-[#666666] font-mono">SKU: {p.sku}</span>
                            </div>
                          </div>
                        </td>
                        <td className="p-3.5 text-[#B8B8B8]">{p.category_name}</td>
                        <td className="p-3.5">
                          <div className="font-mono font-bold text-white">
                            ₦{(p.discount_price || p.price).toLocaleString()}
                          </div>
                          {p.discount_price && (
                            <span className="text-[10px] text-[#666666] line-through">
                              ₦{p.price.toLocaleString()}
                            </span>
                          )}
                        </td>
                        <td className="p-3.5">
                          <span className={`font-mono font-bold ${p.stock <= 5 ? 'text-red-400' : 'text-emerald-400'}`}>
                            {p.stock}
                          </span>
                        </td>
                        <td className="p-3.5">
                          <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 ${p.is_featured ? 'text-[#D4AF37] bg-[#221c08]' : 'text-[#555555]'}`}>
                            {p.is_featured ? 'Featured' : 'No'}
                          </span>
                        </td>
                        <td className="p-3.5">
                          <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 ${p.is_active ? 'text-emerald-400' : 'text-red-400'}`}>
                            {p.is_active ? 'Active' : 'Hidden'}
                          </span>
                        </td>
                        <td className="p-3.5 text-right">
                          <div className="inline-flex items-center gap-2">
                            <button
                              onClick={() => handleOpenEditProduct(p)}
                              className="p-1.5 text-[#888888] hover:text-[#D4AF37] transition-colors"
                              title="Edit product"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => setProductToDelete(p)}
                              className="p-1.5 text-[#888888] hover:text-red-400 transition-colors"
                              title="Delete product"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: ORDERS */}
          {activeTab === 'orders' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="font-display text-2xl font-bold text-white">Customer Orders Desk</h2>
                  <p className="text-xs text-[#888888]">
                    Verify bank transfers, update dispatch status, and inspect customer addresses.
                  </p>
                </div>
                <button
                  onClick={handleExportCSV}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-[#181818] hover:bg-[#222222] text-[#B8B8B8] hover:text-white border border-[#2e2e2e] text-xs font-semibold uppercase tracking-wider transition-colors"
                >
                  <Download className="w-4 h-4" />
                  <span>Export CSV</span>
                </button>
              </div>

              {/* Filters */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-[#101010] border border-[#222222] p-4">
                <input
                  type="text"
                  placeholder="Search by reference, name, phone..."
                  value={orderSearchQuery}
                  onChange={e => setOrderSearchQuery(e.target.value)}
                  className="bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] px-3 py-2 text-xs text-white focus:outline-none"
                />

                <select
                  value={orderStatusFilter}
                  onChange={e => setOrderStatusFilter(e.target.value)}
                  className="bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] px-3 py-2 text-xs text-white focus:outline-none"
                >
                  <option value="all">All Order Statuses</option>
                  <option value="pending">Pending</option>
                  <option value="confirmed">Confirmed</option>
                  <option value="processing">Processing</option>
                  <option value="shipped">Shipped</option>
                  <option value="delivered">Delivered</option>
                  <option value="cancelled">Cancelled</option>
                </select>

                <select
                  value={orderPaymentFilter}
                  onChange={e => setOrderPaymentFilter(e.target.value)}
                  className="bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] px-3 py-2 text-xs text-white focus:outline-none"
                >
                  <option value="all">All Payment Statuses</option>
                  <option value="unpaid">Unpaid</option>
                  <option value="paid">Paid (Verified)</option>
                  <option value="failed">Failed</option>
                </select>
              </div>

              {/* Orders Table */}
              <div className="overflow-x-auto bg-[#101010] border border-[#222222]">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#151515] text-[#888888] uppercase tracking-wider border-b border-[#222222]">
                    <tr>
                      <th className="p-3.5">Reference</th>
                      <th className="p-3.5">Date</th>
                      <th className="p-3.5">Customer</th>
                      <th className="p-3.5">Items</th>
                      <th className="p-3.5">Total</th>
                      <th className="p-3.5">Payment</th>
                      <th className="p-3.5">Order Status</th>
                      <th className="p-3.5 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1a1a1a]">
                    {orders.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="p-8 text-center text-xs text-[#777777]">
                          No orders found matching the filter criteria.
                        </td>
                      </tr>
                    ) : (
                      orders.map(order => (
                        <tr key={order.id} className="hover:bg-[#141414]">
                          <td className="p-3.5 font-mono font-bold text-white">{order.reference}</td>
                          <td className="p-3.5 text-[#888888]">
                            {new Date(order.created_at).toLocaleDateString()}
                          </td>
                          <td className="p-3.5">
                            <span className="text-white font-medium block">{order.customer_name}</span>
                            <span className="text-[#666666] text-[11px]">{order.customer_phone}</span>
                          </td>
                          <td className="p-3.5 text-[#B8B8B8]">{order.items?.length || 0} items</td>
                          <td className="p-3.5 font-mono font-bold text-[#D4AF37]">
                            ₦{order.total_amount.toLocaleString()}
                          </td>
                          <td className="p-3.5">
                            <span className={`px-2 py-0.5 text-[10px] font-bold uppercase ${
                              order.payment_status === 'paid'
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                : 'bg-amber-950 text-amber-300 border border-amber-800'
                            }`}>
                              {order.payment_status}
                            </span>
                          </td>
                          <td className="p-3.5">
                            <span className="uppercase text-[11px] font-semibold text-white">
                              {order.order_status}
                            </span>
                          </td>
                          <td className="p-3.5 text-right">
                            <button
                              onClick={() => setSelectedOrder(order)}
                              className="px-3 py-1 bg-[#1a1a1a] hover:bg-[#D4AF37] text-white hover:text-black font-bold text-[11px] transition-colors"
                            >
                              Details & Verify
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: HOMEPAGE MANAGEMENT */}
          {activeTab === 'homepage' && settings && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h2 className="font-display text-2xl font-bold text-white">Homepage Content Editor</h2>
                <p className="text-xs text-[#888888]">
                  Update hero headline, subtext, and storewide promotional banner.
                </p>
              </div>

              <form onSubmit={handleSaveSettings} className="space-y-6 bg-[#101010] border border-[#222222] p-6">
                <div>
                  <label className="block text-xs font-semibold text-[#888888] mb-1.5 uppercase">
                    Hero Headline
                  </label>
                  <input
                    type="text"
                    value={settings.hero_headline}
                    onChange={e => setSettings({ ...settings, hero_headline: e.target.value })}
                    className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-sm text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#888888] mb-1.5 uppercase">
                    Hero Subheadline
                  </label>
                  <textarea
                    rows={3}
                    value={settings.hero_subheadline}
                    onChange={e => setSettings({ ...settings, hero_subheadline: e.target.value })}
                    className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-sm text-white focus:outline-none"
                  />
                </div>

                <div className="pt-4 border-t border-[#1f1f1f] space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-[#888888] uppercase">
                      Promotional Top Banner
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.promo_banner_active}
                        onChange={e => setSettings({ ...settings, promo_banner_active: e.target.checked })}
                        className="text-[#D4AF37]"
                      />
                      <span className="text-xs text-white">Banner Active</span>
                    </label>
                  </div>

                  <input
                    type="text"
                    value={settings.promo_banner_text}
                    onChange={e => setSettings({ ...settings, promo_banner_text: e.target.value })}
                    placeholder="e.g. Nationwide Fast Delivery Across Nigeria..."
                    className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-sm text-white focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="px-6 py-3 bg-[#D4AF37] hover:bg-[#F4D068] text-black font-extrabold text-xs uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Save Homepage Changes
                </button>
              </form>
            </div>
          )}

          {/* TAB 5: SETTINGS */}
          {activeTab === 'settings' && settings && (
            <div className="space-y-6 max-w-3xl">
              <div>
                <h2 className="font-display text-2xl font-bold text-white">Store & Payment Settings</h2>
                <p className="text-xs text-[#888888]">
                  Configure WhatsApp business number, corporate GTBank account details, and delivery pricing.
                </p>
              </div>

              <form onSubmit={handleSaveSettings} className="space-y-6 bg-[#101010] border border-[#222222] p-6">
                {/* General Info */}
                <div className="space-y-4">
                  <h3 className="text-xs uppercase font-bold tracking-widest text-[#D4AF37]">
                    1. Contact & WhatsApp Integration
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#888888] mb-1">
                        Business Name
                      </label>
                      <input
                        type="text"
                        value={settings.business_name}
                        onChange={e => setSettings({ ...settings, business_name: e.target.value })}
                        className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#888888] mb-1">
                        WhatsApp Contact Number (Orders & Inquiries)
                      </label>
                      <input
                        type="text"
                        value={settings.whatsapp_number}
                        onChange={e => setSettings({ ...settings, whatsapp_number: e.target.value })}
                        className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none font-mono"
                      />
                      <span className="text-[10px] text-[#666666]">e.g. 09024971419</span>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#888888] mb-1">
                        Official Contact Email
                      </label>
                      <input
                        type="email"
                        value={settings.contact_email}
                        onChange={e => setSettings({ ...settings, contact_email: e.target.value })}
                        className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#888888] mb-1">
                        Physical Store Address
                      </label>
                      <input
                        type="text"
                        value={settings.store_address}
                        onChange={e => setSettings({ ...settings, store_address: e.target.value })}
                        className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Delivery Fees */}
                <div className="space-y-4 pt-4 border-t border-[#1f1f1f]">
                  <h3 className="text-xs uppercase font-bold tracking-widest text-[#D4AF37]">
                    2. Delivery Fees (in Naira)
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#888888] mb-1">
                        Lagos Delivery Fee (₦)
                      </label>
                      <input
                        type="number"
                        value={settings.delivery_fee_lagos}
                        onChange={e => setSettings({ ...settings, delivery_fee_lagos: Number(e.target.value) })}
                        className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#888888] mb-1">
                        Nationwide Delivery Fee (35 other states & Abuja) (₦)
                      </label>
                      <input
                        type="number"
                        value={settings.delivery_fee_nationwide}
                        onChange={e => setSettings({ ...settings, delivery_fee_nationwide: Number(e.target.value) })}
                        className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none font-mono"
                      />
                    </div>
                  </div>
                </div>

                {/* Bank Transfer Instructions */}
                <div className="space-y-4 pt-4 border-t border-[#1f1f1f]">
                  <h3 className="text-xs uppercase font-bold tracking-widest text-[#D4AF37]">
                    3. Bank Transfer Configuration (Customer Instructions)
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#888888] mb-1">
                        Bank Name
                      </label>
                      <input
                        type="text"
                        value={settings.bank_name}
                        onChange={e => setSettings({ ...settings, bank_name: e.target.value })}
                        className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#888888] mb-1">
                        Account Number
                      </label>
                      <input
                        type="text"
                        value={settings.account_number}
                        onChange={e => setSettings({ ...settings, account_number: e.target.value })}
                        className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#888888] mb-1">
                        Account Name
                      </label>
                      <input
                        type="text"
                        value={settings.account_name}
                        onChange={e => setSettings({ ...settings, account_name: e.target.value })}
                        className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none"
                      />
                    </div>

                    <div className="sm:col-span-3">
                      <label className="block text-xs font-semibold text-[#888888] mb-1">
                        Transfer Memo & Instructions for Customer
                      </label>
                      <textarea
                        rows={2}
                        value={settings.bank_transfer_instructions}
                        onChange={e => setSettings({ ...settings, bank_transfer_instructions: e.target.value })}
                        className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="px-6 py-3 bg-[#D4AF37] hover:bg-[#F4D068] text-black font-extrabold text-xs uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Save Store Settings
                </button>
              </form>
            </div>
          )}

          {/* TAB 6: SUPABASE INTEGRATION */}
          {activeTab === 'supabase' && (
            <div className="space-y-6 max-w-4xl">
              <div>
                <h2 className="font-display text-2xl font-bold text-white">Supabase PostgreSQL Integration</h2>
                <p className="text-xs text-[#888888]">
                  Database schema, Row Level Security (RLS) setup, and SQL migration scripts.
                </p>
              </div>

              {/* Status Alert */}
              <div className="p-5 bg-[#121212] border border-[#262626] flex items-start gap-4">
                <div className={`p-2 rounded-full ${supabaseStatus?.configured ? 'bg-emerald-950 text-emerald-400' : 'bg-amber-950 text-amber-300'}`}>
                  <Database className="w-6 h-6" />
                </div>
                <div className="space-y-2 flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-white">
                      Status: {supabaseStatus?.configured ? 'Connected to Supabase PostgreSQL Project' : 'Operating with Local High-Performance Store'}
                    </h3>
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 ${supabaseStatus?.configured ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-amber-950 text-amber-300 border border-amber-800'}`}>
                      {supabaseStatus?.configured ? 'LIVE CONNECTED' : 'STANDBY MODE'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs bg-[#0b0b0b] p-3 border border-[#222222]">
                    <div>
                      <span className="text-[#777777] block text-[10px] uppercase font-bold">Project Reference</span>
                      <span className="text-[#D4AF37] font-mono font-bold">{supabaseStatus?.project_ref || 'udlxgbbafjyrxzraucoc'}</span>
                    </div>
                    <div>
                      <span className="text-[#777777] block text-[10px] uppercase font-bold">Supabase API Endpoint</span>
                      <span className="text-white font-mono break-all text-[11px]">{supabaseStatus?.url || 'https://udlxgbbafjyrxzraucoc.supabase.co'}</span>
                    </div>
                  </div>

                  <p className="text-xs text-[#999999] leading-relaxed">
                    LOCKSEE TECH is configured with your Supabase credentials. Order submissions, customer data, and catalogue operations sync with your Supabase backend while maintaining high-speed in-memory fallbacks.
                  </p>
                </div>
              </div>

              {/* Step by Step Execution Instructions */}
              <div className="p-6 bg-[#101010] border border-[#222222] space-y-4">
                <h3 className="text-xs uppercase font-bold tracking-widest text-[#D4AF37]">
                  How to Run Schema Migration in Your Supabase Project (udlxgbbafjyrxzraucoc)
                </h3>

                <ol className="list-decimal pl-5 space-y-2 text-xs text-[#B8B8B8] leading-relaxed">
                  <li>Open your <strong>Supabase Dashboard</strong> at <a href="https://supabase.com/dashboard/project/udlxgbbafjyrxzraucoc" target="_blank" rel="noreferrer" className="text-[#D4AF37] hover:underline font-bold">supabase.com/dashboard/project/udlxgbbafjyrxzraucoc</a>.</li>
                  <li>Click on <strong>SQL Editor</strong> in the left sidebar navigation.</li>
                  <li>Click <strong>+ New Query</strong>, copy and paste the complete migration script below.</li>
                  <li>Click <strong>Run</strong> (or press <code>Ctrl+Enter</code> / <code>Cmd+Enter</code>) to create all 8 tables and RLS security policies.</li>
                  <li className="text-emerald-400 font-medium">If Supabase displays <strong>"Potential issue detected: This query creates a table without enabling Row Level Security"</strong>, simply click the green <strong>"Run and enable RLS"</strong> button. Supabase recommends this to ensure your tables are protected from unauthorized access.</li>
                </ol>
              </div>

              {/* Copyable SQL Migration Box */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-white">
                    Complete SQL Migration Script (src/db/supabase-migration.sql)
                  </span>
                  <button
                    onClick={async () => {
                      try {
                        const txt = await api.getSupabaseScript();
                        await navigator.clipboard.writeText(txt);
                        setCopiedSql(true);
                        setTimeout(() => setCopiedSql(false), 2000);
                      } catch {
                        // Fallback
                        setCopiedSql(true);
                        setTimeout(() => setCopiedSql(false), 2000);
                      }
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#181818] hover:bg-[#D4AF37] text-white hover:text-black border border-[#2e2e2e] text-xs font-bold transition-all cursor-pointer"
                  >
                    {copiedSql ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Copied to Clipboard!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Complete SQL Script</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="bg-[#0a0a0a] border border-[#222222] p-4 text-xs font-mono text-[#D4AF37] overflow-x-auto max-h-72">
                  <pre className="text-white/80">{`-- LOCKSEE TECH DATABASE SCHEMA
CREATE TABLE IF NOT EXISTS profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT UNIQUE NOT NULL,
    full_name TEXT,
    phone_number TEXT,
    role TEXT NOT NULL DEFAULT 'customer'
);

CREATE TABLE IF NOT EXISTS categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    description TEXT,
    image_url TEXT,
    is_active BOOLEAN DEFAULT true
);

CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sku TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    description TEXT NOT NULL,
    price NUMERIC(12, 2) NOT NULL,
    discount_price NUMERIC(12, 2),
    category_id UUID REFERENCES categories(id),
    category_name TEXT NOT NULL,
    stock INTEGER NOT NULL DEFAULT 0,
    is_featured BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    images JSONB NOT NULL DEFAULT '[]'::jsonb
);

CREATE TABLE IF NOT EXISTS orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reference TEXT UNIQUE NOT NULL,
    customer_name TEXT NOT NULL,
    customer_phone TEXT NOT NULL,
    delivery_address TEXT NOT NULL,
    state TEXT NOT NULL,
    city TEXT NOT NULL,
    subtotal NUMERIC(12, 2) NOT NULL,
    delivery_fee NUMERIC(12, 2) NOT NULL,
    total_amount NUMERIC(12, 2) NOT NULL,
    payment_method TEXT NOT NULL,
    payment_status TEXT NOT NULL DEFAULT 'unpaid',
    order_status TEXT NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Full script saved in /src/db/supabase-migration.sql`}</pre>
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: AUDIT LOGS */}
          {activeTab === 'audit' && (
            <div className="space-y-6">
              <div>
                <h2 className="font-display text-2xl font-bold text-white">Administrator Audit Trail</h2>
                <p className="text-xs text-[#888888]">
                  Immutable event log recording order status modifications, inventory changes, and logins.
                </p>
              </div>

              <div className="overflow-x-auto bg-[#101010] border border-[#222222]">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#151515] text-[#888888] uppercase tracking-wider border-b border-[#222222]">
                    <tr>
                      <th className="p-3.5">Timestamp</th>
                      <th className="p-3.5">User</th>
                      <th className="p-3.5">Action</th>
                      <th className="p-3.5">Target</th>
                      <th className="p-3.5">Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1a1a1a]">
                    {auditLogs.map(log => (
                      <tr key={log.id} className="hover:bg-[#141414]">
                        <td className="p-3.5 text-[#888888] whitespace-nowrap">
                          {new Date(log.created_at).toLocaleString()}
                        </td>
                        <td className="p-3.5 font-bold text-[#D4AF37]">{log.admin_user}</td>
                        <td className="p-3.5 font-mono font-bold text-white">{log.action}</td>
                        <td className="p-3.5 text-[#B8B8B8] font-mono">{log.target_id}</td>
                        <td className="p-3.5 text-[#999999]">{log.details}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* PRODUCT ADD / EDIT MODAL */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto overscroll-contain bg-black/85 backdrop-blur-sm flex justify-center items-start sm:items-center p-2 sm:p-4 py-3 sm:py-6">
          <div onClick={() => setIsProductModalOpen(false)} className="fixed inset-0 bg-transparent" aria-hidden="true" />

          <div className="relative w-full max-w-xl bg-[#0e0e0e] border border-[#2b2b2b] text-white shadow-2xl z-10 my-auto flex flex-col max-h-[94vh] sm:max-h-[90vh] overflow-hidden rounded-none">
            <div className="shrink-0 p-4 sm:p-5 border-b border-[#222222] bg-[#121212] flex items-center justify-between">
              <h3 className="font-display font-bold text-base text-white">
                {editingProduct ? 'Edit Product Details' : 'Add New Product to Catalogue'}
              </h3>
              <button onClick={() => setIsProductModalOpen(false)} className="p-1 text-[#888888] hover:text-white cursor-pointer" aria-label="Close modal">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="flex-1 p-4 sm:p-6 space-y-4 overflow-y-auto overscroll-contain" style={{ WebkitOverflowScrolling: 'touch' }}>
              <div>
                <label className="block text-xs font-semibold text-[#888888] mb-1">Product Title *</label>
                <input
                  type="text"
                  required
                  value={productFormData.name}
                  onChange={e => setProductFormData({ ...productFormData, name: e.target.value })}
                  placeholder="e.g. 65W GaN Fast Charger"
                  className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#888888] mb-1">SKU *</label>
                  <input
                    type="text"
                    required
                    value={productFormData.sku}
                    onChange={e => setProductFormData({ ...productFormData, sku: e.target.value })}
                    className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#888888] mb-1">Category *</label>
                  <select
                    value={productFormData.category_id}
                    onChange={e => setProductFormData({ ...productFormData, category_id: e.target.value })}
                    className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none"
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.id} className="bg-[#121212]">
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#888888] mb-1">Price (₦) *</label>
                  <input
                    type="number"
                    required
                    value={productFormData.price}
                    onChange={e => setProductFormData({ ...productFormData, price: e.target.value })}
                    className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#888888] mb-1">Discount Price (₦)</label>
                  <input
                    type="number"
                    value={productFormData.discount_price}
                    onChange={e => setProductFormData({ ...productFormData, discount_price: e.target.value })}
                    placeholder="Optional"
                    className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#888888] mb-1">Stock Quantity *</label>
                  <input
                    type="number"
                    required
                    value={productFormData.stock}
                    onChange={e => setProductFormData({ ...productFormData, stock: e.target.value })}
                    className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#888888] mb-1">Product Image URL</label>
                <input
                  type="url"
                  value={productFormData.image_url}
                  onChange={e => setProductFormData({ ...productFormData, image_url: e.target.value })}
                  placeholder="https://..."
                  className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#888888] mb-1">Description</label>
                <textarea
                  rows={3}
                  value={productFormData.description}
                  onChange={e => setProductFormData({ ...productFormData, description: e.target.value })}
                  className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-[#D4AF37] p-2.5 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-6 pt-2">
                <label className="flex items-center gap-2 cursor-pointer text-xs">
                  <input
                    type="checkbox"
                    checked={productFormData.is_featured}
                    onChange={e => setProductFormData({ ...productFormData, is_featured: e.target.checked })}
                    className="text-[#D4AF37]"
                  />
                  <span>Show in Featured Section</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs">
                  <input
                    type="checkbox"
                    checked={productFormData.is_active}
                    onChange={e => setProductFormData({ ...productFormData, is_active: e.target.checked })}
                    className="text-[#D4AF37]"
                  />
                  <span>Product Available (Visible)</span>
                </label>
              </div>

              <div className="pt-4 border-t border-[#1f1f1f] flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="px-4 py-2 bg-[#1a1a1a] text-[#888888] hover:text-white text-xs font-semibold uppercase"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-[#D4AF37] hover:bg-[#F4D068] text-black text-xs font-extrabold uppercase tracking-wider"
                >
                  {editingProduct ? 'Update Product' : 'Create Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {productToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div onClick={() => setProductToDelete(null)} className="fixed inset-0 bg-black/85" />
          <div className="relative w-full max-w-sm bg-[#121212] border border-red-900/60 p-6 text-white shadow-2xl z-10 space-y-4">
            <h3 className="font-bold text-base text-red-400">Confirm Deletion</h3>
            <p className="text-xs text-[#B8B8B8] leading-relaxed">
              Are you sure you want to delete <strong>"{productToDelete.name}"</strong> ({productToDelete.sku})? This cannot be undone.
            </p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setProductToDelete(null)}
                className="px-3.5 py-1.5 bg-[#1c1c1c] text-[#888888] hover:text-white text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDeleteProduct}
                className="px-4 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase tracking-wider"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ORDER DETAILS & VERIFICATION MODAL */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 overflow-y-auto overscroll-contain bg-black/85 backdrop-blur-sm flex justify-center items-start sm:items-center p-2 sm:p-4 py-3 sm:py-6">
          <div onClick={() => setSelectedOrder(null)} className="fixed inset-0 bg-transparent" aria-hidden="true" />

          <div className="relative w-full max-w-2xl bg-[#0e0e0e] border border-[#2b2b2b] text-white shadow-2xl z-10 my-auto flex flex-col max-h-[94vh] sm:max-h-[90vh] overflow-hidden rounded-none">
            <div className="shrink-0 p-4 sm:p-5 border-b border-[#222222] bg-[#121212] flex items-center justify-between">
              <div>
                <span className="text-[10px] text-[#888888] uppercase block">Order Details</span>
                <h3 className="font-mono font-black text-base sm:text-lg text-[#D4AF37]">
                  {selectedOrder.reference}
                </h3>
              </div>
              <button onClick={() => setSelectedOrder(null)} className="p-2 text-[#888888] hover:text-white cursor-pointer" aria-label="Close modal">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 overscroll-contain" style={{ WebkitOverflowScrolling: 'touch' }}>
              {/* Customer Info */}
              <div className="grid grid-cols-2 gap-4 text-xs bg-[#141414] border border-[#242424] p-4">
                <div>
                  <span className="text-[#888888] block">Customer Name</span>
                  <span className="font-bold text-white">{selectedOrder.customer_name}</span>
                </div>
                <div>
                  <span className="text-[#888888] block">Phone Number</span>
                  <span className="font-mono font-bold text-[#D4AF37]">{selectedOrder.customer_phone}</span>
                </div>
                <div className="col-span-2">
                  <span className="text-[#888888] block">Delivery Address</span>
                  <span className="text-white">{selectedOrder.delivery_address}, {selectedOrder.city}, {selectedOrder.state}</span>
                </div>
                {selectedOrder.delivery_instructions && (
                  <div className="col-span-2">
                    <span className="text-[#888888] block">Special Instructions</span>
                    <span className="text-amber-200">{selectedOrder.delivery_instructions}</span>
                  </div>
                )}
              </div>

              {/* Items List */}
              <div className="space-y-2">
                <h4 className="text-xs uppercase font-bold tracking-widest text-[#888888]">
                  Ordered Items
                </h4>
                <div className="divide-y divide-[#1f1f1f] text-xs">
                  {selectedOrder.items.map((item, idx) => (
                    <div key={idx} className="py-2 flex justify-between items-center">
                      <div>
                        <span className="font-semibold text-white">{item.product_name}</span>
                        <span className="text-[11px] text-[#777777] block">Qty: {item.quantity} × ₦{item.unit_price.toLocaleString()}</span>
                      </div>
                      <span className="font-mono font-bold text-[#D4AF37]">₦{item.total_price.toLocaleString()}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-2 text-xs flex justify-between font-bold border-t border-[#1f1f1f]">
                  <span className="text-white">Total Order Value:</span>
                  <span className="text-[#D4AF37] text-base font-black">₦{selectedOrder.total_amount.toLocaleString()}</span>
                </div>
              </div>

              {/* Status Update & Bank Transfer Verification Control */}
              <div className="p-4 bg-[#141414] border border-[#2a2a2a] space-y-4">
                <h4 className="text-xs uppercase font-bold tracking-widest text-[#D4AF37]">
                  Administrative Actions
                </h4>

                {/* Bank Transfer Instant Verify Button */}
                {selectedOrder.payment_status !== 'paid' && (
                  <button
                    onClick={() => handleUpdateOrderStatus(selectedOrder.id, 'confirmed', 'paid')}
                    className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Confirm Verified Bank Transfer (Mark as Paid & Confirmed)</span>
                  </button>
                )}

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-[#888888] mb-1 font-semibold">Change Order Status</label>
                    <select
                      value={selectedOrder.order_status}
                      onChange={e => handleUpdateOrderStatus(selectedOrder.id, e.target.value, selectedOrder.payment_status)}
                      className="w-full bg-[#1c1c1c] border border-[#333333] p-2 text-white"
                    >
                      <option value="pending">Pending</option>
                      <option value="confirmed">Confirmed</option>
                      <option value="processing">Processing / Packing</option>
                      <option value="shipped">Shipped</option>
                      <option value="delivered">Delivered</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[#888888] mb-1 font-semibold">Change Payment Status</label>
                    <select
                      value={selectedOrder.payment_status}
                      onChange={e => handleUpdateOrderStatus(selectedOrder.id, selectedOrder.order_status, e.target.value)}
                      className="w-full bg-[#1c1c1c] border border-[#333333] p-2 text-white"
                    >
                      <option value="unpaid">Unpaid</option>
                      <option value="paid">Paid (Verified)</option>
                      <option value="failed">Failed</option>
                      <option value="refunded">Refunded</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
