/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { CartProvider } from './context/CartContext';
import { AdminAuthProvider } from './context/AdminAuthContext';
import { api } from './lib/api';
import { Product, Category, StoreSettings, Order } from './types';

// UI Components
import { PromoBanner } from './components/PromoBanner';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { FeaturedCategories } from './components/FeaturedCategories';
import { WhyChooseUs } from './components/WhyChooseUs';
import { ProductCard } from './components/ProductCard';
import { ShopCatalogue } from './components/ShopCatalogue';
import { PolicyViews } from './components/PolicyViews';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderConfirmationModal } from './components/OrderConfirmationModal';
import { TrackOrderModal } from './components/TrackOrderModal';
import { SearchModal } from './components/SearchModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Footer } from './components/Footer';
import { AdminDashboard } from './pages/AdminDashboard';
import { ArrowRight, Loader2, Sparkles } from 'lucide-react';

export default function App() {
  // Check initial hash for admin access
  const isInitialAdmin = typeof window !== 'undefined' && (
    window.location.hash.toLowerCase() === '#/admin' ||
    window.location.hash.toLowerCase() === '#admin'
  );
  const [currentView, setCurrentView] = useState<string>(isInitialAdmin ? 'admin' : 'home');
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('all');
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Modals state
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isTrackOrderOpen, setIsTrackOrderOpen] = useState(false);
  const [trackInitialRef, setTrackInitialRef] = useState('');
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);
  const [confirmedBankDetails, setConfirmedBankDetails] = useState<any | null>(null);

  // Listen to browser hash changes for direct #/admin navigation
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.toLowerCase().trim();
      if (hash === '#/admin' || hash === '#admin') {
        setCurrentView('admin');
      } else if (hash === '' || hash === '#' || hash === '#/') {
        setCurrentView(prev => (prev === 'admin' ? 'home' : prev));
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Load initial data
  const loadData = async () => {
    try {
      const [productsData, categoriesData, settingsData] = await Promise.all([
        api.getProducts(),
        api.getCategories(),
        api.getSettings()
      ]);
      setProducts(productsData);
      setCategories(categoriesData);
      setSettings(settingsData);
    } catch (err) {
      console.error('Failed loading store data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const whatsappNumber = settings?.whatsapp_number || '09024971419';
  const businessName = settings?.business_name || 'LOCKSEE TECH';

  const handleSelectCategory = (catId: string) => {
    setSelectedCategoryId(catId);
    setCurrentView('shop');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOrderSuccess = (order: Order, bankDetails: any) => {
    setConfirmedOrder(order);
    setConfirmedBankDetails(bankDetails);
  };

  const handleTrackOrderFromConfirmation = (ref: string) => {
    setConfirmedOrder(null);
    setTrackInitialRef(ref);
    setIsTrackOrderOpen(true);
  };

  // If initial loading
  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#080808] flex flex-col items-center justify-center space-y-4">
        <div className="w-12 h-12 bg-[#121212] border border-[#D4AF37]/60 flex items-center justify-center text-[#D4AF37]">
          <span className="font-display font-black text-2xl">L</span>
        </div>
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-[#B8B8B8]">
          <Loader2 className="w-4 h-4 animate-spin text-[#D4AF37]" />
          <span>Loading LOCKSEE TECH...</span>
        </div>
      </div>
    );
  }

  // Admin View (Accessed only via #/admin URL)
  if (currentView === 'admin') {
    return (
      <AdminAuthProvider>
        <AdminDashboard
          onBackToStore={() => {
            window.location.hash = '';
            setCurrentView('home');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          categories={categories}
          onRefreshData={loadData}
        />
      </AdminAuthProvider>
    );
  }

  return (
    <CartProvider>
      <div className="min-h-screen bg-[#080808] text-white flex flex-col selection:bg-[#D4AF37]/30 selection:text-[#D4AF37]">
        {/* Top Promotional Banner */}
        {settings && (
          <PromoBanner
            text={settings.promo_banner_text}
            isActive={settings.promo_banner_active}
          />
        )}

        {/* Global Navigation Header */}
        <Header
          currentView={currentView}
          setCurrentView={(v) => {
            if (v === 'shop') setSelectedCategoryId('all');
            setCurrentView(v);
          }}
          whatsappNumber={whatsappNumber}
          businessName={businessName}
          onOpenSearch={() => setIsSearchOpen(true)}
          onOpenTrackOrder={() => {
            setTrackInitialRef('');
            setIsTrackOrderOpen(true);
          }}
        />

        {/* Dynamic Body Content */}
        <main className="flex-1">
          {/* VIEW: HOME */}
          {currentView === 'home' && (
            <>
              {/* Hero Section */}
              <Hero
                headline={settings?.hero_headline}
                subheadline={settings?.hero_subheadline}
                onShopNow={() => {
                  setSelectedCategoryId('all');
                  setCurrentView('shop');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                onExploreCategories={() => {
                  const catSec = document.getElementById('categories-section');
                  if (catSec) catSec.scrollIntoView({ behavior: 'smooth' });
                }}
              />

              {/* Featured Categories */}
              <div id="categories-section">
                <FeaturedCategories
                  categories={categories}
                  onSelectCategory={handleSelectCategory}
                />
              </div>

              {/* Featured Products Section */}
              <section className="py-16 sm:py-24 bg-[#080808] border-b border-[#1f1f1f]">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-12 pb-6 border-b border-[#222222] gap-4">
                    <div>
                      <div className="inline-flex items-center gap-1.5 text-xs uppercase font-bold tracking-[0.25em] text-[#D4AF37] mb-2">
                        <Sparkles className="w-3.5 h-3.5 fill-[#D4AF37]" />
                        <span>Curated Selection</span>
                      </div>
                      <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-wide">
                        Featured Accessories
                      </h2>
                    </div>

                    <button
                      onClick={() => {
                        setSelectedCategoryId('all');
                        setCurrentView('shop');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#D4AF37] hover:text-[#F4D068] transition-colors"
                    >
                      <span>Explore All Products ({products.length})</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {products.filter(p => p.is_featured).slice(0, 8).map(product => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        onQuickView={p => setQuickViewProduct(p)}
                      />
                    ))}
                  </div>
                </div>
              </section>

              {/* Why Choose Us */}
              <WhyChooseUs />
            </>
          )}

          {/* VIEW: SHOP */}
          {currentView === 'shop' && (
            <ShopCatalogue
              products={products}
              categories={categories}
              selectedCategoryId={selectedCategoryId}
              onSelectCategory={setSelectedCategoryId}
              onQuickView={p => setQuickViewProduct(p)}
            />
          )}

          {/* VIEW: CATEGORIES */}
          {currentView === 'categories' && (
            <div className="py-12">
              <FeaturedCategories
                categories={categories}
                onSelectCategory={handleSelectCategory}
              />
            </div>
          )}

          {/* VIEW: POLICIES / STATIC PAGES */}
          {['about', 'contact', 'delivery-info', 'return-policy', 'privacy-policy', 'terms'].includes(currentView) && (
            <PolicyViews
              view={currentView}
              onBack={() => {
                setCurrentView('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              whatsappNumber={whatsappNumber}
            />
          )}
        </main>

        {/* Global Footer */}
        <Footer
          categories={categories}
          onSelectCategory={handleSelectCategory}
          onNavigate={(v) => {
            if (v === 'track') {
              setIsTrackOrderOpen(true);
            } else {
              setCurrentView(v);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }
          }}
          whatsappNumber={whatsappNumber}
        />

        {/* Floating WhatsApp Action Button */}
        <FloatingWhatsApp whatsappNumber={whatsappNumber} />

        {/* Slide-Over Shopping Cart Drawer */}
        <CartDrawer
          onProceedToCheckout={() => setIsCheckoutOpen(true)}
          whatsappNumber={whatsappNumber}
        />

        {/* Checkout Modal */}
        <CheckoutModal
          isOpen={isCheckoutOpen}
          onClose={() => setIsCheckoutOpen(false)}
          onOrderSuccess={handleOrderSuccess}
          whatsappNumber={whatsappNumber}
        />

        {/* Order Confirmation Modal */}
        <OrderConfirmationModal
          order={confirmedOrder}
          bankDetails={confirmedBankDetails}
          onClose={() => setConfirmedOrder(null)}
          onTrackOrder={handleTrackOrderFromConfirmation}
          whatsappNumber={whatsappNumber}
        />

        {/* Track Order Modal */}
        <TrackOrderModal
          isOpen={isTrackOrderOpen}
          onClose={() => setIsTrackOrderOpen(false)}
          initialReference={trackInitialRef}
          whatsappNumber={whatsappNumber}
        />

        {/* Search Modal */}
        <SearchModal
          isOpen={isSearchOpen}
          onClose={() => setIsSearchOpen(false)}
          products={products}
          onSelectProduct={p => setQuickViewProduct(p)}
        />

        {/* Product Quick View / Detail Modal */}
        <ProductDetailModal
          product={quickViewProduct}
          onClose={() => setQuickViewProduct(null)}
          whatsappNumber={whatsappNumber}
        />
      </div>
    </CartProvider>
  );
}
