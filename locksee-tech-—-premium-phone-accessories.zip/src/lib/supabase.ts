import { createClient } from '@supabase/supabase-js';

// Sanitize URL by removing trailing slashes or /rest/v1 endpoints if provided
export const sanitizeSupabaseUrl = (rawUrl: string): string => {
  if (!rawUrl) return '';
  return rawUrl.trim().replace(/\/rest\/v1\/?$/i, '').replace(/\/+$/, '');
};

// Fallback project details provided by user
const DEFAULT_SUPABASE_URL = 'https://udlxgbbafjyrxzraucoc.supabase.co';
const DEFAULT_SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVkbHhnYmJhZmp5cnh6cmF1Y29jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMxNzU3MDksImV4cCI6MjEwODc1MTcwOX0.3CZAM1caQO69kIWk0_tMSwlhszxqQPr1fTqaJWcHoT8';

// Environment variables or localStorage fallback for runtime testing
export const getSupabaseConfig = () => {
  const envUrl = (import.meta.env.VITE_SUPABASE_URL as string) || '';
  const localUrl = (typeof window !== 'undefined' ? localStorage.getItem('locksee_supabase_url') : '') || '';
  const rawUrl = envUrl || localUrl || DEFAULT_SUPABASE_URL;

  const envKey = (import.meta.env.VITE_SUPABASE_ANON_KEY as string) || '';
  const localKey = (typeof window !== 'undefined' ? localStorage.getItem('locksee_supabase_anon_key') : '') || '';
  const key = envKey || localKey || DEFAULT_SUPABASE_KEY;

  const url = sanitizeSupabaseUrl(rawUrl);
  const isConfigured = Boolean(url && key && url.includes('supabase.co'));

  return { url, key, isConfigured };
};

export const { url: SUPABASE_URL, key: SUPABASE_ANON_KEY, isConfigured: IS_SUPABASE_CONFIGURED } = getSupabaseConfig();

export const supabase = (IS_SUPABASE_CONFIGURED && SUPABASE_URL && SUPABASE_ANON_KEY)
  ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  : null;

export const saveSupabaseConfig = (url: string, key: string) => {
  if (typeof window !== 'undefined') {
    if (url) localStorage.setItem('locksee_supabase_url', sanitizeSupabaseUrl(url));
    else localStorage.removeItem('locksee_supabase_url');

    if (key) localStorage.setItem('locksee_supabase_anon_key', key.trim());
    else localStorage.removeItem('locksee_supabase_anon_key');
  }
};

