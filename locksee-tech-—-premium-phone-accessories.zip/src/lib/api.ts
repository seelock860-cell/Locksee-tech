import { Product, Category, StoreSettings, Order, AnalyticsSummary, AdminAuditLog } from '../types';

const API_BASE = '/api';

export const api = {
  // Store Settings
  async getSettings(): Promise<StoreSettings> {
    const res = await fetch(`${API_BASE}/settings`);
    if (!res.ok) throw new Error('Failed to fetch settings');
    return res.json();
  },

  async updateSettings(settings: Partial<StoreSettings>, token: string): Promise<{ success: boolean; settings: StoreSettings }> {
    const res = await fetch(`${API_BASE}/admin/settings`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(settings)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to update settings');
    }
    return res.json();
  },

  // Categories
  async getCategories(): Promise<Category[]> {
    const res = await fetch(`${API_BASE}/categories`);
    if (!res.ok) throw new Error('Failed to fetch categories');
    return res.json();
  },

  // Products
  async getProducts(params?: { category?: string; search?: string; sort?: string; featured?: boolean }): Promise<Product[]> {
    const query = new URLSearchParams();
    if (params?.category) query.set('category', params.category);
    if (params?.search) query.set('search', params.search);
    if (params?.sort) query.set('sort', params.sort);
    if (params?.featured) query.set('featured', 'true');

    const res = await fetch(`${API_BASE}/products?${query.toString()}`);
    if (!res.ok) throw new Error('Failed to fetch products');
    return res.json();
  },

  async getProduct(id: string): Promise<Product> {
    const res = await fetch(`${API_BASE}/products/${id}`);
    if (!res.ok) throw new Error('Failed to fetch product');
    return res.json();
  },

  // Admin Products
  async getAdminProducts(token: string): Promise<Product[]> {
    const res = await fetch(`${API_BASE}/admin/products`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (res.status === 401) throw new Error('401 Unauthorized: Session expired or invalid');
    if (!res.ok) throw new Error('Failed to fetch admin products');
    return res.json();
  },

  async createProduct(productData: Partial<Product>, token: string): Promise<Product> {
    const res = await fetch(`${API_BASE}/admin/products`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(productData)
    });
    if (res.status === 401) throw new Error('401 Unauthorized: Session expired or invalid');
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to create product');
    }
    return res.json();
  },

  async updateProduct(id: string, productData: Partial<Product>, token: string): Promise<Product> {
    const res = await fetch(`${API_BASE}/admin/products/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(productData)
    });
    if (res.status === 401) throw new Error('401 Unauthorized: Session expired or invalid');
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to update product');
    }
    return res.json();
  },

  async deleteProduct(id: string, token: string): Promise<{ success: boolean }> {
    const res = await fetch(`${API_BASE}/admin/products/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` }
    });
    if (res.status === 401) throw new Error('401 Unauthorized: Session expired or invalid');
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to delete product');
    }
    return res.json();
  },

  // Orders
  async createOrder(orderData: {
    customer_name: string;
    customer_phone: string;
    customer_email?: string;
    delivery_address: string;
    state: string;
    city: string;
    delivery_instructions?: string;
    items: { product_id: string; quantity: number }[];
    payment_method: string;
    notes?: string;
  }): Promise<{ success: boolean; order: Order; bank_details: any }> {
    const res = await fetch(`${API_BASE}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to create order');
    }
    return res.json();
  },

  async trackOrder(reference: string): Promise<any> {
    const res = await fetch(`${API_BASE}/orders/track/${encodeURIComponent(reference)}`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Order not found');
    }
    return res.json();
  },

  // Payments
  async initializePayment(order_reference: string, email?: string): Promise<any> {
    const res = await fetch(`${API_BASE}/payments/initialize`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ order_reference, email })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Payment initialization failed');
    }
    return res.json();
  },

  async verifyPayment(reference: string): Promise<any> {
    const res = await fetch(`${API_BASE}/payments/verify/${encodeURIComponent(reference)}`);
    if (!res.ok) throw new Error('Verification request failed');
    return res.json();
  },

  // Admin
  async adminLogin(username: string, password: string): Promise<{ success: boolean; token: string; user: any }> {
    const res = await fetch(`${API_BASE}/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Invalid credentials');
    }
    return res.json();
  },

  async getAdminAnalytics(token: string): Promise<AnalyticsSummary & { recent_orders: Order[]; low_stock_products: any[] }> {
    const res = await fetch(`${API_BASE}/admin/analytics`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (res.status === 401) throw new Error('401 Unauthorized: Session expired or invalid');
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to fetch analytics');
    }
    return res.json();
  },

  async getAdminOrders(params: { status?: string; payment_status?: string; search?: string }, token: string): Promise<Order[]> {
    const query = new URLSearchParams();
    if (params.status && params.status !== 'all') query.set('status', params.status);
    if (params.payment_status && params.payment_status !== 'all') query.set('payment_status', params.payment_status);
    if (params.search && params.search.trim()) query.set('search', params.search.trim());

    const queryString = query.toString();
    const url = queryString ? `${API_BASE}/admin/orders?${queryString}` : `${API_BASE}/admin/orders`;

    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (res.status === 401) throw new Error('401 Unauthorized: Session expired or invalid');
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to fetch admin orders');
    }
    return res.json();
  },

  async updateOrderStatus(id: string, updates: { order_status?: string; payment_status?: string; notes?: string }, token: string): Promise<{ success: boolean; order: Order }> {
    const res = await fetch(`${API_BASE}/admin/orders/${id}/status`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(updates)
    });
    if (res.status === 401) throw new Error('401 Unauthorized: Session expired or invalid');
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to update order status');
    }
    return res.json();
  },

  async getAuditLogs(token: string): Promise<AdminAuditLog[]> {
    const res = await fetch(`${API_BASE}/admin/audit-logs`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (res.status === 401) throw new Error('401 Unauthorized: Session expired or invalid');
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to fetch audit logs');
    }
    return res.json();
  },

  async getSupabaseStatus(): Promise<{ configured: boolean; url: string; has_service_key: boolean }> {
    const res = await fetch(`${API_BASE}/supabase/status`);
    if (!res.ok) return { configured: false, url: 'Error', has_service_key: false };
    return res.json();
  },

  async getSupabaseScript(): Promise<string> {
    const res = await fetch(`${API_BASE}/admin/supabase-script`);
    if (!res.ok) throw new Error('Failed to fetch SQL script');
    return res.text();
  }
};
